"""
PG2GPKG - Export dialog
Copyright (C) 2025 Federico Gianoli — GPLv3
"""

import os

from qgis.core import QgsApplication, QgsMessageLog, QgsProject, Qgis
from qgis.PyQt.QtCore import Qt, QCoreApplication, QSettings
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLineEdit, QPushButton, QFileDialog, QComboBox,
    QLabel, QProgressDialog, QMessageBox, QCheckBox,
    QGroupBox, QAbstractItemView, QTreeWidget, QTreeWidgetItem,
    QHeaderView, QRadioButton, QButtonGroup, QDialogButtonBox,
)

# Collapsible group box (accordion). Falls back to a plain group box if the
# QGIS gui module is unavailable.
try:
    from qgis.gui import QgsCollapsibleGroupBox as _CollapsibleGroupBox
except ImportError:
    _CollapsibleGroupBox = QGroupBox

from .db_utils import (
    HAS_PSYCOPG2, get_pg_connections, pg_connect,
    get_schemas, get_tables_and_views, resolve_auth_params,
    get_qgis_projects_in_db,
)
from .export_engine import ExportWorker

LOG_TAG = "PG2GPKG"

# ── Qt6 scoped-enum compatibility ─────────────────────────────────────
try:
    _EchoPassword = QLineEdit.EchoMode.Password
except AttributeError:
    _EchoPassword = QLineEdit.Password

try:
    _HdrStretch = QHeaderView.ResizeMode.Stretch
except AttributeError:
    _HdrStretch = QHeaderView.Stretch

try:
    _HdrResizeToContents = QHeaderView.ResizeMode.ResizeToContents
except AttributeError:
    _HdrResizeToContents = QHeaderView.ResizeToContents

try:
    _NoSelection = QAbstractItemView.SelectionMode.NoSelection
except AttributeError:
    _NoSelection = QAbstractItemView.NoSelection

try:
    _ItemIsUserCheckable = Qt.ItemFlag.ItemIsUserCheckable
except AttributeError:
    _ItemIsUserCheckable = Qt.ItemIsUserCheckable

try:
    _ItemIsAutoTristate = Qt.ItemFlag.ItemIsAutoTristate
except AttributeError:
    _ItemIsAutoTristate = Qt.ItemIsAutoTristate

try:
    _Checked = Qt.CheckState.Checked
except AttributeError:
    _Checked = Qt.Checked

try:
    _Unchecked = Qt.CheckState.Unchecked
except AttributeError:
    _Unchecked = Qt.Unchecked

try:
    _UserRole = Qt.ItemDataRole.UserRole
except AttributeError:
    _UserRole = Qt.UserRole

try:
    _WindowModal = Qt.WindowModality.WindowModal
except AttributeError:
    _WindowModal = Qt.WindowModal

try:
    _AcceptRole = QDialogButtonBox.ButtonRole.AcceptRole
    _RejectRole = QDialogButtonBox.ButtonRole.RejectRole
except AttributeError:
    _AcceptRole = QDialogButtonBox.AcceptRole
    _RejectRole = QDialogButtonBox.RejectRole


class ExportPGtoGPKGDialog(QDialog):

    def __init__(self, iface=None, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.conn = None
        self.conn_params = None
        self._all_tables = {}
        self._worker = None
        self._progress = None

        self.setWindowTitle(self.tr("Export PostgreSQL → GeoPackage"))
        icon = QIcon(os.path.join(
            os.path.dirname(__file__), "icons", "pg2gpkg.png"))
        if not icon.isNull():
            self.setWindowIcon(icon)
        self.setMinimumWidth(720)
        self.setMinimumHeight(680)
        self._setup_ui()

    def tr(self, message):
        return QCoreApplication.translate("PG2GPKG", message)

    # ================================================================
    # UI setup
    # ================================================================

    def _setup_ui(self):
        layout = QVBoxLayout()
        self.setLayout(layout)

        # ── Connection (collapsible / accordion) ──────────────────
        cg = _CollapsibleGroupBox(self.tr("PostgreSQL Connection"))
        self.conn_group = cg
        cl = QFormLayout()
        cg.setLayout(cl)

        self.conn_combo = QComboBox()
        self.connections = get_pg_connections()
        for name in sorted(self.connections.keys()):
            db = self.connections[name].get("database", "")
            self.conn_combo.addItem(f"{name} ({db})", name)
        cl.addRow(self.tr("Connection:"), self.conn_combo)

        self.host_edit = QLineEdit("localhost")
        self.port_edit = QLineEdit("5432")
        self.db_edit = QLineEdit()
        self.user_edit = QLineEdit()
        self.pass_edit = QLineEdit()
        self.pass_edit.setEchoMode(_EchoPassword)

        self.use_manual = QCheckBox(self.tr("Use manual parameters"))
        self.use_manual.toggled.connect(self._toggle_manual)
        cl.addRow(self.use_manual)
        cl.addRow(self.tr("Host:"), self.host_edit)
        cl.addRow(self.tr("Port:"), self.port_edit)
        cl.addRow(self.tr("Database:"), self.db_edit)
        cl.addRow(self.tr("User:"), self.user_edit)
        cl.addRow(self.tr("Password:"), self.pass_edit)
        for w in (self.host_edit, self.port_edit, self.db_edit,
                  self.user_edit, self.pass_edit):
            w.setEnabled(False)

        btn_connect = QPushButton(self.tr("Connect and load schemas/tables"))
        btn_connect.clicked.connect(self._load_all)
        cl.addRow(btn_connect)
        layout.addWidget(cg)
        # Start collapsed to keep the dialog compact; the user expands it only
        # to connect, and it re-collapses automatically afterwards.
        if hasattr(cg, "setCollapsed"):
            cg.setCollapsed(True)

        # ── Table tree ────────────────────────────────────────────
        tg = QGroupBox(self.tr("Schemas and tables"))
        tl = QVBoxLayout()
        tg.setLayout(tl)

        self.table_tree = QTreeWidget()
        self.table_tree.setHeaderLabels([
            self.tr("Name"), self.tr("Type"),
            self.tr("Geometry"), self.tr("SRID"),
        ])
        self.table_tree.header().setSectionResizeMode(0, _HdrStretch)
        for col in (1, 2, 3):
            self.table_tree.header().setSectionResizeMode(col, _HdrResizeToContents)
        self.table_tree.setSelectionMode(_NoSelection)
        tl.addWidget(self.table_tree)

        br = QHBoxLayout()
        for label, fn in [
            (self.tr("Select all"), lambda: self._set_all_check(True)),
            (self.tr("Deselect all"), lambda: self._set_all_check(False)),
            (self.tr("Spatial only"), self._check_spatial_only),
        ]:
            b = QPushButton(label)
            b.clicked.connect(fn)
            br.addWidget(b)
        tl.addLayout(br)
        layout.addWidget(tg)

        # ── Export mode ───────────────────────────────────────────
        mg = QGroupBox(self.tr("GeoPackage mode"))
        ml = QVBoxLayout()
        mg.setLayout(ml)

        self.mode_per_schema = QRadioButton(
            self.tr("One GeoPackage per schema  (output/schema.gpkg)"))
        self.mode_single = QRadioButton(
            self.tr("Everything in a single GeoPackage"))
        self.mode_per_table = QRadioButton(
            self.tr("One GeoPackage per table  (output/schema/table.gpkg)"))
        self.mode_single.setChecked(True)

        self.gpkg_mode = QButtonGroup(self)
        self.gpkg_mode.addButton(self.mode_per_schema, 0)
        self.gpkg_mode.addButton(self.mode_single, 1)
        self.gpkg_mode.addButton(self.mode_per_table, 2)

        ml.addWidget(self.mode_per_schema)

        sr = QHBoxLayout()
        sr.addWidget(self.mode_single)
        self.single_name = QLineEdit()
        self.single_name.setPlaceholderText(self.tr("filename.gpkg"))
        self.single_name.setEnabled(True)
        sr.addWidget(self.single_name)
        ml.addLayout(sr)

        ml.addWidget(self.mode_per_table)
        self.mode_single.toggled.connect(self.single_name.setEnabled)
        layout.addWidget(mg)

        # ── Options ───────────────────────────────────────────────
        og = QGroupBox(self.tr("Options"))
        ol = QVBoxLayout()
        og.setLayout(ol)

        self.cb_projects = QCheckBox(
            self.tr("Export QGIS projects from DB as .qgz files "
                    "(paths relinked to the GeoPackage layers)"))
        self.cb_projects.setChecked(True)
        self.cb_projects.setToolTip(self.tr(
            "Each selected project is saved as a .qgz file in the output "
            "folder, with layer paths pointing to the exported GeoPackage. "
            "Keep the .qgz and the .gpkg in the same folder to stay portable."))
        ol.addWidget(self.cb_projects)

        self.cb_embed_external = QCheckBox(
            self.tr("Copy external vector layers into the GeoPackage; "
                    "make other file paths (rasters) relative"))
        self.cb_embed_external.setChecked(True)
        self.cb_embed_external.setToolTip(self.tr(
            "Project layers linked from disk are handled too: external vector "
            "files of any format (shapefile, GeoPackage, GeoJSON, DXF, CSV/DBF "
            "and other attribute-only tables, etc.) are copied into the single "
            "GeoPackage as new layers — styles, widgets and relations are kept "
            "— and their links are updated. Rasters and other files are not "
            "copied but their paths are made relative to the output folder "
            "when on the same drive."))
        ol.addWidget(self.cb_embed_external)
        self.cb_projects.toggled.connect(self.cb_embed_external.setEnabled)

        self.cb_export_rasters = QCheckBox(
            self.tr("Also export raster layers as compressed GeoTIFFs in the "
                    "output folder (relinked with relative paths)"))
        self.cb_export_rasters.setChecked(False)
        self.cb_export_rasters.setToolTip(self.tr(
            "External raster layers (GeoTIFF, JPEG, ...) referenced by the "
            "project are converted to compressed GeoTIFF files saved next to "
            "the GeoPackage, and the project is relinked to them with relative "
            "paths. Rasters are NOT put inside the GeoPackage. Georeferencing "
            "is preserved when present."))
        ol.addWidget(self.cb_export_rasters)
        self.cb_projects.toggled.connect(self.cb_export_rasters.setEnabled)

        self.cb_organize = QCheckBox(
            self.tr("Organize output into Vector/ and Raster/ subfolders "
                    "(project stays in the root)"))
        self.cb_organize.setChecked(False)
        self.cb_organize.setToolTip(self.tr(
            "When enabled, GeoPackages go into a 'Vector' subfolder and "
            "exported rasters into a 'Raster' subfolder of the destination, "
            "while the project file stays loose in the destination root. All "
            "links in the project are updated to this structure."))
        ol.addWidget(self.cb_organize)
        layout.addWidget(og)

        # ── Output ────────────────────────────────────────────────
        orow = QHBoxLayout()
        self.output_edit = QLineEdit()
        self.output_edit.setPlaceholderText(self.tr("Select output folder..."))
        btn_browse = QPushButton(self.tr("Browse..."))
        btn_browse.clicked.connect(self._browse)
        orow.addWidget(QLabel(self.tr("Output:")))
        orow.addWidget(self.output_edit)
        orow.addWidget(btn_browse)
        layout.addLayout(orow)

        # ── Buttons ───────────────────────────────────────────────
        bb = QDialogButtonBox()
        self.btn_export = QPushButton(self.tr("Export"))
        self.btn_export.clicked.connect(self._run_export)
        self.btn_export.setEnabled(False)
        btn_close = QPushButton(self.tr("Close"))
        btn_close.clicked.connect(self.reject)
        bb.addButton(self.btn_export, _AcceptRole)
        bb.addButton(btn_close, _RejectRole)
        layout.addWidget(bb)

        self.status_label = QLabel("")
        layout.addWidget(self.status_label)

    # ================================================================
    # UI helpers
    # ================================================================

    def _toggle_manual(self, on):
        for w in (self.host_edit, self.port_edit, self.db_edit,
                  self.user_edit, self.pass_edit):
            w.setEnabled(on)
        self.conn_combo.setEnabled(not on)

    def _conn_params(self):
        if self.use_manual.isChecked():
            return {
                "host": self.host_edit.text(), "port": self.port_edit.text(),
                "database": self.db_edit.text(), "username": self.user_edit.text(),
                "password": self.pass_edit.text(), "sslmode": "prefer",
            }
        name = self.conn_combo.currentData()
        return self.connections.get(name) if name else None

    def _browse(self):
        f = QFileDialog.getExistingDirectory(self, self.tr("Select output folder"))
        if f:
            self.output_edit.setText(f)

    def closeEvent(self, event):
        """Ensure background worker and DB connection are cleaned up."""
        if self._worker and self._worker.isRunning():
            self._worker.request_cancel()
            self._worker.wait()
        if self.conn:
            try:
                self.conn.close()
            except Exception:
                pass
            self.conn = None
        super().closeEvent(event)

    # ================================================================
    # Load schemas/tables
    # ================================================================

    def _load_all(self):
        if not HAS_PSYCOPG2:
            QMessageBox.critical(self, self.tr("Missing dependency"),
                self.tr("The 'psycopg2' module is not installed.\n\n"
                         "Install it with: pip install psycopg2-binary"))
            return

        self.table_tree.clear()
        self._all_tables = {}
        params = self._conn_params()
        if not params:
            QMessageBox.warning(self, self.tr("Error"),
                                self.tr("No connection selected."))
            return

        params = resolve_auth_params(params)

        try:
            if self.conn:
                try:
                    self.conn.close()
                except Exception:
                    pass
            self.conn = pg_connect(params)
            self.conn_params = params
        except Exception as e:
            QMessageBox.critical(self, self.tr("Connection error"), str(e))
            return

        schemas = get_schemas(self.conn)
        n = 0
        for schema in schemas:
            tables = get_tables_and_views(self.conn, schema)
            if not tables:
                continue
            self._all_tables[schema] = tables

            si = QTreeWidgetItem([schema, "", "", ""])
            si.setFlags(si.flags() | _ItemIsUserCheckable | _ItemIsAutoTristate)
            si.setCheckState(0, _Checked)

            for t in tables:
                geom = t["geom_type"] or "—"
                srid = str(t["srid"]) if (t["geom_column"] or
                                          t.get("is_raster")) else "—"
                if t.get("is_raster"):
                    ttype = self.tr("Raster")
                    rc = t.get("raster_column")
                    if rc:
                        ttype += f"  [{rc}]"
                    nb = t.get("num_bands")
                    if nb:
                        geom = f"RASTER ({nb} band)"
                else:
                    ttype = self.tr("View") if "VIEW" in (t["table_type"] or "") \
                        else self.tr("Table")
                    if t["geom_column"]:
                        ttype += f"  [{t['geom_column']}]"

                ci = QTreeWidgetItem([t["table"], ttype, geom, srid])
                ci.setFlags(ci.flags() | _ItemIsUserCheckable)
                ci.setCheckState(0, _Checked)
                ci.setData(0, _UserRole, t)
                ci.setData(0, _UserRole + 1, schema)
                si.addChild(ci)
                n += 1

            self.table_tree.addTopLevelItem(si)

        self.table_tree.expandAll()
        self.btn_export.setEnabled(True)

        # Show the connected database in the group title and collapse it again
        # to reclaim vertical space now that the connection is established.
        self.conn_group.setTitle(
            self.tr("PostgreSQL Connection — {db}").format(db=params["database"]))
        if hasattr(self.conn_group, "setCollapsed"):
            self.conn_group.setCollapsed(True)

        self.status_label.setText(
            self.tr("{count} tables/views in {schemas} schemas — {db}").format(
                count=n, schemas=len(self._all_tables),
                db=params["database"]))

    def _set_all_check(self, on):
        st = _Checked if on else _Unchecked
        for i in range(self.table_tree.topLevelItemCount()):
            self.table_tree.topLevelItem(i).setCheckState(0, st)

    def _check_spatial_only(self):
        for i in range(self.table_tree.topLevelItemCount()):
            si = self.table_tree.topLevelItem(i)
            for j in range(si.childCount()):
                ci = si.child(j)
                info = ci.data(0, _UserRole)
                ci.setCheckState(
                    0, _Checked if info and (info.get("geom_column") or
                                             info.get("is_raster"))
                    else _Unchecked)

    def _selected_tables(self):
        """Return {schema: [table_info, ...]} for checked items."""
        result = {}
        for i in range(self.table_tree.topLevelItemCount()):
            si = self.table_tree.topLevelItem(i)
            for j in range(si.childCount()):
                ci = si.child(j)
                if ci.checkState(0) == _Checked:
                    info = ci.data(0, _UserRole)
                    schema = ci.data(0, _UserRole + 1)
                    if schema and info:
                        result.setdefault(schema, []).append(info)
        return result

    # ================================================================
    # Export
    # ================================================================

    def _choose_projects(self, names):
        """Show a checkable list of project names found in the DB.
        Returns the list of selected names, or None if the user cancels.
        Pre-selects a project whose name matches the single-GPKG filename or
        the current QGIS project, otherwise selects all."""
        dlg = QDialog(self)
        dlg.setWindowTitle(self.tr("Select projects to export"))
        lay = QVBoxLayout(dlg)
        lay.addWidget(QLabel(self.tr(
            "Multiple QGIS projects were found in the database.\n"
            "Choose which one(s) to embed in the GeoPackage:")))

        tree = QTreeWidget()
        tree.setHeaderHidden(True)
        tree.setSelectionMode(QAbstractItemView.NoSelection)
        items = []
        for n in names:
            it = QTreeWidgetItem([n])
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(0, Qt.Unchecked)
            tree.addTopLevelItem(it)
            items.append(it)
        lay.addWidget(tree)

        # Pre-selection heuristic: match the single-GPKG filename if any
        preferred = None
        gn = self.single_name.text().strip()
        if gn:
            base = os.path.splitext(os.path.basename(gn))[0].lower()
            for it in items:
                if it.text(0).lower() == base:
                    preferred = it
                    break
        if preferred is not None:
            preferred.setCheckState(0, Qt.Checked)
        else:
            for it in items:
                it.setCheckState(0, Qt.Checked)

        bb = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        lay.addWidget(bb)

        if dlg.exec_() != QDialog.Accepted:
            return None
        chosen = [it.text(0) for it in items
                  if it.checkState(0) == Qt.Checked]
        return chosen

    def _run_export(self):
        output_dir = self.output_edit.text()
        if not output_dir or not os.path.isdir(output_dir):
            QMessageBox.warning(self, self.tr("Error"),
                                self.tr("Select a valid output folder."))
            return

        selected = self._selected_tables()
        if not selected:
            QMessageBox.warning(self, self.tr("Error"),
                                self.tr("Select at least one table."))
            return

        if not self.conn_params:
            QMessageBox.warning(self, self.tr("Error"),
                                self.tr("Connect to database first."))
            return

        mode = self.gpkg_mode.checkedId()  # 0=per-schema 1=single 2=per-table

        single_path = None
        if mode == 1:
            gn = self.single_name.text().strip()
            if not gn:
                gn = f"{self.conn_params['database']}.gpkg"
            if not gn.lower().endswith(".gpkg"):
                gn += ".gpkg"
            single_path = os.path.join(output_dir, gn)

        do_projects = self.cb_projects.isChecked()
        total = sum(len(v) for v in selected.values())

        # If projects are requested and the DB holds more than one, let the
        # user pick which ones to embed (avoids exporting unwanted duplicates).
        project_filter = None
        if do_projects:
            try:
                conn = pg_connect(self.conn_params)
                try:
                    found = get_qgis_projects_in_db(conn)
                finally:
                    conn.close()
            except Exception as e:
                found = []
                QgsMessageLog.logMessage(
                    f"Could not list projects: {e}", LOG_TAG, Qgis.Warning)

            names = [p["name"] for p in found]
            if len(names) > 1:
                chosen = self._choose_projects(names)
                if chosen is None:        # user cancelled the whole export
                    return
                project_filter = chosen

        # Get transform context from main thread (thread-safe copy)
        transform_context = QgsProject.instance().transformContext()

        # Save last output directory
        QSettings().setValue("PG2GPKG/lastOutputDir", output_dir)

        # Progress dialog
        self._progress = QProgressDialog(
            self.tr("Exporting..."), self.tr("Cancel"), 0, total + 1, self)
        self._progress.setWindowTitle(self.tr("Export PostgreSQL → GeoPackage"))
        self._progress.setWindowModality(_WindowModal)
        self._progress.setMinimumDuration(0)
        self._progress.show()

        # Create worker thread
        self._worker = ExportWorker(
            conn_params=self.conn_params,
            selected=selected,
            mode=mode,
            output_dir=output_dir,
            single_path=single_path,
            do_projects=do_projects,
            transform_context=transform_context,
            project_filter=project_filter,
            embed_external_vectors=self.cb_embed_external.isChecked(),
            export_rasters=self.cb_export_rasters.isChecked(),
            organize_subfolders=self.cb_organize.isChecked(),
        )
        self._worker.progress_updated.connect(self._on_progress)
        self._worker.export_finished.connect(self._on_export_finished)
        self._progress.canceled.connect(self._worker.request_cancel)

        # Disable UI during export
        self.btn_export.setEnabled(False)

        self._worker.start()

    def _on_progress(self, step, total, label):
        if self._progress:
            self._progress.setValue(step)
            self._progress.setLabelText(f"{label}  ({step}/{total})")

    def _on_export_finished(self, results):
        if self._progress:
            self._progress.close()
            self._progress = None

        self.btn_export.setEnabled(True)

        # Properly tear down the worker thread. The export_finished signal is
        # emitted from inside the thread's run(); clearing the only reference
        # here (while the QThread hasn't fully finished) can destroy it while
        # still running and crash QGIS. Quit + wait + deleteLater is the safe
        # sequence, deferred so we don't block the slot that the thread itself
        # is still emitting from.
        w = self._worker
        self._worker = None
        if w is not None:
            try:
                w.export_finished.disconnect()
                w.progress_updated.disconnect()
            except (TypeError, RuntimeError):
                pass
            w.quit()
            w.wait()
            w.deleteLater()

        mode = results["mode"]
        ok_count = results["ok_count"]
        total = results["total"]
        gpkg_count = results["gpkg_count"]
        errors = results["errors"]
        exported_proj = results["exported_projects"]

        mode_labels = {
            0: self.tr("one GeoPackage per schema"),
            1: self.tr("single GeoPackage"),
            2: self.tr("one GeoPackage per table"),
        }

        if results.get("cancelled"):
            s = self.tr("Export cancelled.\n\n")
        else:
            s = ""

        s += self.tr("Export completed! ({mode})\n\n"
                     "Layers exported: {ok}/{total}\n"
                     "GeoPackages created: {gpkg}\n").format(
            mode=mode_labels[mode], ok=ok_count, total=total, gpkg=gpkg_count)

        if exported_proj:
            s += self.tr("\nQGIS projects (.qgz in the output folder): "
                         "{count}\n").format(count=len(exported_proj))
            for p in exported_proj:
                s += f"  • {p}\n"
            s += self.tr("Keep each .qgz together with the GeoPackage(s) "
                         "in the same folder.\n")

        if errors:
            s += self.tr("\nErrors ({count}):\n").format(count=len(errors))
            for e in errors[:25]:
                s += f"  • {e}\n"
            if len(errors) > 25:
                s += self.tr("  … and {n} more (see log)\n").format(n=len(errors) - 25)

        QMessageBox.information(self, self.tr("Result"), s)
        self.status_label.setText(
            self.tr("Completed: {ok} layers, {err} errors").format(
                ok=ok_count, err=len(errors)))
