"""
PG2GPKG - Export engine
Copyright (C) 2025 Federico Gianoli — GPLv3
"""

import os
import re
import io
import sys
import json
import shutil
import sqlite3
import zipfile
import subprocess
from datetime import datetime

try:
    from defusedxml import ElementTree as ET
except ImportError:
    # defusedxml not available; stdlib is safe here since input is local QGIS project files
    import xml.etree.ElementTree as ET  # nosec B314

from qgis.core import (
    QgsDataSourceUri,
    QgsVectorLayer,
    QgsVectorFileWriter,
    QgsProject,
    QgsCoordinateTransformContext,
    QgsMessageLog,
    Qgis,
)
from qgis.PyQt.QtCore import QThread, QVariant, pyqtSignal

from .db_utils import normalize_sslmode, pg_connect, get_qgis_projects_in_db

LOG_TAG = "PG2GPKG"

# ── Qt6 scoped-enum compatibility (QVariant type constants) ───────────
try:
    _QVariant_Int = QVariant.Int
except AttributeError:
    from qgis.PyQt.QtCore import QMetaType
    _QVariant_Int = QMetaType.Type.Int

try:
    _QVariant_LongLong = QVariant.LongLong
except AttributeError:
    from qgis.PyQt.QtCore import QMetaType
    _QVariant_LongLong = QMetaType.Type.LongLong

try:
    _QVariant_UInt = QVariant.UInt
except AttributeError:
    from qgis.PyQt.QtCore import QMetaType
    _QVariant_UInt = QMetaType.Type.UInt

try:
    _QVariant_ULongLong = QVariant.ULongLong
except AttributeError:
    from qgis.PyQt.QtCore import QMetaType
    _QVariant_ULongLong = QMetaType.Type.ULongLong


def export_table_to_gpkg(conn_params, schema, table_info, gpkg_path,
                          layer_name_override=None, transform_context=None):
    """
    Export a single PostgreSQL table/view to a GeoPackage layer.

    :param conn_params: dict with host, port, database, username, password, sslmode
    :param schema: schema name
    :param table_info: dict with table, geom_column, geom_type, srid, table_type
    :param gpkg_path: output GeoPackage file path
    :param layer_name_override: optional layer name in the GPKG
    :param transform_context: QgsCoordinateTransformContext (pass from main thread)
    :returns: tuple (success: bool, message: str)
    """
    ssl_map = {
        "disable": 0, "allow": 1, "prefer": 2,
        "require": 3, "verify-ca": 4, "verify-full": 5,
    }
    uri = QgsDataSourceUri()
    uri.setConnection(
        conn_params["host"], str(conn_params["port"]), conn_params["database"],
        conn_params["username"], conn_params["password"],
        QgsDataSourceUri.SslMode(
            ssl_map.get(normalize_sslmode(conn_params.get("sslmode")), 2)),
    )

    table_name = table_info["table"]
    geom_column = table_info["geom_column"]

    if geom_column:
        uri.setDataSource(schema, table_name, geom_column)
    else:
        uri.setDataSource(schema, table_name, None)

    # Detect primary key
    try:
        c = pg_connect(conn_params)
        try:
            cur = c.cursor()
            cur.execute("""
                SELECT a.attname FROM pg_index i
                JOIN pg_attribute a ON a.attrelid=i.indrelid AND a.attnum=ANY(i.indkey)
                WHERE i.indrelid=%s::regclass AND i.indisprimary
            """, (f'"{schema}"."{table_name}"',))
            pk = cur.fetchone()
            if pk:
                uri.setKeyColumn(pk[0])
            cur.close()
        finally:
            c.close()
    except Exception:
        pass

    layer = QgsVectorLayer(uri.uri(False), table_name, "postgres")
    if not layer.isValid():
        return False, f"Invalid layer: {schema}.{table_name}"

    layer_name = layer_name_override or table_name

    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GPKG"
    options.layerName = layer_name
    options.fileEncoding = "UTF-8"

    # Handle fid field type conflict (GPKG requires integer fid)
    fidx = layer.fields().lookupField("fid")
    if fidx >= 0:
        ft = layer.fields().at(fidx).type()
        if ft not in (_QVariant_Int, _QVariant_LongLong, _QVariant_UInt, _QVariant_ULongLong):
            options.layerOptions = ["FID=gpkg_fid"]

    if os.path.exists(gpkg_path):
        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
    else:
        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile

    ctx = transform_context if transform_context is not None else QgsCoordinateTransformContext()
    err, msg, _, _ = QgsVectorFileWriter.writeAsVectorFormatV3(layer, gpkg_path, ctx, options)

    if err != QgsVectorFileWriter.NoError:
        return False, f"Export error {schema}.{table_name}: {msg}"
    return True, f"OK: {schema}.{table_name} → {layer_name}"


def _parse_pg_schema_table(ds):
    """Extract (schema, table) from a PostgreSQL/PostGISRaster datasource,
    handling the different ways QGIS writes them:
      • table="schema"."table"      (quoted, dotted — most common)
      • table='schema'.'table'
      • schema='schema' table='table'   (separate fields)
      • table="table"  with a separate schema="schema"
    Returns (schema, table) with either possibly None.
    """
    schema = None
    table = None
    # 1) dotted form: table="schema"."table"  or  table='schema'.'table'
    m = re.search(r'table\s*=\s*"([^"]+)"\s*\.\s*"([^"]+)"', ds)
    if not m:
        m = re.search(r"table\s*=\s*'([^']+)'\s*\.\s*'([^']+)'", ds)
    if m:
        return m.group(1), m.group(2)
    # 2) separate schema= field
    for pat in (r"schema\s*=\s*'([^']*)'", r'schema\s*=\s*"([^"]*)"'):
        mm = re.search(pat, ds)
        if mm:
            schema = mm.group(1)
            break
    # 3) table= field (quoted single/double, no dot)
    for pat in (r'table\s*=\s*"([^".]+)"', r"table\s*=\s*'([^'.]+)'"):
        mm = re.search(pat, ds)
        if mm:
            table = mm.group(1)
            break
    return schema, table


def _build_pg_raster_uri(conn_params, schema, table, raster_column):
    """Build a postgresraster datasource URI as a fallback when the project
    doesn't provide one. mode=2 merges tiles into one georeferenced raster."""
    parts = [f"PG: dbname='{conn_params.get('database', '')}'",
             f"host={conn_params.get('host', 'localhost')}",
             f"port={conn_params.get('port', 5432)}"]
    if conn_params.get("user"):
        parts.append(f"user='{conn_params['user']}'")
    if conn_params.get("password"):
        parts.append(f"password='{conn_params['password']}'")
    parts.append(f"schema='{schema}'")
    parts.append(f"table='{table}'")
    parts.append(f"column='{raster_column}'")
    parts.append("mode=2")
    return " ".join(parts)


def _collect_pg_raster_datasources(xml_content):
    """Return {(schema, table): datasource} for postgresraster layers in the
    project, so the raster can be loaded exactly as the project references it
    (preserving its on-map position)."""
    import xml.etree.ElementTree as ET
    out = {}
    try:
        root = ET.fromstring(xml_content)
    except Exception:
        return out
    for ml in root.iter("maplayer"):
        if ml.findtext("provider") != "postgresraster":
            continue
        ds = ml.findtext("datasource")
        if not ds:
            continue
        sch, tbl = _parse_pg_schema_table(ds)
        if sch and tbl:
            out[(sch, tbl)] = ds.strip()
    return out


def export_vector_file_to_gpkg(src_path, gpkg_path, layer_name,
                               transform_context=None, provider="ogr",
                               full_uri=None):
    """
    Copy an external file-based vector layer (shapefile, gpkg, geojson, dxf,
    csv, dbf, spatialite, ...) into a GeoPackage as a new layer. Used for
    project layers linked from disk rather than from PostgreSQL. Works for
    attribute-only tables too (written as aspatial GeoPackage tables).

    :param src_path: path to the source file (bare path, no OGR suffix)
    :param provider: source provider ('ogr', 'delimitedtext', 'spatialite')
    :param full_uri: optional full datasource URI to open the source layer
                     (needed for delimitedtext CSVs that carry options)
    :returns: (success: bool, message: str)
    """
    source = full_uri if full_uri else src_path
    layer = QgsVectorLayer(source, layer_name, provider)
    if not layer.isValid():
        # Fall back to plain OGR if the declared provider failed
        layer = QgsVectorLayer(src_path, layer_name, "ogr")
        if not layer.isValid():
            return False, f"Invalid external layer: {src_path}"

    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GPKG"
    options.layerName = layer_name
    options.fileEncoding = "UTF-8"

    fidx = layer.fields().lookupField("fid")
    if fidx >= 0:
        ft = layer.fields().at(fidx).type()
        if ft not in (_QVariant_Int, _QVariant_LongLong,
                      _QVariant_UInt, _QVariant_ULongLong):
            options.layerOptions = ["FID=gpkg_fid"]

    if os.path.exists(gpkg_path):
        options.actionOnExistingFile = \
            QgsVectorFileWriter.CreateOrOverwriteLayer
    else:
        options.actionOnExistingFile = \
            QgsVectorFileWriter.CreateOrOverwriteFile

    ctx = transform_context if transform_context is not None else QgsCoordinateTransformContext()
    err, msg, _, _ = QgsVectorFileWriter.writeAsVectorFormatV3(
        layer, gpkg_path, ctx, options)
    if err != QgsVectorFileWriter.NoError:
        return False, f"Export error {src_path}: {msg}"
    return True, f"OK: {os.path.basename(src_path)} → {layer_name}"


def collect_external_vector_layers(xml_content, skip_paths=None):
    """
    Scan a project XML and return the distinct external vector files it
    references — any OGR/file-based vector source linked from disk, not just
    shapefiles: GeoPackage, GeoJSON, KML, GML, MapInfo, SpatiaLite, DXF/DWG,
    FlatGeobuf, GeoParquet, CSV/DBF and other attribute-only tables, etc.
    Rasters (provider 'gdal'/'wms') are intentionally excluded — handled
    separately as relative paths.

    A layer qualifies when its provider is file-based vector (ogr,
    delimitedtext, spatialite) and its datasource points to a real local file.
    Attribute-only tables (no geometry) are included: they are copied into the
    GeoPackage as aspatial tables.

    :param skip_paths: iterable of file paths to ignore (e.g. the output gpkg)
    :returns: dict normalised-key -> {"path", "ext", "basename", "provider"}
    """
    import xml.etree.ElementTree as ET
    try:
        root = ET.fromstring(xml_content)
    except Exception:
        return {}

    FILE_VECTOR_PROVIDERS = ("ogr", "delimitedtext", "spatialite")
    skip = {_norm_file_key(p) for p in (skip_paths or [])}

    found = {}
    for ml in root.iter("maplayer"):
        # Only vector layers; rasters are handled elsewhere.
        if (ml.get("type") or "vector") != "vector":
            continue
        prov = ml.findtext("provider")
        ds = ml.findtext("datasource")
        if not ds or prov not in FILE_VECTOR_PROVIDERS:
            continue

        file_path = _datasource_file_path(ds, prov)
        if not file_path:
            continue
        # Must look like a real local file path (has an extension, not a URL
        # to a service). Relative or absolute both fine.
        ext = os.path.splitext(file_path)[1].lower()
        if not ext:
            continue
        key = _norm_file_key(file_path)
        if key in skip:
            continue
        if key not in found:
            entry = {"path": file_path, "ext": ext,
                     "basename": os.path.basename(file_path),
                     "provider": prov}
            if prov == "delimitedtext":
                entry["full_uri"] = ds.strip()
            found[key] = entry
    return found


def collect_external_raster_layers(xml_content, skip_paths=None):
    """
    Scan a project XML and return the distinct external raster files it
    references (provider 'gdal' pointing to a local file). WMS/WMTS and other
    service rasters are excluded.

    :returns: dict normalised-key -> {"path", "ext", "basename"}
    """
    import xml.etree.ElementTree as ET
    try:
        root = ET.fromstring(xml_content)
    except Exception:
        return {}

    skip = {_norm_file_key(p) for p in (skip_paths or [])}
    found = {}
    for ml in root.iter("maplayer"):
        if (ml.get("type") or "") != "raster":
            continue
        prov = ml.findtext("provider")
        ds = ml.findtext("datasource")
        if not ds or prov != "gdal":
            continue
        file_path = ds.split("|", 1)[0].strip()
        # Skip URLs / service sources
        if "://" in file_path and not file_path.lower().startswith("file:"):
            continue
        if file_path.lower().startswith("file:"):
            file_path = re.sub(r"^file://", "", file_path)
            if re.match(r"/[A-Za-z]:", file_path):
                file_path = file_path[1:]
        ext = os.path.splitext(file_path)[1].lower()
        if not ext:
            continue
        key = _norm_file_key(file_path)
        if key in skip:
            continue
        if key not in found:
            found[key] = {"path": file_path, "ext": ext,
                          "basename": os.path.basename(file_path)}
    return found


def _find_gdal_translate():
    """Locate the gdal_translate executable. In OSGeo4W/QGIS it sits next to
    the QGIS binaries; fall back to PATH."""
    candidates = []
    exe = "gdal_translate.exe" if os.name == "nt" else "gdal_translate"
    # 1) same bin folder as the running Python/QGIS
    py_dir = os.path.dirname(sys.executable or "")
    if py_dir:
        candidates.append(os.path.join(py_dir, exe))
    # 2) QGIS prefix (…/apps/qgis/bin or …/bin) via env
    for var in ("OSGEO4W_ROOT", "QGIS_PREFIX_PATH"):
        root = os.environ.get(var)
        if root:
            candidates.append(os.path.join(root, "bin", exe))
            candidates.append(os.path.join(root, exe))
    # 3) anything on PATH
    found = shutil.which(exe)
    if found:
        candidates.append(found)
    for c in candidates:
        if c and os.path.isfile(c):
            return c
    return found or exe  # last resort: rely on PATH at call time


def export_pg_raster_via_subprocess(conn_params, schema, table,
                                    raster_column, dst_path, compress="LZW"):
    """
    Export a PostGIS Raster table to a GeoTIFF by running gdal_translate as a
    SEPARATE PROCESS. This isolates the fragile PostGISRaster driver from QGIS:
    if it crashes, only the subprocess dies and we report an error — QGIS stays
    alive. The subprocess also avoids any thread-safety issues with libpq.

    :returns: (success: bool, message: str)
    """
    name = os.path.basename(dst_path)
    # Build the connection WITHOUT the password (passed via PGPASSWORD env), so
    # it never lands in the command line / process list.
    cp_no_pw = dict(conn_params)
    cp_no_pw.pop("password", None)
    src = _build_pg_raster_uri(cp_no_pw, schema, table, raster_column)

    gdal_translate = _find_gdal_translate()
    cmd = [gdal_translate, "-of", "GTiff",
           "-co", f"COMPRESS={compress}", "-co", "TILED=YES",
           "-co", "BIGTIFF=IF_SAFER",
           src, dst_path]

    # Pass the DB password via environment (PGPASSWORD) so it never appears in
    # the command line / process list.
    env = dict(os.environ)
    if conn_params.get("password"):
        env["PGPASSWORD"] = conn_params["password"]

    try:
        # Hide the console window on Windows.
        creationflags = 0
        if os.name == "nt":
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        proc = subprocess.run(
            cmd, env=env, capture_output=True, text=True,
            timeout=1800, creationflags=creationflags)
    except FileNotFoundError:
        return False, (f"gdal_translate not found for {schema}.{table}; "
                       f"cannot export DB raster")
    except subprocess.TimeoutExpired:
        return False, f"Timeout exporting raster {schema}.{table}"
    except Exception as e:
        return False, f"Raster subprocess error {schema}.{table}: {e}"

    if proc.returncode != 0:
        # Crash or driver error in the subprocess — QGIS itself is unaffected.
        err = (proc.stderr or "").strip().splitlines()
        tail = err[-1] if err else f"exit code {proc.returncode}"
        # Clean up a possibly half-written file
        try:
            if os.path.exists(dst_path):
                os.remove(dst_path)
        except OSError:
            pass
        return False, f"Raster export failed {schema}.{table}: {tail}"

    if not os.path.exists(dst_path):
        return False, f"Raster export produced no file: {schema}.{table}"
    return True, f"OK raster (georeferenced): {schema}.{table} → {name}"


def export_raster_layer_to_geotiff(datasource, provider, dst_path,
                                   compress="LZW"):
    """
    Export a raster to a compressed GeoTIFF, preserving its georeferencing.

    IMPORTANT: this runs inside a background QThread. QGIS layer/raster classes
    (QgsRasterLayer, QgsRasterPipe, QgsRasterFileWriter) are NOT safe to use off
    the main thread and crash QGIS if called here. We therefore use plain GDAL
    (osgeo.gdal), which is thread-safe, to read the source and write the GeoTIFF
    — georeferencing (CRS + geotransform, including world files) is carried over
    faithfully by GDAL.

    :param datasource: the layer datasource string (file path, or a
                       'PG:...' connection for postgresraster)
    :param provider: provider key ('gdal', 'postgresraster', ...)
    :returns: (success: bool, message: str)
    """
    name = os.path.basename(dst_path)
    try:
        from osgeo import gdal
    except ImportError:
        return False, "GDAL Python bindings not available for raster export"
    gdal.UseExceptions()

    # Translate a QGIS datasource into something gdal.Open understands.
    if provider == "postgresraster":
        gdal_src = _pg_raster_ds_to_gdal(datasource)
    else:
        # ogr/gdal file datasource: strip any '|' suffix
        gdal_src = datasource.split("|", 1)[0].strip()
        if gdal_src.lower().startswith("file://"):
            gdal_src = re.sub(r"^file://", "", gdal_src)
            if re.match(r"/[A-Za-z]:", gdal_src):
                gdal_src = gdal_src[1:]

    src_ds = None
    try:
        src_ds = gdal.Open(gdal_src, gdal.GA_ReadOnly)
    except Exception as e:
        return False, f"Cannot open raster {name}: {e}"
    if src_ds is None:
        return False, f"Cannot open raster: {gdal_src[:80]}"

    if src_ds.RasterXSize <= 0 or src_ds.RasterYSize <= 0:
        src_ds = None
        return False, f"Raster has no native resolution, skipped: {name}"

    src_gt = src_ds.GetGeoTransform(can_return_null=True)
    src_proj = src_ds.GetProjection()

    creation = [f"COMPRESS={compress}", "TILED=YES", "BIGTIFF=IF_SAFER"]
    try:
        opts = gdal.TranslateOptions(format="GTiff", creationOptions=creation)
        out_ds = gdal.Translate(dst_path, src_ds, options=opts)
        if out_ds is None:
            return False, f"Raster export failed: {name}"
        out_gt = out_ds.GetGeoTransform(can_return_null=True)
        out_proj = out_ds.GetProjection()
        out_ds.FlushCache()
        out_ds = None

        has_gt = out_gt is not None and out_gt != (0.0, 1.0, 0.0, 0.0, 0.0, 1.0)
        has_crs = bool(out_proj)
        if (src_gt or src_proj) and not (has_gt or has_crs):
            return True, f"WARNING (georeference may be lost): {name}"
        if has_gt and has_crs:
            return True, f"OK (georeferenced): {name}"
        if has_gt and not has_crs:
            return True, f"OK (georeferenced, no CRS): {name}"
        return True, f"OK (no georeference in source): {name}"
    except Exception as e:
        return False, f"Raster export error {name}: {e}"
    finally:
        src_ds = None


def _pg_raster_ds_to_gdal(datasource):
    """Convert a QGIS 'postgresraster' datasource into a GDAL PostGISRaster
    connection string. QGIS uses a 'PG: ...' form already; ensure mode=2 so the
    whole table is read as one georeferenced raster (tiles merged)."""
    ds = datasource.strip()
    # QGIS postgresraster datasources typically already start with "PG:".
    if not ds.upper().startswith("PG:"):
        ds = "PG: " + ds
    if "mode=" not in ds:
        ds = ds + " mode=2"
    return ds


def _datasource_file_path(ds_text, provider):
    """Extract the local file path from a datasource string, handling the
    different syntaxes:
      • ogr/spatialite:  /path/file.shp|layername=...|subset=...
      • delimitedtext:   file:///path/file.csv?delimiter=,&...
    Returns the bare file path, or None if it isn't a local file."""
    raw = ds_text.strip()
    if provider == "delimitedtext":
        # file:///C:/dir/x.csv?delimiter=... or file:///home/.../x.csv?...
        m = re.match(r"file://(/?[^?]+)", raw)
        if not m:
            return None
        p = m.group(1)
        # On Windows the path comes as /C:/...; strip the leading slash there
        if re.match(r"/[A-Za-z]:", p):
            p = p[1:]
        from urllib.parse import unquote
        return unquote(p)
    # ogr / spatialite: path is everything before the first '|'
    return raw.split("|", 1)[0].strip()

def serialize_qgis_project(root):
    """Serialize a project element tree restoring the standard QGIS DOCTYPE
    (ElementTree drops it)."""
    import xml.etree.ElementTree as ET
    out = ET.tostring(root, encoding="unicode", xml_declaration=True)
    if "<!DOCTYPE" not in out:
        nl = out.find("\n")
        doctype = "<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>"
        if nl >= 0 and out[:nl].lstrip().startswith("<?xml"):
            out = out[:nl + 1] + doctype + "\n" + out[nl + 1:]
        else:
            out = doctype + "\n" + out
    return out


def _norm_file_key(path):
    """Normalise a file path so it can be matched regardless of slashes/case
    (Windows is case-insensitive). Strips any OGR suffix after '|'."""
    p = path.split("|", 1)[0].strip()
    p = p.replace("\\", "/")
    return os.path.normcase(os.path.normpath(p))


def _split_ds_suffix(ds_text):
    """Split an OGR datasource into (file_path, suffix) where suffix is the
    part starting at the first '|' (e.g. '|layername=x|subset=...'),
    or '' if none."""
    i = ds_text.find("|")
    if i < 0:
        return ds_text, ""
    return ds_text[:i], ds_text[i:]


def _extract_subset(suffix):
    """Pull the |subset=... value (if any) out of an OGR datasource suffix."""
    m = re.search(r"\|subset=(.*)$", suffix, re.DOTALL)
    return m.group(1) if m else None


def _rewrite_external_datasource(layer_elem, prov, ds, ext_lookup, base_dir,
                                 relink_file_paths, rewritten_ids,
                                 raster_lookup=None):
    """
    Handle a non-PostgreSQL (file-based) layer datasource.

    Returns:
      "gpkg"     if redirected to a layer copied into the GeoPackage,
      "relinked" if the file path was rewritten relative to base_dir,
      None       if left untouched.
    """
    raster_lookup = raster_lookup or {}
    ds_text = ds.text
    provider = prov.text or "ogr"
    # Bare file path (handles ogr '|' suffix and delimitedtext file:// URI)
    file_path = _datasource_file_path(ds_text, provider)
    if not file_path:
        return None
    _, suffix = _split_ds_suffix(ds_text)
    if provider == "delimitedtext":
        suffix = ""   # delimitedtext options don't apply to the gpkg layer
    key = _norm_file_key(file_path)

    # Case 0: this raster was exported as a new GeoTIFF in the output folder
    if provider == "gdal" and key in raster_lookup:
        new_path = raster_lookup[key]
        if base_dir:
            rel = os.path.relpath(new_path, base_dir).replace(os.sep, "/")
            new_path = rel if rel.startswith(".") else f"./{rel}"
        else:
            new_path = new_path.replace(os.sep, "/")
        ds.text = new_path
        lid = layer_elem.findtext("id")
        if lid:
            rewritten_ids[lid] = ds.text
        QgsMessageLog.logMessage(
            f"Rewrite (raster→file): {os.path.basename(file_path)} "
            f"→ {ds.text}", LOG_TAG, Qgis.Info)
        return "relinked"

    # Case 1: this source file was copied into the gpkg -> redirect
    entry = ext_lookup.get(key)
    if entry:
        gpkg_path, layer_name = entry
        if base_dir:
            rel = os.path.relpath(gpkg_path, base_dir).replace(os.sep, "/")
            ds_path = rel if rel.startswith(".") else f"./{rel}"
        else:
            ds_path = gpkg_path.replace(os.sep, "/")
        new_ds = f"{ds_path}|layername={layer_name}"
        subset = _extract_subset(suffix)
        if subset:
            new_ds += f"|subset={subset}"
        ds.text = new_ds
        prov.text = "ogr"
        lid = layer_elem.findtext("id")
        if lid:
            rewritten_ids[lid] = new_ds
        QgsMessageLog.logMessage(
            f"Rewrite (external→gpkg): {os.path.basename(file_path)} "
            f"→ {new_ds}", LOG_TAG, Qgis.Info)
        return "gpkg"

    # Case 2: make the file path relative to the output folder (portable).
    # Only for plain file datasources (not delimitedtext URIs).
    if provider != "delimitedtext" and relink_file_paths and base_dir and (
            os.path.isabs(file_path) or "\\" in file_path or
            file_path[1:3] == ":/"):
        try:
            rel = os.path.relpath(file_path, base_dir).replace(os.sep, "/")
        except ValueError:
            # Different drive on Windows: a relative path is impossible.
            QgsMessageLog.logMessage(
                f"Keep absolute (different drive): {file_path[:90]}",
                LOG_TAG, Qgis.Info)
            return None
        # relpath that climbs out is fine ("../.."); only rewrite if it didn't
        # stay absolute
        if not os.path.isabs(rel) and rel[1:3] != ":/":
            if not rel.startswith("."):
                rel = f"./{rel}"
            ds.text = rel + suffix
            lid = layer_elem.findtext("id")
            if lid:
                rewritten_ids[lid] = ds.text
            return "relinked"
    return None


def rewrite_qgis_project_datasources(xml_content, layer_map=None,
                                      schema_gpkg_map=None,
                                      table_gpkg_map=None, layer_prefix_map=None,
                                      base_dir=None, return_stats=False,
                                      abs_for_gpkg=None,
                                      external_layer_map=None,
                                      relink_file_paths=False,
                                      raster_path_map=None,
                                      pg_raster_path_map=None):
    """
    Rewrite PostgreSQL datasources in a QGIS project XML to point to GeoPackage files.

    :param xml_content: project XML as string
    :param layer_map: {(schema, table, geom_column_or_None): (gpkg_path, layer_name)}
                      Preferred: built by the export worker, guarantees the
                      datasource points to the exact layer name written in the
                      GPKG (multi-geometry tables included).
    :param schema_gpkg_map: legacy {schema: gpkg_path} for per-schema / single modes
    :param table_gpkg_map: legacy {(schema, table): gpkg_path} for per-table mode
    :param layer_prefix_map: legacy {schema: "prefix__"} for single-gpkg multi-schema
    :param base_dir: if given, datasource paths are written relative to this
                     directory ("./file.gpkg|layername=..."), making the
                     project portable; otherwise absolute paths are used.
    :param abs_for_gpkg: path of a GPKG for which datasources MUST be written
                     as ABSOLUTE paths instead of relative. Used for the host
                     GPKG when embedding a project inside it: QGIS cannot
                     resolve a relative "./self.gpkg" reference from a project
                     that lives inside that same gpkg (QGIS issues #32689,
                     #39796), so the project fails to open. Absolute paths to
                     the host gpkg avoid this.
    :param return_stats: if True, returns (xml, stats) where stats includes
                         per-GPKG layer usage counts (used to pick the host
                         GPKG for project embedding).
    :returns: modified XML string, or (xml, stats) if return_stats
    """
    empty_stats = {"gpkg_usage": {}, "rewritten": 0, "relinked_files": 0,
                   "skipped": 0}
    try:
        root = ET.fromstring(xml_content)  # nosec B314
    except ET.ParseError as e:
        QgsMessageLog.logMessage(f"XML parse error: {e}", LOG_TAG, Qgis.Warning)
        return (xml_content, empty_stats) if return_stats else xml_content

    layer_map = layer_map or {}
    schema_gpkg_map = schema_gpkg_map or {}
    table_gpkg_map = table_gpkg_map or {}
    external_layer_map = external_layer_map or {}
    raster_path_map = raster_path_map or {}

    # Normalised lookup for external rasters exported as new files in the
    # output folder: source path -> new file path (already relative if wanted)
    raster_lookup = {}
    for src_path, new_path in raster_path_map.items():
        raster_lookup[_norm_file_key(src_path)] = new_path

    # PostGIS raster tables exported as external GeoTIFFs:
    # (schema, table) -> new file path
    pg_raster_path_map = pg_raster_path_map or {}
    pg_raster_lookup = dict(pg_raster_path_map)

    # Normalised lookup for external vector files copied into the gpkg:
    # absolute-normalised source .shp/.gpkg/... path -> (gpkg_path, layer_name)
    ext_lookup = {}
    for src_path, entry in external_layer_map.items():
        ext_lookup[_norm_file_key(src_path)] = entry

    # Fallback lookup by (schema, table) when the geometry column in the
    # datasource doesn't match any key (e.g. None vs actual column name).
    st_fallback = {}
    for (s, t, _g), entry in layer_map.items():
        st_fallback.setdefault((s, t), entry)

    rewritten = 0
    skipped = 0
    relinked_files = 0
    rewritten_ids = {}  # maplayer id -> new datasource (per i layer-tree-layer)
    gpkg_usage = {}     # gpkg_path -> n. layer del progetto che vi puntano

    for layer_elem in root.iter("maplayer"):
        prov = layer_elem.find("provider")
        ds = layer_elem.find("datasource")
        if prov is None or ds is None or ds.text is None:
            continue

        # PostGIS Raster layer: provider 'postgresraster'. After export it
        # becomes an external GeoTIFF in the output folder; relink to it with
        # a relative path and provider 'gdal'.
        if prov.text == "postgresraster":
            sch, tbl = _parse_pg_schema_table(ds.text or "")
            new_file = pg_raster_lookup.get((sch, tbl))
            if new_file:
                if base_dir:
                    rel = os.path.relpath(new_file, base_dir).replace(os.sep, "/")
                    new_file = rel if rel.startswith(".") else f"./{rel}"
                else:
                    new_file = new_file.replace(os.sep, "/")
                ds.text = new_file
                prov.text = "gdal"
                lid = layer_elem.findtext("id")
                if lid:
                    rewritten_ids[lid] = ds.text
                relinked_files += 1
                QgsMessageLog.logMessage(
                    f"Rewrite (pg raster→GeoTIFF): {sch}.{tbl} → {ds.text}",
                    LOG_TAG, Qgis.Info)
            else:
                skipped += 1
                QgsMessageLog.logMessage(
                    f"Rewrite skip: no exported GeoTIFF for {sch}.{tbl}",
                    LOG_TAG, Qgis.Warning)
            continue

        is_pg = (prov.text == "postgres" or "dbname=" in ds.text or "service=" in ds.text)
        if not is_pg:
            # Non-PostgreSQL layer (file-based: shapefile, gpkg, raster, ...).
            # Two possible actions:
            #   1) the source file was copied into the gpkg -> redirect the
            #      datasource to the gpkg layer (keeping any |subset filter);
            #   2) otherwise, optionally rewrite the file path relative to the
            #      output folder so the package stays portable.
            handled = _rewrite_external_datasource(
                layer_elem, prov, ds, ext_lookup, base_dir, relink_file_paths,
                rewritten_ids, raster_lookup)
            if handled == "gpkg":
                rewritten += 1
            elif handled == "relinked":
                relinked_files += 1
            else:
                skipped += 1
            continue

        ds_text = ds.text

        # Extract schema
        schema_name = None
        for pat in [r"schema='([^']*)'", r'schema="([^"]*)"', r"schema=(\S+)"]:
            m = re.search(pat, ds_text)
            if m:
                schema_name = m.group(1)
                break

        # Extract table (and remember where the match ends, to read the
        # geometry column that follows, e.g.  table="s"."t" (geom) )
        table_name = None
        table_match_end = None
        for pat in [
            r'table="([^"]*)"[.\s]*"([^"]*)"',
            r"table='([^']*)'\.'([^']*)'",
            r'table="([^"]*)"',
            r"table='([^']*)'"
        ]:
            m = re.search(pat, ds_text)
            if m:
                if m.lastindex == 2:
                    table_name = m.group(2)
                    if not schema_name:
                        schema_name = m.group(1)
                else:
                    table_name = m.group(1)
                table_match_end = m.end()
                break

        # Extract geometry column: the parenthesised token right after table=
        geom_col = None
        if table_match_end is not None:
            mg = re.match(r'\s*\(\s*"?([^")]+?)"?\s*\)',
                          ds_text[table_match_end:])
            if mg:
                geom_col = mg.group(1).strip()

        # Extract the layer filter (provider subset). In a PostgreSQL
        # datasource QGIS stores it as  sql=<expression>  at the very end.
        # It must be carried over to the GeoPackage datasource, otherwise
        # "filtered copies" of the same table (e.g. one layer per phase) all
        # collapse to the full unfiltered layer.
        subset_filter = None
        msql = re.search(r"\bsql=(.*)$", ds_text.strip(), re.DOTALL)
        if msql:
            expr = msql.group(1).strip()
            if expr:
                subset_filter = expr

        if not schema_name and table_name:
            # QGIS può omettere lo schema per le tabelle in 'public'
            schema_name = "public"

        if not schema_name or not table_name:
            QgsMessageLog.logMessage(
                f"Rewrite skip: can't parse: {ds_text[:120]}", LOG_TAG, Qgis.Warning)
            skipped += 1
            continue

        # Resolve GPKG path and layer name
        gpkg_path = None
        gpkg_layer_name = table_name

        entry = (layer_map.get((schema_name, table_name, geom_col))
                 or layer_map.get((schema_name, table_name, None))
                 or st_fallback.get((schema_name, table_name)))
        if entry:
            gpkg_path, gpkg_layer_name = entry
        elif (schema_name, table_name) in table_gpkg_map:
            gpkg_path = table_gpkg_map[(schema_name, table_name)]
        elif schema_name in schema_gpkg_map:
            gpkg_path = schema_gpkg_map[schema_name]
            if layer_prefix_map and schema_name in layer_prefix_map:
                gpkg_layer_name = f"{layer_prefix_map[schema_name]}{table_name}"

        if not gpkg_path:
            QgsMessageLog.logMessage(
                f"Rewrite skip: no GPKG for {schema_name}.{table_name}", LOG_TAG, Qgis.Warning)
            skipped += 1
            continue

        if abs_for_gpkg and os.path.normpath(gpkg_path) == \
                os.path.normpath(abs_for_gpkg):
            # Host gpkg of an embedded project: QGIS can't resolve a relative
            # self-reference, so write the absolute path.
            ds_path = os.path.abspath(gpkg_path).replace(os.sep, "/")
        elif base_dir:
            rel = os.path.relpath(gpkg_path, base_dir).replace(os.sep, "/")
            ds_path = rel if rel.startswith(".") else f"./{rel}"
        else:
            ds_path = gpkg_path

        new_ds = f"{ds_path}|layername={gpkg_layer_name}"
        if subset_filter:
            # OGR/GeoPackage subset syntax: |subset=<SQL WHERE expression>.
            # PostgreSQL and GeoPackage both use SQL, so simple field-based
            # filters transfer as-is. (Postgres-specific functions, if any,
            # may need manual adjustment — reported via the log.)
            new_ds += f"|subset={subset_filter}"
            QgsMessageLog.logMessage(
                f"Rewrite: kept filter on {schema_name}.{table_name}: "
                f"{subset_filter[:80]}", LOG_TAG, Qgis.Info)
        gpkg_usage[gpkg_path] = gpkg_usage.get(gpkg_path, 0) + 1
        QgsMessageLog.logMessage(
            f"Rewrite: {schema_name}.{table_name} → {new_ds}", LOG_TAG, Qgis.Info)

        ds.text = new_ds
        prov.text = "ogr"
        rewritten += 1

        id_elem = layer_elem.find("id")
        if id_elem is not None and id_elem.text:
            rewritten_ids[id_elem.text] = new_ds

    QgsMessageLog.logMessage(
        f"Rewrite: {rewritten} rewritten, {relinked_files} relinked, "
        f"{skipped} skipped", LOG_TAG, Qgis.Info)

    # Keep the layer tree consistent with the rewritten datasources
    for lt in root.iter("layer-tree-layer"):
        lid = lt.get("id")
        if lid in rewritten_ids:
            lt.set("source", rewritten_ids[lid])
            lt.set("providerKey", "ogr")

    # Clean up project metadata
    to_rm = []
    for parent in root.iter():
        for child in list(parent):
            if child.tag == "projectstorage":
                to_rm.append((parent, child))
    for p, c in to_rm:
        p.remove(c)

    if root.tag == "qgis":
        root.attrib.setdefault("projectname", "")

    for hp in root.iter("homePath"):
        pv = hp.get("path", "")
        if "postgresql" in pv.lower() or "dbname=" in pv.lower():
            hp.set("path", "")

    # When we rewrite datasources as paths relative to the output folder, the
    # project MUST be set to use relative paths, otherwise QGIS keeps the
    # "absolute paths" mode and fails to resolve "./file.gpkg" against the
    # project folder ("Unable to open ./file.gpkg"). Also clear any homePath
    # pointing at the original machine so the project base is its own folder.
    if base_dir:
        props = root.find("properties")
        if props is None:
            props = ET.SubElement(root, "properties")
        paths = props.find("Paths")
        if paths is None:
            paths = ET.SubElement(props, "Paths")
        abs_el = paths.find("Absolute")
        if abs_el is None:
            abs_el = ET.SubElement(paths, "Absolute")
        abs_el.set("type", "bool")
        abs_el.text = "false"
        # Reset a home path that points at an absolute on-disk location so the
        # project resolves relative datasources against its own folder.
        for hp in root.iter("homePath"):
            hp.set("path", "")

    out = serialize_qgis_project(root)

    if return_stats:
        return out, {"gpkg_usage": gpkg_usage,
                     "rewritten": rewritten,
                     "relinked_files": relinked_files,
                     "skipped": skipped}
    return out


def create_empty_gpkg(path):
    """
    Create a valid empty GeoPackage. Uses GDAL/OGR (always available inside
    QGIS); falls back to a minimal spec-compliant SQLite file (application_id
    'GPKG', gpkg_spatial_ref_sys + gpkg_contents with default SRS entries)
    so the file is recognised by QGIS/OGR even without GDAL bindings.
    """
    try:
        from osgeo import ogr
        drv = ogr.GetDriverByName("GPKG")
        if drv is not None:
            ds = drv.CreateDataSource(path)
            if ds is not None:
                ds = None  # noqa: F841 — closes/flushes the datasource
                return
    except Exception:
        pass

    con = sqlite3.connect(path)
    try:
        con.execute("PRAGMA application_id = 1196444487")  # 'GPKG'
        con.execute("PRAGMA user_version = 10300")          # GeoPackage 1.3
        con.execute("""CREATE TABLE IF NOT EXISTS gpkg_spatial_ref_sys (
            srs_name TEXT NOT NULL, srs_id INTEGER PRIMARY KEY,
            organization TEXT NOT NULL, organization_coordsys_id INTEGER NOT NULL,
            definition TEXT NOT NULL, description TEXT)""")
        con.executemany(
            "INSERT OR IGNORE INTO gpkg_spatial_ref_sys VALUES (?,?,?,?,?,?)",
            [("Undefined Cartesian SRS", -1, "NONE", -1, "undefined", None),
             ("Undefined Geographic SRS", 0, "NONE", 0, "undefined", None),
             ("WGS 84 geodetic", 4326, "EPSG", 4326,
              'GEOGCS["WGS 84",DATUM["WGS_1984",SPHEROID["WGS 84",'
              '6378137,298.257223563]],PRIMEM["Greenwich",0],'
              'UNIT["degree",0.0174532925199433]]', None)])
        con.execute("""CREATE TABLE IF NOT EXISTS gpkg_contents (
            table_name TEXT NOT NULL PRIMARY KEY, data_type TEXT NOT NULL,
            identifier TEXT UNIQUE, description TEXT DEFAULT '',
            last_change DATETIME NOT NULL
                DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
            min_x DOUBLE, min_y DOUBLE, max_x DOUBLE, max_y DOUBLE,
            srs_id INTEGER,
            CONSTRAINT fk_gc_r_srs_id FOREIGN KEY (srs_id)
                REFERENCES gpkg_spatial_ref_sys(srs_id))""")
        con.commit()
    finally:
        con.close()


def _make_qgz_bytes(project_name, xml_text):
    """
    Build a .qgz (zip containing "<project_name>.qgs") and return its bytes.

    Critical: QGIS reads project archives with libzip, which since 3.30
    applies strict consistency checks that REJECT some archives produced by
    Python's zipfile (even though they are formally valid — same symptom:
    "Impossible to unzip ..." on the temp file). To guarantee the archive is
    readable, we build it with QGIS' own QgsZipUtils.zip() (libzip), i.e. the
    exact same library that will later read it. Python's zipfile is only a
    last-resort fallback.
    """
    import tempfile

    tmpdir = tempfile.mkdtemp(prefix="pg2gpkg_")
    qgs_path = os.path.join(tmpdir, f"{project_name}.qgs")
    qgz_path = os.path.join(tmpdir, f"{project_name}.qgz")
    try:
        with open(qgs_path, "w", encoding="utf-8") as f:
            f.write(xml_text)

        used_libzip = False
        try:
            from qgis.core import QgsZipUtils
            # zip(zipFile, files, overwrite)
            if QgsZipUtils.zip(qgz_path, [qgs_path], True):
                used_libzip = True
            else:
                QgsMessageLog.logMessage(
                    "QgsZipUtils.zip returned False, falling back to zipfile",
                    LOG_TAG, Qgis.Warning)
        except Exception as e:
            QgsMessageLog.logMessage(
                f"QgsZipUtils unavailable ({e}), falling back to zipfile",
                LOG_TAG, Qgis.Warning)

        if used_libzip and os.path.exists(qgz_path):
            with open(qgz_path, "rb") as f:
                return f.read()

        # Fallback: Python zipfile (may not open in QGIS >= 3.30)
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(f"{project_name}.qgs", xml_text)
        return buf.getvalue()
    finally:
        for p in (qgs_path, qgz_path):
            try:
                if os.path.exists(p):
                    os.remove(p)
            except OSError:
                pass
        try:
            os.rmdir(tmpdir)
        except OSError:
            pass


def embed_project_in_gpkg(gpkg_path, project_name, xml_text):
    """
    Store a QGIS project inside a GeoPackage in the exact native QGIS format,
    so it opens from the Browser (geopackage:/path.gpkg?projectName=name).

    Two things are required for QGIS to actually open it, beyond writing the
    blob into qgis_projects:
      1. content must be a valid .qgz built with libzip (QgsZipUtils) — a
         Python zipfile archive is rejected by QGIS' strict reader (>= 3.30).
      2. the 'qgis' GeoPackage extension must be registered in gpkg_extensions
         for the qgis_projects table.
    """
    content = _make_qgz_bytes(project_name, xml_text)

    metadata = json.dumps({
        "last_modified_time": datetime.now().isoformat(timespec="seconds"),
        "last_modified_user": "PG2GPKG",
    })

    con = sqlite3.connect(gpkg_path)
    try:
        con.execute(
            "CREATE TABLE IF NOT EXISTS qgis_projects "
            "(name TEXT PRIMARY KEY, metadata BLOB, content BLOB)")
        con.execute(
            "INSERT OR REPLACE INTO qgis_projects VALUES (?, ?, ?)",
            (project_name, metadata, sqlite3.Binary(content)))

        # Register the QGIS GeoPackage extension (idempotent). This is the
        # row QGIS itself writes; its absence is what breaks project opening.
        con.execute(
            "CREATE TABLE IF NOT EXISTS gpkg_extensions ("
            "table_name TEXT, column_name TEXT, "
            "extension_name TEXT NOT NULL, definition TEXT NOT NULL, "
            "scope TEXT NOT NULL, "
            "CONSTRAINT ge_tce UNIQUE (table_name, column_name, extension_name))")
        # NULL column_name doesn't trip the UNIQUE constraint (NULL != NULL in
        # SQL), so INSERT OR IGNORE would still duplicate — check explicitly.
        already = con.execute(
            "SELECT 1 FROM gpkg_extensions "
            "WHERE table_name = ? AND extension_name = ?",
            ("qgis_projects", "qgis")).fetchone()
        if not already:
            con.execute(
                "INSERT INTO gpkg_extensions "
                "(table_name, column_name, extension_name, definition, scope) "
                "VALUES (?, NULL, ?, ?, ?)",
                ("qgis_projects", "qgis",
                 "http://github.com/pka/qgpkg/blob/master/"
                 "qgis_geopackage_extension.md",
                 "read-write"))
        con.commit()
    finally:
        con.close()


# ============================================================================
# Export worker (QThread)
# ============================================================================

class ExportWorker(QThread):
    """Background thread for exporting PostgreSQL tables to GeoPackage."""

    progress_updated = pyqtSignal(int, int, str)   # step, total, label
    export_finished = pyqtSignal(dict)              # results

    def __init__(self, conn_params, selected, mode, output_dir,
                 single_path, do_projects, transform_context,
                 project_filter=None, embed_external_vectors=True,
                 export_rasters=False, organize_subfolders=False,
                 parent=None):
        super().__init__(parent)
        self.conn_params = conn_params
        self.selected = selected
        self.mode = mode
        self.output_dir = output_dir
        self.single_path = single_path
        self.do_projects = do_projects
        self.transform_context = transform_context
        # Optional set/list of project names to export; None = all found
        self.project_filter = (
            set(project_filter) if project_filter is not None else None)
        # Copy external file-based vector layers into the gpkg (single mode)
        self.embed_external_vectors = embed_external_vectors
        # Export external rasters as GeoTIFFs in the output folder
        self.export_rasters = export_rasters
        # Organize outputs into Vector/ and Raster/ subfolders (project stays
        # loose in the destination root). Paths in the project are relinked
        # accordingly.
        self.organize_subfolders = organize_subfolders
        self.vector_dir = (os.path.join(output_dir, "Vector")
                           if organize_subfolders else output_dir)
        self.raster_dir = (os.path.join(output_dir, "Raster")
                           if organize_subfolders else output_dir)
        self._cancelled = False

    def request_cancel(self):
        self._cancelled = True

    def _single_vector_path(self):
        """Path of the single-mode gpkg, placed under Vector/ if organizing."""
        if not self.single_path:
            return None
        if self.organize_subfolders:
            return os.path.join(self.vector_dir,
                                os.path.basename(self.single_path))
        return self.single_path

    def _build_plan(self):
        """
        Build the export plan: a list of jobs and the (schema, table, geom)
        → (gpkg_path, layer_name) map used for project rewriting.

        Layer names are ALWAYS the original table names — no schema prefixes
        or other additions — so that project relations, value relations,
        joins and expressions keep working. A disambiguating suffix is added
        ONLY when a real name collision inside the same GeoPackage would
        otherwise silently overwrite a layer (multi-geometry tables, or the
        same table name in two schemas exported to a single GPKG). Each
        renamed layer is reported as a warning.
        """
        jobs = []          # [{schema, tinfo, gpkg, layer_name}]
        layer_map = {}     # (schema, table, geom_col) -> (gpkg, layer_name)
        warnings = []
        used = {}          # gpkg_path -> set(layer names)

        for schema, tables in self.selected.items():
            for t in tables:
                table = t["table"]
                geom = t["geom_column"]

                # PostGIS Raster tables don't go into a gpkg: they are exported
                # as external GeoTIFFs. Keep them in jobs (gpkg=None) so the
                # worker can pick them up, but out of the vector layer_map.
                if t.get("is_raster"):
                    jobs.append({"schema": schema, "tinfo": t,
                                 "gpkg": None, "layer_name": table})
                    continue

                if self.mode == 1:
                    gp = self._single_vector_path()
                elif self.mode == 2:
                    gp = os.path.join(self.vector_dir, schema, f"{table}.gpkg")
                else:
                    gp = os.path.join(self.vector_dir, f"{schema}.gpkg")

                names = used.setdefault(gp, {})  # name -> (schema, table)
                name = table
                if name in names:
                    # Real collision: disambiguate minimally and warn.
                    # Same schema+table → multi-geometry → suffix the geometry
                    # column; different schema → suffix the schema name.
                    owner = names[name]
                    candidates = []
                    if owner == (schema, table) and geom:
                        candidates = [f"{table}_{geom}",
                                      f"{schema}_{table}_{geom}"]
                    else:
                        candidates = [f"{schema}_{table}"]
                        if geom:
                            candidates.append(f"{schema}_{table}_{geom}")
                    name = next((c for c in candidates if c not in names), None)
                    i = 2
                    while name is None or name in names:
                        name = f"{table}_{i}"
                        i += 1
                    warnings.append(
                        f"Name collision in {os.path.basename(gp)}: "
                        f"{schema}.{table}"
                        + (f" ({geom})" if geom else "")
                        + f" exported as layer '{name}'")
                names[name] = (schema, table)

                jobs.append({"schema": schema, "tinfo": t,
                             "gpkg": gp, "layer_name": name})
                layer_map[(schema, table, geom)] = (gp, name)

        return jobs, layer_map, warnings

    def run(self):
        errors = []
        ok_count = 0
        exported_projects = []

        total = sum(len(v) for v in self.selected.values())
        step = 0

        jobs, layer_map, name_warnings = self._build_plan()
        errors.extend(name_warnings)

        # Remove pre-existing target files once, then append layers into them
        cleaned = set()
        for job in jobs:
            gp = job["gpkg"]
            if not gp or gp in cleaned:
                continue
            os.makedirs(os.path.dirname(gp), exist_ok=True)
            if os.path.exists(gp):
                try:
                    os.remove(gp)
                except OSError as e:
                    errors.append(f"Cannot overwrite {gp}: {e}")
            cleaned.add(gp)

        pg_raster_jobs = []   # raster tables → exported as external GeoTIFFs
        for job in jobs:
            if self._cancelled:
                break
            schema = job["schema"]
            t = job["tinfo"]

            if t.get("is_raster"):
                # PostGIS Raster tables are NOT written into the gpkg; they are
                # collected here and exported as external GeoTIFFs (same place
                # as on-disk rasters), so the gpkg stays vector-only.
                pg_raster_jobs.append(job)
                continue

            step += 1
            self.progress_updated.emit(step, total, f"{schema}.{t['table']}")
            ok, msg = export_table_to_gpkg(
                self.conn_params, schema, t, job["gpkg"],
                layer_name_override=job["layer_name"],
                transform_context=self.transform_context)
            if ok:
                ok_count += 1
            else:
                errors.append(msg)
            QgsMessageLog.logMessage(
                msg, LOG_TAG, Qgis.Info if ok else Qgis.Warning)

        gpkg_count = sum(
            1 for gp in {j["gpkg"] for j in jobs} if gp and os.path.exists(gp))

        # ── QGIS projects ──
        # Each selected project is written as a plain .qgs file in the output
        # folder, with datasources relinked (relative paths) to the exported
        # GeoPackage layers.
        embedded_projects = []
        if self.do_projects and not self._cancelled:
            self.progress_updated.emit(step, total, "QGIS projects...")

            conn = None
            try:
                conn = pg_connect(self.conn_params)
                projects = get_qgis_projects_in_db(conn)
                if self.project_filter is not None:
                    projects = [p for p in projects
                                if p["name"] in self.project_filter]
                if not projects:
                    QgsMessageLog.logMessage(
                        "No QGIS projects found in database", LOG_TAG, Qgis.Info)
                for proj in projects:
                    if self._cancelled:
                        break
                    pn = proj["name"]
                    if pn.lower().endswith((".qgz", ".qgs")):
                        pn = pn[:-4]
                    qgz_name = pn + ".qgz"

                    self.progress_updated.emit(step, total, f"Project: {qgz_name}")

                    try:
                        # --- Copy external vector files (shapefiles, etc.)
                        #     referenced by the project into the GeoPackage, so
                        #     the project no longer depends on those external
                        #     files. Their datasources are then redirected to
                        #     the gpkg; rasters/other files are made relative.
                        external_layer_map = {}
                        if self.embed_external_vectors:
                            # Destination gpkg for the external vectors:
                            #  • single mode → the single output gpkg
                            #  • per-schema / per-table → a dedicated
                            #    'esterni.gpkg' in the output folder
                            if self.single_path:
                                ext_gpkg = self._single_vector_path()
                            else:
                                ext_gpkg = os.path.join(self.vector_dir,
                                                        "esterni.gpkg")
                            ext_layers = collect_external_vector_layers(
                                proj["xml_content"],
                                skip_paths=[ext_gpkg])
                            used_names = {n for (_s, _t, _g), (_gp, n)
                                          in layer_map.items()
                                          if os.path.normpath(_gp) ==
                                          os.path.normpath(ext_gpkg)}
                            for key, info in ext_layers.items():
                                if self._cancelled:
                                    break
                                src = info["path"]
                                prov = info.get("provider", "ogr")
                                # layer name: file stem, disambiguated
                                base = os.path.splitext(info["basename"])[0]
                                base = re.sub(r"[^0-9A-Za-z_]+", "_", base) or "layer"
                                lname = base
                                i = 2
                                while lname in used_names:
                                    lname = f"{base}_{i}"
                                    i += 1
                                ok, msg = export_vector_file_to_gpkg(
                                    src, ext_gpkg, lname,
                                    self.transform_context, provider=prov,
                                    full_uri=info.get("full_uri"))
                                if ok:
                                    used_names.add(lname)
                                    external_layer_map[src] = (ext_gpkg, lname)
                                    QgsMessageLog.logMessage(
                                        f"External vector copied: {msg}",
                                        LOG_TAG, Qgis.Info)
                                else:
                                    QgsMessageLog.logMessage(
                                        f"External vector skipped: {msg}",
                                        LOG_TAG, Qgis.Warning)

                        # --- Export external rasters as compressed GeoTIFFs
                        #     in the output folder (not inside the gpkg), and
                        #     relink the project to the new relative paths.
                        raster_path_map = {}
                        if self.export_rasters:
                            rasters = collect_external_raster_layers(
                                proj["xml_content"])
                            used_files = set()
                            n_done = 0
                            for rkey, rinfo in rasters.items():
                                if self._cancelled:
                                    break
                                src = rinfo["path"]
                                stem = os.path.splitext(rinfo["basename"])[0]
                                stem = re.sub(r"[^0-9A-Za-z_\-]+", "_", stem) or "raster"
                                # All in the output folder, one flat dir;
                                # disambiguate only on name collision.
                                fname = f"{stem}.tif"
                                j = 2
                                while fname.lower() in used_files:
                                    fname = f"{stem}_{j}.tif"
                                    j += 1
                                used_files.add(fname.lower())
                                if self.organize_subfolders:
                                    os.makedirs(self.raster_dir, exist_ok=True)
                                dst = os.path.join(self.raster_dir, fname)
                                ok, msg = export_raster_layer_to_geotiff(
                                    src, "gdal", dst, compress="LZW")
                                if ok:
                                    raster_path_map[src] = dst
                                    n_done += 1
                                    QgsMessageLog.logMessage(
                                        f"Raster exported: {msg}",
                                        LOG_TAG, Qgis.Info)
                                else:
                                    QgsMessageLog.logMessage(
                                        f"Raster skipped: {msg}",
                                        LOG_TAG, Qgis.Warning)
                            if n_done:
                                QgsMessageLog.logMessage(
                                    f"Project '{pn}': {n_done} rasters "
                                    f"exported as GeoTIFF", LOG_TAG, Qgis.Info)

                        # --- Export PostGIS Raster tables (selected in the DB
                        #     panel) as external GeoTIFFs, same folder. These
                        #     are gated only by the table selection, not by the
                        #     "export rasters" checkbox (which is for on-disk
                        #     rasters).
                        pg_raster_path_map = {}
                        if pg_raster_jobs:
                            # Map (schema, table) -> the postgresraster
                            # datasource exactly as it appears in the project,
                            # so the loaded layer has the project's position.
                            pg_ds_by_table = _collect_pg_raster_datasources(
                                proj["xml_content"])
                            used_files = set(
                                os.path.basename(p).lower()
                                for p in raster_path_map.values())
                            for rjob in pg_raster_jobs:
                                if self._cancelled:
                                    break
                                rsch = rjob["schema"]
                                rt = rjob["tinfo"]
                                stem = re.sub(r"[^0-9A-Za-z_\-]+", "_",
                                              rt["table"]) or "raster"
                                fname = f"{stem}.tif"
                                j = 2
                                while fname.lower() in used_files:
                                    fname = f"{stem}_{j}.tif"
                                    j += 1
                                used_files.add(fname.lower())
                                if self.organize_subfolders:
                                    os.makedirs(self.raster_dir, exist_ok=True)
                                dst = os.path.join(self.raster_dir, fname)
                                # Export the DB raster in a SEPARATE PROCESS via
                                # gdal_translate: the fragile PostGISRaster
                                # driver can't take QGIS down if it fails.
                                QgsMessageLog.logMessage(
                                    f"Exporting DB raster {rsch}.{rt['table']} "
                                    f"→ {fname} (subprocess)…",
                                    LOG_TAG, Qgis.Info)
                                ok, msg = export_pg_raster_via_subprocess(
                                    self.conn_params, rsch, rt["table"],
                                    rt.get("raster_column", "rast"), dst,
                                    compress="LZW")
                                if ok:
                                    pg_raster_path_map[(rsch, rt["table"])] = dst
                                    ok_count += 1
                                    QgsMessageLog.logMessage(
                                        f"Raster exported: {msg}",
                                        LOG_TAG, Qgis.Info)
                                else:
                                    errors.append(msg)
                                    QgsMessageLog.logMessage(
                                        f"Raster skipped: {msg}",
                                        LOG_TAG, Qgis.Warning)

                        # Project exported as a .qgz file next to the
                        # GeoPackage(s), with datasources rewritten to the
                        # exported layers using paths RELATIVE to the output
                        # folder. Keep the .qgz and the .gpkg(s) together.
                        xml, stats = rewrite_qgis_project_datasources(
                            proj["xml_content"], layer_map=layer_map,
                            base_dir=self.output_dir, return_stats=True,
                            external_layer_map=external_layer_map,
                            relink_file_paths=True,
                            raster_path_map=raster_path_map,
                            pg_raster_path_map=pg_raster_path_map)

                        if stats["rewritten"] == 0:
                            QgsMessageLog.logMessage(
                                f"Project '{pn}': no datasource matched the "
                                f"exported layers", LOG_TAG, Qgis.Warning)
                        if stats.get("relinked_files"):
                            QgsMessageLog.logMessage(
                                f"Project '{pn}': {stats['relinked_files']} "
                                f"external file paths made relative",
                                LOG_TAG, Qgis.Info)

                        # Save as a compressed .qgz (single portable file)
                        # built with libzip (QgsZipUtils), the same library
                        # QGIS uses to read it back.
                        pp = os.path.join(self.output_dir, qgz_name)
                        qgz_bytes = _make_qgz_bytes(pn, xml)
                        with open(pp, "wb") as f:
                            f.write(qgz_bytes)
                        exported_projects.append(qgz_name)
                        QgsMessageLog.logMessage(
                            f"Project exported: {qgz_name} "
                            f"({stats['rewritten']} layers relinked)",
                            LOG_TAG, Qgis.Info)
                    except Exception as e:
                        errors.append(f"Project {qgz_name}: {e}")
                        QgsMessageLog.logMessage(
                            f"Project {qgz_name}: {e}", LOG_TAG, Qgis.Warning)
            except Exception as e:
                errors.append(f"Projects: {e}")
                QgsMessageLog.logMessage(
                    f"Error connecting for projects: {e}", LOG_TAG, Qgis.Warning)
            finally:
                if conn:
                    try:
                        conn.close()
                    except Exception:
                        pass

        self.export_finished.emit({
            "ok_count": ok_count,
            "errors": errors,
            "gpkg_count": gpkg_count,
            "exported_projects": exported_projects,
            "embedded_projects": embedded_projects,
            "mode": self.mode,
            "total": total,
            "cancelled": self._cancelled,
        })
