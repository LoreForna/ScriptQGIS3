"""
PG2GPKG - Database utility functions
Copyright (C) 2025 Federico Gianoli — GPLv3
"""

import os
import re
import zlib
import zipfile
import io

from qgis.core import QgsMessageLog, Qgis
from qgis.PyQt.QtCore import QSettings

try:
    import psycopg2
    from psycopg2 import sql as psql
    HAS_PSYCOPG2 = True
except ImportError:
    HAS_PSYCOPG2 = False

SYSTEM_TABLES = {
    "geography_columns", "geometry_columns", "spatial_ref_sys",
    "raster_columns", "raster_overviews", "qgis_projects",
}

LOG_TAG = "PG2GPKG"


# ============================================================================
# Connection helpers
# ============================================================================

def get_pg_connections():
    """Return dict of registered PostgreSQL connections from QGIS settings."""
    s = QSettings()
    s.beginGroup("PostgreSQL/connections")
    connections = {}
    for name in s.childGroups():
        s.beginGroup(name)
        connections[name] = {
            "host": s.value("host", "localhost"),
            "port": s.value("port", "5432"),
            "database": s.value("database", ""),
            "username": s.value("username", ""),
            "password": s.value("password", ""),
            "sslmode": s.value("sslmode", "prefer"),
            "authcfg": s.value("authcfg", ""),
        }
        s.endGroup()
    s.endGroup()
    return connections


def resolve_auth_params(params):
    """Resolve QGIS authcfg to actual username/password. Must be called from main thread."""
    authcfg = params.get("authcfg", "")
    if not authcfg or (params.get("username") and params.get("password")):
        return params
    try:
        from qgis.core import QgsApplication, QgsAuthMethodConfig
        conf = QgsAuthMethodConfig()
        if QgsApplication.authManager().loadAuthenticationConfig(authcfg, conf, True):
            params = dict(params)
            params["username"] = conf.config("username") or params.get("username", "")
            params["password"] = conf.config("password") or params.get("password", "")
    except Exception as e:
        QgsMessageLog.logMessage(
            f"Auth config resolution failed for {authcfg}: {e}", LOG_TAG, Qgis.Warning)
    return params


def normalize_sslmode(value):
    """Convert QGIS/Qt sslmode enum values to psycopg2-compatible strings."""
    if value is None:
        return "prefer"
    mapping = {
        "SslPrefer": "prefer", "SslDisable": "disable", "SslAllow": "allow",
        "SslRequire": "require", "SslVerifyCa": "verify-ca", "SslVerifyFull": "verify-full",
        "0": "prefer", "1": "disable", "2": "allow",
        "3": "require", "4": "verify-ca", "5": "verify-full",
    }
    s = str(value).strip()
    valid = ("prefer", "disable", "allow", "require", "verify-ca", "verify-full")
    return mapping.get(s, s.lower() if s.lower() in valid else "prefer")


def pg_connect(params):
    """Open a psycopg2 connection. Call resolve_auth_params first if using authcfg."""
    return psycopg2.connect(
        host=params["host"], port=params["port"], dbname=params["database"],
        user=params["username"], password=params["password"],
        sslmode=normalize_sslmode(params.get("sslmode")),
    )


# ============================================================================
# Schema / table discovery
# ============================================================================

def get_schemas(conn):
    """Return list of non-system schemas."""
    cur = conn.cursor()
    try:
        cur.execute("""
            SELECT schema_name FROM information_schema.schemata
            WHERE schema_name NOT IN ('pg_catalog','information_schema','pg_toast','topology')
            ORDER BY schema_name
        """)
        return [r[0] for r in cur.fetchall()]
    finally:
        cur.close()


def table_exists(conn, schema, table):
    """Return True if the given table exists in the schema."""
    cur = conn.cursor()
    try:
        cur.execute("""
            SELECT EXISTS (
                SELECT 1 FROM information_schema.tables
                WHERE table_schema = %s AND table_name = %s
            )
        """, (schema, table))
        return bool(cur.fetchone()[0])
    finally:
        cur.close()


def get_table_columns(conn, schema, table):
    """Return list of column names for an existing table (in declaration order)."""
    cur = conn.cursor()
    try:
        cur.execute("""
            SELECT column_name FROM information_schema.columns
            WHERE table_schema = %s AND table_name = %s
            ORDER BY ordinal_position
        """, (schema, table))
        return [r[0] for r in cur.fetchall()]
    finally:
        cur.close()


def drop_table_cascade(conn, schema, table):
    """Drop a table with CASCADE. Returns True if it ran without error."""
    cur = conn.cursor()
    try:
        cur.execute(
            psql.SQL("DROP TABLE IF EXISTS {}.{} CASCADE").format(
                psql.Identifier(schema), psql.Identifier(table)))
        conn.commit()
        return True
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()


def rename_table_columns(conn, schema, table, renames):
    """Apply ALTER TABLE ... RENAME COLUMN for each (old, new) in renames.
    Skips rows where old == new. Commits at the end."""
    if not renames:
        return
    cur = conn.cursor()
    try:
        for old, new in renames:
            if old == new:
                continue
            cur.execute(
                psql.SQL("ALTER TABLE {}.{} RENAME COLUMN {} TO {}").format(
                    psql.Identifier(schema), psql.Identifier(table),
                    psql.Identifier(old), psql.Identifier(new)))
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()


def pg_is_in_recovery(conn):
    """True if the server is currently in WAL recovery (standby or post-crash)."""
    cur = conn.cursor()
    try:
        cur.execute("SELECT pg_is_in_recovery()")
        row = cur.fetchone()
        return bool(row[0]) if row else False
    finally:
        cur.close()


def get_server_version(conn):
    """Return PostgreSQL server_version_num (e.g. '150004' for 15.4) or ''."""
    cur = conn.cursor()
    try:
        cur.execute("SHOW server_version_num")
        row = cur.fetchone()
        return str(row[0]) if row else ""
    except Exception:
        return ""
    finally:
        cur.close()


def get_postgis_version(conn):
    """Return PostGIS version string (e.g. '3.4.2') or ''. None if extension absent."""
    cur = conn.cursor()
    try:
        cur.execute("SELECT extversion FROM pg_extension WHERE extname='postgis'")
        row = cur.fetchone()
        return row[0] if row else ""
    except Exception:
        return ""
    finally:
        cur.close()


def create_schema(conn, schema_name):
    """Run CREATE SCHEMA IF NOT EXISTS for the given identifier.
    The name is passed through psql.Identifier so quoting is automatic."""
    cur = conn.cursor()
    try:
        cur.execute(
            psql.SQL("CREATE SCHEMA IF NOT EXISTS {}").format(
                psql.Identifier(schema_name)))
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()


def get_writable_schemas(conn):
    """Return list of schemas where the current user has CREATE privilege."""
    cur = conn.cursor()
    try:
        cur.execute("""
            SELECT n.nspname
            FROM pg_namespace n
            WHERE n.nspname NOT IN ('pg_catalog','information_schema','pg_toast','topology')
              AND n.nspname NOT LIKE 'pg_temp_%'
              AND n.nspname NOT LIKE 'pg_toast_temp_%'
              AND has_schema_privilege(current_user, n.nspname, 'CREATE')
            ORDER BY n.nspname
        """)
        return [r[0] for r in cur.fetchall()]
    finally:
        cur.close()


def get_tables_and_views(conn, schema):
    """
    Return list of dicts with table info.
    Each dict: {table, geom_column, geom_type, srid, table_type, is_raster,
                raster_column, num_bands}
    Raster tables (PostGIS Raster) are detected via raster_columns and marked
    with is_raster=True so the export can handle them as rasters, not vectors.
    """
    cur = conn.cursor()
    try:
        cur.execute("""
            SELECT f_table_name, f_geometry_column, type, srid
            FROM geometry_columns WHERE f_table_schema = %s ORDER BY f_table_name
        """, (schema,))
        spatial = {}
        for tname, gcol, gtype, srid in cur.fetchall():
            spatial.setdefault(tname, []).append(
                {"geom_column": gcol, "geom_type": gtype, "srid": srid})

        # PostGIS Raster tables (may be absent if the raster extension isn't
        # installed; ignore errors in that case).
        raster = {}
        try:
            cur.execute("""
                SELECT r_table_name, r_raster_column, srid, num_bands
                FROM raster_columns WHERE r_table_schema = %s
                ORDER BY r_table_name
            """, (schema,))
            for tname, rcol, srid, nbands in cur.fetchall():
                raster[tname] = {"raster_column": rcol, "srid": srid,
                                 "num_bands": nbands}
        except Exception:
            conn.rollback()  # raster_columns not available; continue cleanly

        cur.execute("""
            SELECT table_name, table_type FROM information_schema.tables
            WHERE table_schema = %s ORDER BY table_name
        """, (schema,))
        results = []
        for tname, ttype in cur.fetchall():
            if tname in SYSTEM_TABLES:
                continue
            if tname in raster:
                ri = raster[tname]
                results.append({
                    "table": tname, "geom_column": None,
                    "geom_type": "RASTER", "srid": ri["srid"],
                    "table_type": ttype, "is_raster": True,
                    "raster_column": ri["raster_column"],
                    "num_bands": ri["num_bands"],
                })
            elif tname in spatial:
                for gi in spatial[tname]:
                    results.append({
                        "table": tname, "geom_column": gi["geom_column"],
                        "geom_type": gi["geom_type"], "srid": gi["srid"],
                        "table_type": ttype, "is_raster": False,
                    })
            else:
                results.append({
                    "table": tname, "geom_column": None,
                    "geom_type": None, "srid": 0, "table_type": ttype,
                    "is_raster": False,
                })
        return results
    finally:
        cur.close()


# ============================================================================
# QGIS projects in database
# ============================================================================

def get_qgis_projects_in_db(conn):
    """
    Find QGIS projects stored in the database.
    Returns list of dicts: {schema, name, xml_content}
    """
    cur = conn.cursor()
    try:
        cur.execute("""
            SELECT table_schema, table_name FROM information_schema.tables
            WHERE table_name = 'qgis_projects'
        """)
        project_tables = cur.fetchall()
    finally:
        cur.close()

    projects = []
    for pschema, ptable in project_tables:
        cur = conn.cursor()
        try:
            cur.execute("""
                SELECT column_name FROM information_schema.columns
                WHERE table_schema=%s AND table_name=%s ORDER BY ordinal_position
            """, (pschema, ptable))
            columns = [r[0] for r in cur.fetchall()]
            QgsMessageLog.logMessage(
                f"{pschema}.{ptable} columns: {columns}", LOG_TAG, Qgis.Info)

            # Standard QGIS schema: name TEXT, metadata JSONB, content BYTEA.
            # Only 'content' holds the project; 'metadata' is just JSON info.
            if "content" not in columns:
                QgsMessageLog.logMessage(
                    f"{pschema}.{ptable}: no 'content' column, skipping "
                    f"(non-standard qgis_projects table)", LOG_TAG, Qgis.Warning)
                continue
            xml_col = "content"

            cur.execute(
                psql.SQL("SELECT name, {} FROM {}.{}").format(
                    psql.Identifier(xml_col),
                    psql.Identifier(pschema),
                    psql.Identifier(ptable),
                )
            )
            for name, raw in cur.fetchall():
                if raw is None:
                    continue
                if isinstance(raw, memoryview):
                    raw = bytes(raw)
                xml = _extract_qgs_xml(name, raw)
                if xml:
                    projects.append({"schema": pschema, "name": name, "xml_content": xml})
        except Exception as e:
            QgsMessageLog.logMessage(
                f"Error reading projects from {pschema}.{ptable}: {e}",
                LOG_TAG, Qgis.Warning)
            conn.rollback()
        finally:
            cur.close()

    return projects


def _is_qgs(text):
    """True if the text looks like a QGIS project file.

    Real .qgs files written by QGIS start with a DOCTYPE declaration
    (<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>) and
    usually have NO <?xml ...?> prolog, so checking only for '<?xml' or
    '<qgis' rejects every genuine project. Accept any of the three
    openings, plus a fallback scan of the first bytes for '<qgis'.
    """
    s = text.lstrip("\ufeff").strip()
    return (s.startswith("<?xml")
            or s.startswith("<!DOCTYPE qgis")
            or s.startswith("<qgis")
            or "<qgis" in s[:1024])


def _extract_qgs_xml(name, raw):
    """Extract QGIS project XML from various storage formats."""
    if isinstance(raw, str):
        return raw if _is_qgs(raw) else None
    if isinstance(raw, memoryview):
        raw = bytes(raw)
    if isinstance(raw, dict) or not isinstance(raw, bytes):
        return None

    QgsMessageLog.logMessage(
        f"Project {name}: {len(raw)} bytes, header: {raw[:4].hex()}", LOG_TAG, Qgis.Info)

    # ZIP (.qgz)
    if raw[:4] == b'PK\x03\x04':
        try:
            with zipfile.ZipFile(io.BytesIO(raw), "r") as zf:
                qgs = [f for f in zf.namelist() if f.lower().endswith(".qgs")]
                target = qgs[0] if qgs else (zf.namelist()[0] if zf.namelist() else None)
                if target:
                    text = zf.read(target).decode("utf-8")
                    if _is_qgs(text):
                        return text
        except Exception as e:
            QgsMessageLog.logMessage(f"Project {name}: ZIP error: {e}", LOG_TAG, Qgis.Warning)

    # zlib
    if raw[:1] == b'\x78':
        try:
            text = zlib.decompress(raw).decode("utf-8")
            if _is_qgs(text):
                return text
        except Exception:
            pass

    # plain UTF-8
    try:
        text = raw.decode("utf-8")
        if _is_qgs(text):
            return text
    except Exception:
        pass

    # last resort zlib
    try:
        text = zlib.decompress(raw).decode("utf-8")
        if _is_qgs(text):
            return text
    except Exception:
        pass

    QgsMessageLog.logMessage(
        f"Project {name}: cannot extract XML. header: {raw[:16].hex()}", LOG_TAG, Qgis.Warning)
    return None


# Public alias: also used by the import side to read projects from GeoPackages
extract_qgs_xml = _extract_qgs_xml
