# -*- coding: utf-8 -*-
"""
Suite di verifica completa per coord_std_dev_xyz.py.

Estrae dal sorgente le sezioni puro-Python (RunningStats3D, derived_stats,
_ellipse_coords, _percentile_sqrt) ed esegue:

  PARTE A - VERIFICA MANUALE aritmetica su un caso 3D piccolo
  PARTE B - REGRESSION dei casi planimetrici noti
  PARTE C - STABILITA' NUMERICA Welford su coordinate UTM
  PARTE D - AUTOVALORI 2x2 vs numpy.linalg.eigh
  PARTE E - PERCENTILI ed ellisse
  PARTE F - CEP50/SEP vs grandezze teoriche
  PARTE G - EDGE CASES (n=1, n=2, Z tutti NaN, anisotropia estrema)
  PARTE H - CASO 3D MISTO (alcuni vertici senza Z)
  PARTE I - CASO TOPOGRAFICO REALE
  PARTE J - INVARIANZA TRASLAZIONE 3D
"""

import math
import sys
from collections import defaultdict

try:
    import numpy as np
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install",
                           "numpy", "--break-system-packages", "-q"])
    import numpy as np


# ---------------------------------------------------------------------------
# Estrazione delle sezioni puro-Python dal sorgente
# ---------------------------------------------------------------------------
import os
_HERE = os.path.dirname(os.path.abspath(__file__))
SRC = open(os.path.join(_HERE, "coord_std_dev_xyz.py"),
           encoding="utf-8").read()
start = SRC.find("class RunningStats3D:")
end   = SRC.find("# ============================================================================\n"
                 "# Processing algorithm")
assert start > 0 and end > start, "non riesco a estrarre la sezione pure"
pure = SRC[start:end]

ns = {"math": math, "defaultdict": defaultdict, "__name__": "__pure__"}
exec(compile(pure, "<pure>", "exec"), ns)

RunningStats3D   = ns["RunningStats3D"]
derived_stats    = ns["derived_stats"]
_ellipse_coords  = ns["_ellipse_coords"]
_percentile_sqrt = ns["_percentile_sqrt"]


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------
results = []


def feed(points_xyz):
    acc = RunningStats3D()
    pts = []
    for p in points_xyz:
        x, y = p[0], p[1]
        z = p[2] if len(p) > 2 else None
        acc.add(x, y, z)
        pts.append((x, y, z))
    return acc, pts


def check(label, got, expected, tol=1e-9):
    if got is None and expected is None:
        ok = True
    elif got is None or expected is None:
        ok = False
    else:
        ok = math.isclose(got, expected, abs_tol=tol, rel_tol=tol)
    status = "OK " if ok else "FAIL"
    g_repr = (f"{got!r:>24s}"
              if isinstance(got, (int, float, str))
              else repr(got))
    print(f"  [{status}] {label:42s} got={g_repr}  exp={expected!r}")
    results.append(ok)
    return ok


def header(s):
    print("\n" + "=" * 78)
    print(s)
    print("=" * 78)


# ===========================================================================
# PARTE A - VERIFICA MANUALE ARITMETICA
# ---------------------------------------------------------------------------
# 3 punti: P1=(0,0,10), P2=(3,0,13), P3=(0,4,16)
#
# Medie:
#   m_x = (0+3+0)/3 = 1
#   m_y = (0+0+4)/3 = 4/3
#   m_z = (10+13+16)/3 = 13
#
# Scarti:
#   P1: dx=-1, dy=-4/3, dz=-3
#   P2: dx= 2, dy=-4/3, dz= 0
#   P3: dx=-1, dy= 8/3, dz= 3
#
# Somme:
#   sum(dx^2) = 1 + 4 + 1 = 6
#   sum(dy^2) = 16/9 + 16/9 + 64/9 = 96/9 = 32/3
#   sum(dz^2) = 9 + 0 + 9 = 18
#   sum(dx*dy) = (-1)(-4/3) + (2)(-4/3) + (-1)(8/3)
#              = 4/3 - 8/3 - 8/3 = -12/3 = -4
#
# Varianze campionarie (denominatore n-1 = 2):
#   var_x  = 6/2  = 3
#   var_y  = (32/3)/2 = 16/3
#   var_z  = 18/2 = 9
#   cov_xy = -4/2 = -2
#
# Sigma:
#   sigma_x  = sqrt(3)        ~ 1.7320508
#   sigma_y  = sqrt(16/3)     ~ 2.3094011
#   sigma_z  = sqrt(9)        = 3
#   sigma_xy = -2
#   sigma_p  = sqrt(3 + 16/3) = sqrt(25/3)  ~ 2.8867513
#   sigma_3d = sqrt(3 + 16/3 + 9) = sqrt(52/3) ~ 4.1633320
#
# Autovalori della matrice di covarianza 2D:
#   tr   = 3 + 16/3 = 25/3
#   diff = 3 - 16/3 = -7/3
#   disc = sqrt((diff/2)^2 + cov_xy^2) = sqrt((7/6)^2 + 4)
#        = sqrt(49/36 + 144/36) = sqrt(193/36) = sqrt(193)/6
#   lam_max = (25/3)/2 + sqrt(193)/6 = 25/6 + sqrt(193)/6 = (25+sqrt(193))/6
#   lam_min = (25-sqrt(193))/6
#   sigma_max = sqrt(lam_max)
#   sigma_min = sqrt(lam_min)
#
# theta = 0.5 * atan2(2*cov_xy, var_x - var_y)
#       = 0.5 * atan2(-4, -7/3)
#   atan2(-4, -7/3): terzo quadrante
#   = -pi + atan(4 / (7/3)) = -pi + atan(12/7)
# ===========================================================================
header("PARTE A - VERIFICA MANUALE ARITMETICA "
       "(3 punti 3D, valori calcolati a mano)")

pts_manual = [(0, 0, 10), (3, 0, 13), (0, 4, 16)]
acc, pts = feed(pts_manual)
s = derived_stats(acc, pts)

check("n",      s["n"],      3)
check("n_z",    s["n_z"],    3)
check("mean_x", s["mean_x"], 1.0)
check("mean_y", s["mean_y"], 4.0 / 3.0)
check("mean_z", s["mean_z"], 13.0)

check("sigma_x",  s["sigma_x"],  math.sqrt(3.0))
check("sigma_y",  s["sigma_y"],  math.sqrt(16.0 / 3.0))
check("sigma_z",  s["sigma_z"],  3.0)
check("sigma_xy", s["sigma_xy"], -2.0)
check("sigma_p",  s["sigma_p"],  math.sqrt(25.0 / 3.0))
check("sigma_3d", s["sigma_3d"], math.sqrt(52.0 / 3.0))

lam_max_exp = (25.0 + math.sqrt(193.0)) / 6.0
lam_min_exp = (25.0 - math.sqrt(193.0)) / 6.0
check("sigma_max", s["sigma_max"], math.sqrt(lam_max_exp))
check("sigma_min", s["sigma_min"], math.sqrt(lam_min_exp))

# theta atteso: 0.5 * atan2(-4, -7/3)
theta_exp_rad = 0.5 * math.atan2(-4.0, -7.0 / 3.0)
theta_exp_deg = math.degrees(theta_exp_rad)
check("theta_deg", s["theta_deg"], theta_exp_deg)

# anisotropia
aniso_exp = math.sqrt(lam_max_exp) / math.sqrt(lam_min_exp)
check("anisotropy", s["anisotropy"], aniso_exp)

# CEP50 con formula RAND
cep_exp = 0.5614 * math.sqrt(lam_max_exp) + 0.6175 * math.sqrt(lam_min_exp)
check("CEP50", s["CEP50"], cep_exp)

# SEP (sul subset Z = tutti i punti, quindi sigma_x e sigma_y identiche)
sep_exp = 0.51 * (math.sqrt(3.0) + math.sqrt(16.0 / 3.0) + 3.0)
check("SEP", s["SEP"], sep_exp)

# rmsd_2d e rmsd_3d (denominatore n)
# d2_sq = (-1)^2+(-4/3)^2 + 2^2+(-4/3)^2 + (-1)^2+(8/3)^2
#       = 1+16/9 + 4+16/9 + 1+64/9 = 6 + 96/9 = 6 + 32/3 = 50/3
# rmsd_2d = sqrt((50/3)/3) = sqrt(50/9) = 5*sqrt(2)/3
check("rmsd_2d", s["rmsd_2d"], math.sqrt(50.0 / 9.0))

# d3_sq = d2_sq + dz^2 = 50/3 + 18 = 50/3 + 54/3 = 104/3
# rmsd_3d = sqrt((104/3)/3) = sqrt(104/9)
check("rmsd_3d", s["rmsd_3d"], math.sqrt(104.0 / 9.0))

# max_dist_2d: max(d2_sq per punto)
#   P1: 1+16/9 = 25/9
#   P2: 4+16/9 = 52/9
#   P3: 1+64/9 = 73/9
# max -> 73/9
check("max_dist_2d", s["max_dist_2d"], math.sqrt(73.0 / 9.0))

# max_dist_3d: max(d3_sq per punto)
#   P1: 25/9 + 9 = 25/9 + 81/9 = 106/9
#   P2: 52/9 + 0 = 52/9
#   P3: 73/9 + 9 = 73/9 + 81/9 = 154/9
# max -> 154/9
check("max_dist_3d", s["max_dist_3d"], math.sqrt(154.0 / 9.0))


# ===========================================================================
# PARTE A.2 - CONFRONTO DIRETTO CON NUMPY (stessi 3 punti)
# ===========================================================================
header("PARTE A.2 - Confronto con numpy.linalg.eigh sui medesimi 3 punti")

arr = np.array(pts_manual, dtype=float)
cov2d = np.cov(arr[:, 0], arr[:, 1], ddof=1)
eigvals, eigvecs = np.linalg.eigh(cov2d)
# eigh ordina ascendente -> [lam_min, lam_max]
sigma_min_np = math.sqrt(max(float(eigvals[0]), 0.0))
sigma_max_np = math.sqrt(max(float(eigvals[1]), 0.0))
v_max = eigvecs[:, 1]
theta_np_deg = math.degrees(math.atan2(float(v_max[1]), float(v_max[0])))


def normalize_theta(t):
    while t >= 90.0:
        t -= 180.0
    while t < -90.0:
        t += 180.0
    return t


check("sigma_max vs numpy", s["sigma_max"], sigma_max_np)
check("sigma_min vs numpy", s["sigma_min"], sigma_min_np)
check("theta_deg vs numpy",
      normalize_theta(s["theta_deg"]),
      normalize_theta(theta_np_deg))


# ===========================================================================
# PARTE B - REGRESSION dei casi planimetrici noti
# ===========================================================================
header("PARTE B.1 - Quadrato unitario centrato")
acc, pts = feed([(-1, -1), (1, -1), (1, 1), (-1, 1)])
s = derived_stats(acc, pts)
check("n",            s["n"],            4)
check("mean_x",       s["mean_x"],       0.0)
check("mean_y",       s["mean_y"],       0.0)
check("sigma_x",      s["sigma_x"],      math.sqrt(4 / 3))
check("sigma_y",      s["sigma_y"],      math.sqrt(4 / 3))
check("sigma_xy",     s["sigma_xy"],     0.0, tol=1e-15)
check("sigma_p",      s["sigma_p"],      math.sqrt(8 / 3))
check("rmsd_2d",      s["rmsd_2d"],      math.sqrt(2.0))
check("max_dist_2d",  s["max_dist_2d"],  math.sqrt(2.0))
check("sigma_max",    s["sigma_max"],    math.sqrt(4 / 3))
check("sigma_min",    s["sigma_min"],    math.sqrt(4 / 3))
check("anisotropy",   s["anisotropy"],   1.0)

header("PARTE B.2 - Tre punti collineari su y=x")
acc, pts = feed([(0, 0), (1, 1), (2, 2)])
s = derived_stats(acc, pts)
check("sigma_x",   s["sigma_x"],   1.0)
check("sigma_y",   s["sigma_y"],   1.0)
check("sigma_xy",  s["sigma_xy"],  1.0)
check("sigma_p",   s["sigma_p"],   math.sqrt(2.0))
check("sigma_max", s["sigma_max"], math.sqrt(2.0))
check("sigma_min", s["sigma_min"], 0.0)
check("theta_deg", s["theta_deg"], 45.0)
ok = (s["anisotropy"] is None)
print(f"  [{'OK ' if ok else 'FAIL'}] anisotropy is None se sigma_min=0")
results.append(ok)


# ===========================================================================
# PARTE C - STABILITA' Welford su UTM
# ===========================================================================
header("PARTE C - 5000 punti su coordinate UTM (E=500000, N=4500000)")
rng = np.random.default_rng(20260526)
arr = rng.normal(loc=[500000.0, 4500000.0],
                 scale=[0.05, 0.05], size=(5000, 2))
acc, pts = feed([tuple(p) for p in arr.tolist()])
s = derived_stats(acc, pts)
# Tolleranza 1e-9: differenza Welford vs two-pass ~10^-11 (sub-nanometro)
check("mean_x",   s["mean_x"],   float(arr[:, 0].mean()), tol=1e-9)
check("mean_y",   s["mean_y"],   float(arr[:, 1].mean()), tol=1e-9)
check("sigma_x",  s["sigma_x"],  float(arr[:, 0].std(ddof=1)), tol=1e-9)
check("sigma_y",  s["sigma_y"],  float(arr[:, 1].std(ddof=1)), tol=1e-9)
check("sigma_xy", s["sigma_xy"], float(np.cov(arr.T, ddof=1)[0, 1]), tol=1e-9)


# ===========================================================================
# PARTE D - Autovalori 2x2 closed-form vs numpy.linalg.eigh
# ===========================================================================
header("PARTE D - Nuvola ellittica ruotata di 30 deg, anisotropia ~3:1")
rng2 = np.random.default_rng(12345)
N = 2000
raw = rng2.normal(size=(N, 2)) * np.array([3.0, 1.0])
ang = math.radians(30)
R = np.array([[math.cos(ang), -math.sin(ang)],
              [math.sin(ang),  math.cos(ang)]])
arr = (raw @ R.T) + np.array([100.0, 200.0])
acc, pts = feed([tuple(p) for p in arr.tolist()])
s = derived_stats(acc, pts)

cov_np = np.cov(arr.T, ddof=1)
eigvals_np, eigvecs_np = np.linalg.eigh(cov_np)
sigma_max_np = math.sqrt(float(eigvals_np[1]))
sigma_min_np = math.sqrt(float(eigvals_np[0]))
v_max = eigvecs_np[:, 1]
theta_np = normalize_theta(
    math.degrees(math.atan2(float(v_max[1]), float(v_max[0])))
)

check("sigma_max", s["sigma_max"], sigma_max_np, tol=1e-12)
check("sigma_min", s["sigma_min"], sigma_min_np, tol=1e-12)
check("theta_deg", normalize_theta(s["theta_deg"]), theta_np, tol=1e-9)
print(f"  Anisotropia: {s['anisotropy']:.4f}  (atteso ~ 3.0)")


# ===========================================================================
# PARTE E - Percentile e ellisse
# ===========================================================================
header("PARTE E.1 - R95 e max_dist vs numpy")
d_planim = np.linalg.norm(arr - np.array([s["mean_x"], s["mean_y"]]), axis=1)
check("R95_2d", s["R95_2d"], float(np.percentile(d_planim, 95)), tol=1e-12)
check("max_dist_2d", s["max_dist_2d"], float(d_planim.max()), tol=1e-12)

header("PARTE E.2 - Generazione ellisse: vertici, chiusura, area, rotazione")
coords = _ellipse_coords(0.0, 0.0, 2.0, 1.0, 0.0, scale=1.0, n_vertices=72)
check("primo vertice x (a, 0)",         coords[0][0], 2.0)
check("primo vertice y (a, 0)",         coords[0][1], 0.0, tol=1e-15)
check("ring chiuso x",                  coords[-1][0], coords[0][0])
check("ring chiuso y",                  coords[-1][1], coords[0][1])

xs = [c[0] for c in coords[:-1]]
ys = [c[1] for c in coords[:-1]]
n_v = len(xs)
area = 0.5 * abs(sum(xs[i] * ys[(i + 1) % n_v] - xs[(i + 1) % n_v] * ys[i]
                     for i in range(n_v)))
print(f"  Area shoelace 72 vertici: {area:.6f}  (pi*a*b = {2*math.pi:.6f})")
check("area ellisse ~ pi*a*b (tol 1%)", area, 2 * math.pi, tol=0.01)

# n_vertices grande: l'area deve avvicinarsi
coords_fine = _ellipse_coords(0.0, 0.0, 2.0, 1.0, 0.0,
                              scale=1.0, n_vertices=720)
xs = [c[0] for c in coords_fine[:-1]]
ys = [c[1] for c in coords_fine[:-1]]
n_v = len(xs)
area_fine = 0.5 * abs(sum(xs[i] * ys[(i + 1) % n_v] - xs[(i + 1) % n_v] * ys[i]
                          for i in range(n_v)))
print(f"  Area shoelace 720 vertici: {area_fine:.8f}")
check("area ellisse 720v ~ pi*a*b (tol 1e-4)",
      area_fine, 2 * math.pi, tol=1e-4)

# Rotazione 90 deg: primo vertice a (0, a)
coords = _ellipse_coords(0.0, 0.0, 2.0, 1.0, math.radians(90))
check("ellisse 90deg primo x", coords[0][0], 0.0, tol=1e-12)
check("ellisse 90deg primo y", coords[0][1], 2.0, tol=1e-12)

# Centro non-zero: shift di 10, 20
coords = _ellipse_coords(10.0, 20.0, 2.0, 1.0, 0.0)
check("ellisse centrata (10,20) primo x", coords[0][0], 12.0)
check("ellisse centrata (10,20) primo y", coords[0][1], 20.0)

# Scala 2 sigma
coords = _ellipse_coords(0.0, 0.0, 2.0, 1.0, 0.0, scale=2.0)
check("ellisse scala 2 sigma primo x", coords[0][0], 4.0)
check("ellisse scala 2 sigma primo y", coords[0][1], 0.0, tol=1e-15)

# Ellisse degenere (sigma_max=sigma_min=0): None
coords = _ellipse_coords(0.0, 0.0, 0.0, 0.0, 0.0)
ok = coords is None
print(f"  [{'OK ' if ok else 'FAIL'}] ellisse degenere (entrambi sigma=0) -> None")
results.append(ok)


# ===========================================================================
# PARTE F - CEP50 e SEP vs grandezze teoriche
# ===========================================================================
header("PARTE F.1 - CEP50 isotropo vs mediana di Rayleigh")
# Per distribuzione gaussiana isotropa con sigma, la distanza al centro
# segue una Rayleigh con scale=sigma. La mediana e' sigma*sqrt(2*ln2) ~ 1.1774
# La formula RAND 0.5614*sigma_max+0.6175*sigma_min con sigma_max=sigma_min=sigma
# da' 1.1789*sigma. Errore: 0.13%.
arr = rng2.normal(size=(10000, 2))
acc, pts = feed([tuple(p) for p in arr.tolist()])
s = derived_stats(acc, pts)
cep_teorico_rayleigh = math.sqrt(2.0 * math.log(2.0))  # = 1.1774
print(f"  sigma_max={s['sigma_max']:.4f}, sigma_min={s['sigma_min']:.4f}")
print(f"  CEP50 formula RAND : {s['CEP50']:.4f}")
print(f"  CEP50 Rayleigh teor: {cep_teorico_rayleigh:.4f}")
print(f"  Errore RAND vs Rayleigh: "
      f"{100*(s['CEP50']-cep_teorico_rayleigh)/cep_teorico_rayleigh:.3f} %")
ok = abs(s["CEP50"] - cep_teorico_rayleigh) < 0.02
print(f"  [{'OK ' if ok else 'FAIL'}] CEP50 entro 2 cm dalla teoria isotropa")
results.append(ok)
median_emp = float(np.median(np.linalg.norm(
    arr - np.array([s["mean_x"], s["mean_y"]]), axis=1)))
ok = abs(s["CEP50"] - median_emp) < 0.02
print(f"  Mediana empirica: {median_emp:.4f}")
print(f"  [{'OK ' if ok else 'FAIL'}] CEP50 ~ mediana empirica")
results.append(ok)

header("PARTE F.2 - SEP isotropo vs valore teorico")
# Per gaussiana 3D isotropa, SEP = sigma*sqrt(chi2_inv(0.5, df=3))
# valore teorico ~ 1.5382 sigma. Formula Mood: 0.51*(3*sigma) = 1.53 sigma
# Errore: ~0.5%
arr3d = rng2.normal(size=(10000, 3))
acc, pts = feed([tuple(p) for p in arr3d.tolist()])
s = derived_stats(acc, pts)
sep_teorico = 1.5382  # chi2_inv(0.5, df=3)^0.5
print(f"  sigma_x={s['sigma_x']:.4f}, sigma_y={s['sigma_y']:.4f}, "
      f"sigma_z={s['sigma_z']:.4f}")
print(f"  SEP formula Mood: {s['SEP']:.4f}")
print(f"  SEP teorico chi2: {sep_teorico:.4f}")
print(f"  Errore Mood vs teorico: "
      f"{100*(s['SEP']-sep_teorico)/sep_teorico:.3f} %")
ok = abs(s["SEP"] - sep_teorico) < 0.03
print(f"  [{'OK ' if ok else 'FAIL'}] SEP entro 3 cm dalla teoria isotropa")
results.append(ok)


# ===========================================================================
# PARTE G - EDGE CASES
# ===========================================================================
header("PARTE G.1 - n=1 (singolo punto): tutti i sigma = 0")
acc, pts = feed([(42.0, 17.0, 100.0)])
s = derived_stats(acc, pts)
check("n",            s["n"],            1)
check("n_z",          s["n_z"],          1)
check("mean_x",       s["mean_x"],       42.0)
check("mean_y",       s["mean_y"],       17.0)
check("mean_z",       s["mean_z"],       100.0)
check("sigma_x",      s["sigma_x"],      0.0)
check("sigma_y",      s["sigma_y"],      0.0)
check("sigma_z",      s["sigma_z"],      0.0)
check("sigma_p",      s["sigma_p"],      0.0)
check("sigma_3d",     s["sigma_3d"],     0.0)
check("CEP50",        s["CEP50"],        0.0)
check("SEP",          s["SEP"],          0.0)
check("max_dist_2d",  s["max_dist_2d"],  0.0)
check("max_dist_3d",  s["max_dist_3d"],  0.0)
check("R95_2d",       s["R95_2d"],       0.0)
check("R95_3d",       s["R95_3d"],       0.0)
ok = (s["anisotropy"] is None)
print(f"  [{'OK ' if ok else 'FAIL'}] anisotropy is None per n=1")
results.append(ok)

header("PARTE G.2 - n=2 (due punti): sigma con denom (n-1)=1")
acc, pts = feed([(0.0, 0.0, 0.0), (2.0, 4.0, 6.0)])
s = derived_stats(acc, pts)
# Medie: 1, 2, 3
# Scarti: (-1,-2,-3) e (1,2,3) -> dx^2=2, dy^2=8, dz^2=18, dx*dy=4
# var_x=2, var_y=8, var_z=18, cov_xy=4 (denom 1)
check("n",          s["n"],          2)
check("mean_x",     s["mean_x"],     1.0)
check("mean_y",     s["mean_y"],     2.0)
check("mean_z",     s["mean_z"],     3.0)
check("sigma_x",    s["sigma_x"],    math.sqrt(2.0))
check("sigma_y",    s["sigma_y"],    math.sqrt(8.0))
check("sigma_z",    s["sigma_z"],    math.sqrt(18.0))
check("sigma_xy",   s["sigma_xy"],   4.0)
check("sigma_p",    s["sigma_p"],    math.sqrt(10.0))
check("sigma_3d",   s["sigma_3d"],   math.sqrt(28.0))
# autovalori della cov [[2,4],[4,8]]: tr=10, det=0 -> lam=10, 0
check("sigma_max",  s["sigma_max"],  math.sqrt(10.0))
check("sigma_min",  s["sigma_min"],  0.0)

header("PARTE G.3 - Layer 3D dichiarato ma TUTTI i Z = NaN")
# Simula vertici 3D con z=NaN (il codice li tratta come None -> n_z=0)
acc = RunningStats3D()
pts = []
nan = float("nan")
for x, y in [(0, 0), (1, 0), (0, 1), (1, 1)]:
    acc.add(x, y, nan)
    pts.append((x, y, nan))
s = derived_stats(acc, pts)
check("n",        s["n"],        4)
check("n_z",      s["n_z"],      0)
ok = (s["mean_z"] is None and s["sigma_z"] is None and
      s["sigma_3d"] is None and s["SEP"] is None)
print(f"  [{'OK ' if ok else 'FAIL'}] tutti i campi 3D = None quando z=NaN")
results.append(ok)
# planim. correttamente calcolate
check("sigma_x", s["sigma_x"], math.sqrt(1.0 / 3.0))
check("sigma_y", s["sigma_y"], math.sqrt(1.0 / 3.0))

header("PARTE G.4 - Anisotropia estrema (10:1)")
rng3 = np.random.default_rng(99)
raw = rng3.normal(size=(5000, 2)) * np.array([10.0, 1.0])
arr = raw + np.array([1000.0, 2000.0])
acc, pts = feed([tuple(p) for p in arr.tolist()])
s = derived_stats(acc, pts)
cov_np = np.cov(arr.T, ddof=1)
eigvals_np, _ = np.linalg.eigh(cov_np)
sigma_max_np = math.sqrt(float(eigvals_np[1]))
sigma_min_np = math.sqrt(float(eigvals_np[0]))
check("sigma_max vs numpy", s["sigma_max"], sigma_max_np, tol=1e-12)
check("sigma_min vs numpy", s["sigma_min"], sigma_min_np, tol=1e-12)
print(f"  Anisotropia: {s['anisotropy']:.4f}  (atteso ~ 10)")
# CEP50 deve scendere rispetto al caso isotropo (essendo l'ellisse molto sottile)
print(f"  CEP50: {s['CEP50']:.4f}")
print(f"  sigma_max: {s['sigma_max']:.4f}, sigma_min: {s['sigma_min']:.4f}")


# ===========================================================================
# PARTE H - 3D MISTO
# ===========================================================================
header("PARTE H - 3D misto: 3 punti con Z + 2 senza Z (None)")
pts3d = [
    (0.0, 0.0, 10.0),
    (1.0, 0.0, 11.0),
    (0.0, 1.0, 12.0),
    (1.0, 1.0, None),
    (0.5, 0.5, None),
]
acc, pts = feed(pts3d)
s = derived_stats(acc, pts)
check("n",   s["n"],   5)
check("n_z", s["n_z"], 3)
# planim. su n=5
mx_exp = 0.5
my_exp = 0.5
sx_exp = math.sqrt(sum((p[0] - mx_exp) ** 2 for p in pts3d) / 4)
sy_exp = math.sqrt(sum((p[1] - my_exp) ** 2 for p in pts3d) / 4)
check("mean_x", s["mean_x"], mx_exp, tol=1e-12)
check("mean_y", s["mean_y"], my_exp, tol=1e-12)
check("sigma_x", s["sigma_x"], sx_exp, tol=1e-12)
check("sigma_y", s["sigma_y"], sy_exp, tol=1e-12)
# altim. su subset n_z=3
zs = [10.0, 11.0, 12.0]
sz_exp = float(np.std(zs, ddof=1))
mz_exp = sum(zs) / 3
check("mean_z",  s["mean_z"],  mz_exp, tol=1e-12)
check("sigma_z", s["sigma_z"], sz_exp, tol=1e-12)
# rmsd_3d e max_dist_3d sul subset
subset3d = np.array([[0, 0, 10], [1, 0, 11], [0, 1, 12]], dtype=float)
mxyz_sub = subset3d.mean(axis=0)
d3_sub = np.linalg.norm(subset3d - mxyz_sub, axis=1)
check("rmsd_3d",     s["rmsd_3d"],
      float(math.sqrt((d3_sub ** 2).mean())), tol=1e-12)
check("max_dist_3d", s["max_dist_3d"], float(d3_sub.max()), tol=1e-12)

header("PARTE H.2 - 3D misto: alcuni Z=NaN, alcuni z=None, alcuni validi")
acc = RunningStats3D()
pts = []
data = [(0, 0, 10.0), (1, 0, None), (0, 1, float("nan")),
        (1, 1, 12.0), (0.5, 0.5, 14.0)]
for x, y, z in data:
    acc.add(x, y, z)
    pts.append((x, y, z))
s = derived_stats(acc, pts)
check("n",      s["n"],   5)
check("n_z",    s["n_z"], 3)
zs_valid = [10.0, 12.0, 14.0]
check("mean_z", s["mean_z"], sum(zs_valid) / 3)
check("sigma_z", s["sigma_z"], float(np.std(zs_valid, ddof=1)))


# ===========================================================================
# PARTE I - CASO TOPOGRAFICO REALE: GNSS, 5 rilievi statici
# ===========================================================================
header("PARTE I - GNSS 5 rilievi (UTM, metri)")
pts3d = [
    (500000.123, 4500000.045, 152.310),
    (500000.097, 4500000.082, 152.295),
    (500000.156, 4500000.011, 152.328),
    (500000.108, 4500000.067, 152.301),
    (500000.142, 4500000.038, 152.319),
]
acc, pts = feed(pts3d)
s = derived_stats(acc, pts)
print(f"  Centroide: E={s['mean_x']:.3f}  N={s['mean_y']:.3f}  "
      f"Q={s['mean_z']:.3f}")
print(f"  sigma_x = {s['sigma_x']*1000:6.2f} mm")
print(f"  sigma_y = {s['sigma_y']*1000:6.2f} mm")
print(f"  sigma_z = {s['sigma_z']*1000:6.2f} mm")
print(f"  EQMP    = {s['sigma_p']*1000:6.2f} mm  (planimetrico)")
print(f"  EQMS    = {s['sigma_3d']*1000:6.2f} mm  (sferico 3D)")
print(f"  CEP50   = {s['CEP50']*1000:6.2f} mm")
print(f"  SEP     = {s['SEP']*1000:6.2f} mm")
print(f"  R95_2d  = {s['R95_2d']*1000:6.2f} mm")
print(f"  R95_3d  = {s['R95_3d']*1000:6.2f} mm")
print(f"  Ellisse: sigma_max={s['sigma_max']*1000:.2f} mm  "
      f"sigma_min={s['sigma_min']*1000:.2f} mm  "
      f"theta={s['theta_deg']:.1f} deg")
print(f"  Anisotropia: {s['anisotropy']:.3f}")

arr = np.array(pts3d)
sx_np = float(arr[:, 0].std(ddof=1))
sy_np = float(arr[:, 1].std(ddof=1))
sz_np = float(arr[:, 2].std(ddof=1))
check("sigma_x vs numpy", s["sigma_x"], sx_np, tol=1e-9)
check("sigma_y vs numpy", s["sigma_y"], sy_np, tol=1e-9)
check("sigma_z vs numpy", s["sigma_z"], sz_np, tol=1e-9)
check("EQMP    vs numpy", s["sigma_p"],
      math.sqrt(sx_np ** 2 + sy_np ** 2), tol=1e-9)
check("EQMS    vs numpy", s["sigma_3d"],
      math.sqrt(sx_np ** 2 + sy_np ** 2 + sz_np ** 2), tol=1e-9)


# ===========================================================================
# PARTE J - Invarianza per traslazione 3D
# ===========================================================================
header("PARTE J - Invarianza per traslazione 3D di (10^6, 2*10^6, 10^3)")
pts0 = [(0.1, 0.2, 1.0), (0.3, 0.5, 1.5), (-0.4, 0.1, 0.8),
        (0.0, -0.3, 1.2), (0.2, 0.4, 0.9)]
acc0, pa = feed(pts0)
s0 = derived_stats(acc0, pa)
DX, DY, DZ = 1.0e6, 2.0e6, 1.0e3
pts1 = [(x + DX, y + DY, z + DZ) for x, y, z in pts0]
acc1, pb = feed(pts1)
s1 = derived_stats(acc1, pb)
for k in ("sigma_x", "sigma_y", "sigma_z", "sigma_xy",
          "sigma_p", "sigma_3d",
          "sigma_max", "sigma_min", "CEP50", "SEP",
          "R95_2d", "R95_3d", "rmsd_2d", "rmsd_3d"):
    check(f"{k} invariante", s1[k], s0[k], tol=1e-6)


# ===========================================================================
# Resoconto
# ===========================================================================
print("\n" + "=" * 78)
total = len(results)
passed = sum(results)
print(f"RISULTATO: {passed}/{total} controlli superati")
print("=" * 78)
sys.exit(0 if passed == total else 1)
