# -*- coding: utf-8 -*-
"""
Scarto quadratico medio coordinate XYZ (per gruppo, espressione o selezione)
============================================================================

QGIS Processing script. Per ciascun gruppo di punti (intero layer, selezione,
valore di un campo, o espressione QGIS) calcola statistiche di dispersione
planimetrica e altimetrica secondo la convenzione topografica italiana.

PLANIMETRIA (sempre disponibile)
    sigma_x, sigma_y         SQM campionari delle coordinate (denom. n-1)
    sigma_xy                 covarianza campionaria xy (denom. n-1)
    sigma_p = sqrt(sx^2+sy^2)  errore quadratico medio planimetrico (EQMP)
    sigma_max, sigma_min     semiassi dell'ellisse di deviazione standard
                             (autovalori della matrice di covarianza 2D)
    theta_deg                orientamento dell'asse maggiore in gradi
                             (0 = est, antiorario)
    anisotropy = sigma_max/sigma_min
    CEP50                    Circular Error Probable 50% (RAND:
                             0.5614*sigma_max + 0.6175*sigma_min)
    R95_2d                   95-esimo percentile empirico delle distanze
                             planimetriche dal centroide
    max_dist_2d, rmsd_2d     come da convenzione topografica

ALTIMETRIA (se almeno un punto del gruppo ha Z valido)
    n_z                      n. di punti con Z definito
    mean_z, sigma_z          quota media e SQM (denom. n_z-1)
    sigma_3d                 errore quadratico medio sferico, calcolato sul
                             SUBSET dei punti con Z (coerente con sigma_z)
    SEP                      Spherical Error Probable ~ 0.51*(sx+sy+sz)
                             nel subset 3D
    R95_3d, max_dist_3d, rmsd_3d   analoghi 3D

ALGORITMO
    Accumulatore online di Welford-Knuth-Chan in O(1) per punto e O(K) per
    gruppo, numericamente stabile su coordinate UTM. Due sub-accumulatori
    indipendenti gestiscono il caso di layer 3D misti (alcuni punti senza Z).

OTTIMIZZAZIONI
    - QgsFeatureRequest con subset di attributi (o NoAttributes)
    - Welford in singola passata
    - Espressione QGIS opzionale per chiavi di raggruppamento complesse
    - Statistiche derivate (autovalori, percentili, ellisse) come funzioni
      pure top-level, testabili fuori dall'ambiente QGIS.

NOTA SU QVariant
    In QGIS 3.38+ QVariant.* per i tipi di campo e' deprecato a favore di
    QMetaType. Lo script funziona ovunque su QGIS 3.x; verra' adattato a
    QMetaType al passaggio a QGIS 4 (la sostituzione e' meccanica).
"""

import math
from collections import defaultdict

from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsExpression,
    QgsExpressionContext,
    QgsExpressionContextUtils,
    QgsFeature,
    QgsFeatureRequest,
    QgsFeatureSink,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsPoint,
    QgsPointXY,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterExpression,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsProcessingParameterNumber,
    QgsWkbTypes,
)


# ============================================================================
# Logica numerica top-level (testabile fuori QGIS)
# ============================================================================
class RunningStats3D:
    """
    Accumulatore online di Welford-Chan per statistiche XY (sempre) e Z
    (quando disponibile).

    Tiene DUE sub-accumulatori indipendenti:
      - 2D pieno: aggiornato per ogni punto
      - 3D-subset: aggiornato solo per i punti con z valido

    In questo modo le statistiche planimetriche restano coerenti con TUTTE
    le osservazioni del gruppo, mentre quelle altimetriche e sferiche sono
    coerenti tra loro (stessa numerosita' n_z, stessa media (mx_z, my_z, mz)).

    Numericamente stabile su coordinate UTM/Gauss-Boaga: nessuna formula
    "somma quadrati - n*media^2".
    """

    __slots__ = (
        "n", "mx", "my", "M_x", "M_y", "C_xy",
        "n_z", "mx_z", "my_z", "mz", "M_x_z", "M_y_z", "M_z",
    )

    def __init__(self):
        # 2D pieno
        self.n = 0
        self.mx = 0.0
        self.my = 0.0
        self.M_x = 0.0
        self.M_y = 0.0
        self.C_xy = 0.0
        # 3D-subset
        self.n_z = 0
        self.mx_z = 0.0
        self.my_z = 0.0
        self.mz = 0.0
        self.M_x_z = 0.0
        self.M_y_z = 0.0
        self.M_z = 0.0

    def add(self, x, y, z=None):
        # ---- aggiornamento 2D pieno
        self.n += 1
        n = self.n
        dx = x - self.mx
        self.mx += dx / n
        dx2 = x - self.mx
        self.M_x += dx * dx2

        dy = y - self.my
        self.my += dy / n
        dy2 = y - self.my
        self.M_y += dy * dy2

        # Welford per covarianza (stabile):
        #   C_xy_new = C_xy_old + (x_new - mean_x_old) * (y_new - mean_y_new)
        self.C_xy += dx * dy2

        # ---- aggiornamento 3D-subset (solo se z valido)
        if z is None:
            return
        if isinstance(z, float) and math.isnan(z):
            return

        self.n_z += 1
        nz = self.n_z
        dxz = x - self.mx_z
        self.mx_z += dxz / nz
        self.M_x_z += dxz * (x - self.mx_z)

        dyz = y - self.my_z
        self.my_z += dyz / nz
        self.M_y_z += dyz * (y - self.my_z)

        dz = z - self.mz
        self.mz += dz / nz
        self.M_z += dz * (z - self.mz)

    # ----- accessor

    @property
    def has_z(self):
        return self.n_z > 0

    def variances_2d(self):
        """(var_x, var_y, cov_xy) sull'insieme pieno, stimatori campionari."""
        if self.n < 2:
            return 0.0, 0.0, 0.0
        denom = self.n - 1
        return self.M_x / denom, self.M_y / denom, self.C_xy / denom

    def variances_3d_subset(self):
        """(var_x_3d, var_y_3d, var_z) sul subset Z, stimatori campionari."""
        if self.n_z < 2:
            return 0.0, 0.0, 0.0
        denom = self.n_z - 1
        return (self.M_x_z / denom,
                self.M_y_z / denom,
                self.M_z   / denom)


def _percentile_sqrt(squared_values, p):
    """
    Percentile p (0-100) di sqrt(squared_values) con interpolazione lineare
    tra ranghi adiacenti (come numpy.percentile, interpolation='linear').
    Lavora sui quadrati per evitare sqrt inutili.
    """
    if not squared_values:
        return 0.0
    arr = sorted(squared_values)
    k = (len(arr) - 1) * (p / 100.0)
    f = int(math.floor(k))
    c = int(math.ceil(k))
    if f == c:
        return math.sqrt(arr[f])
    return (math.sqrt(arr[f]) * (c - k) +
            math.sqrt(arr[c]) * (k - f))


def derived_stats(acc, points):
    """
    Dato un accumulatore RunningStats3D finalizzato e la lista dei punti
    (x, y, z_or_None) del gruppo, restituisce un dict con tutte le
    statistiche di output.
    """
    n = acc.n
    out = {"n": n, "mean_x": acc.mx, "mean_y": acc.my}

    # ---- varianze planimetriche e sigma
    var_x, var_y, cov_xy = acc.variances_2d()
    out["sigma_x"]  = math.sqrt(max(var_x, 0.0))
    out["sigma_y"]  = math.sqrt(max(var_y, 0.0))
    out["sigma_xy"] = cov_xy
    out["sigma_p"]  = math.sqrt(max(var_x + var_y, 0.0))

    # ---- autovalori della matrice di covarianza 2x2 (closed-form)
    if n >= 2:
        tr   = var_x + var_y
        diff = var_x - var_y
        disc = math.sqrt(max((diff * 0.5) ** 2 + cov_xy ** 2, 0.0))
        lam_max = tr * 0.5 + disc
        lam_min = tr * 0.5 - disc
        sigma_max = math.sqrt(max(lam_max, 0.0))
        sigma_min = math.sqrt(max(lam_min, 0.0))
        # angolo dell'autovettore associato a lam_max rispetto all'asse x
        theta = 0.5 * math.atan2(2.0 * cov_xy, diff)
        theta_deg = math.degrees(theta)
    else:
        sigma_max = sigma_min = theta_deg = 0.0

    out["sigma_max"]  = sigma_max
    out["sigma_min"]  = sigma_min
    out["theta_deg"]  = theta_deg
    out["anisotropy"] = (sigma_max / sigma_min) if sigma_min > 0 else None

    # ---- CEP50 (RAND): valido fino a forte anisotropia
    out["CEP50"] = 0.5614 * sigma_max + 0.6175 * sigma_min

    # ---- distanze planimetriche
    d2_sq = [(p[0] - acc.mx) ** 2 + (p[1] - acc.my) ** 2 for p in points]
    out["max_dist_2d"] = math.sqrt(max(d2_sq)) if d2_sq else 0.0
    out["rmsd_2d"]     = math.sqrt(sum(d2_sq) / n) if n > 0 else 0.0
    out["R95_2d"]      = _percentile_sqrt(d2_sq, 95.0)

    # ---- altimetria (subset 3D)
    if acc.has_z:
        var_x_3d, var_y_3d, var_z = acc.variances_3d_subset()
        sigma_x_3d = math.sqrt(max(var_x_3d, 0.0))
        sigma_y_3d = math.sqrt(max(var_y_3d, 0.0))
        sigma_z    = math.sqrt(max(var_z, 0.0))

        out["n_z"]      = acc.n_z
        out["mean_z"]   = acc.mz
        out["sigma_z"]  = sigma_z
        out["sigma_3d"] = math.sqrt(
            max(var_x_3d + var_y_3d + var_z, 0.0))
        out["SEP"]      = 0.51 * (sigma_x_3d + sigma_y_3d + sigma_z)

        d3_sq = []
        for p in points:
            z = p[2]
            if z is None:
                continue
            if isinstance(z, float) and math.isnan(z):
                continue
            d3_sq.append(
                (p[0] - acc.mx_z) ** 2 +
                (p[1] - acc.my_z) ** 2 +
                (z    - acc.mz)   ** 2
            )
        out["max_dist_3d"] = math.sqrt(max(d3_sq)) if d3_sq else 0.0
        out["rmsd_3d"]     = math.sqrt(sum(d3_sq) / len(d3_sq)) if d3_sq else 0.0
        out["R95_3d"]      = _percentile_sqrt(d3_sq, 95.0)
    else:
        out["n_z"]         = 0
        out["mean_z"]      = None
        out["sigma_z"]     = None
        out["sigma_3d"]    = None
        out["SEP"]         = None
        out["max_dist_3d"] = None
        out["rmsd_3d"]     = None
        out["R95_3d"]      = None

    return out


def _ellipse_coords(cx, cy, sigma_max, sigma_min, theta_rad,
                    scale=1.0, n_vertices=72):
    """
    Genera la lista [(x, y), ...] di vertici di un'ellisse di deviazione
    standard, chiusa (primo == ultimo). Ritorna None se l'ellisse e' degenere.
    """
    if sigma_max <= 0.0 and sigma_min <= 0.0:
        return None
    a = sigma_max * scale
    b = sigma_min * scale
    cos_t = math.cos(theta_rad)
    sin_t = math.sin(theta_rad)
    coords = []
    for i in range(n_vertices):
        ang = 2.0 * math.pi * i / n_vertices
        xl = a * math.cos(ang)
        yl = b * math.sin(ang)
        coords.append((
            cx + xl * cos_t - yl * sin_t,
            cy + xl * sin_t + yl * cos_t,
        ))
    coords.append(coords[0])
    return coords


# ============================================================================
# Processing algorithm
# ============================================================================
class CoordinateStandardDeviation(QgsProcessingAlgorithm):

    INPUT              = "INPUT"
    GROUP_FIELD        = "GROUP_FIELD"
    GROUP_EXPRESSION   = "GROUP_EXPRESSION"
    INCLUDE_NULL_GROUP = "INCLUDE_NULL_GROUP"
    ELLIPSE_SCALE      = "ELLIPSE_SCALE"
    OUTPUT             = "OUTPUT"
    OUTPUT_ELLIPSES    = "OUTPUT_ELLIPSES"

    # --------------------------------------------------------------- UI

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT,
            "Layer puntuale (CRS proiettato; supporta Z)",
            [QgsProcessing.TypeVectorPoint],
        ))
        self.addParameter(QgsProcessingParameterField(
            self.GROUP_FIELD,
            "Campo di raggruppamento (opzionale)",
            parentLayerParameterName=self.INPUT,
            optional=True,
        ))
        self.addParameter(QgsProcessingParameterExpression(
            self.GROUP_EXPRESSION,
            "Espressione di raggruppamento (prevale sul campo, opzionale)",
            parentLayerParameterName=self.INPUT,
            optional=True,
        ))
        self.addParameter(QgsProcessingParameterBoolean(
            self.INCLUDE_NULL_GROUP,
            "Includi feature con chiave di raggruppamento NULL",
            defaultValue=True,
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.ELLIPSE_SCALE,
            "Fattore moltiplicativo per i semiassi dell'ellisse "
            "(default 1.0 = ellisse standard; 2.448 = confidenza 95 %)",
            type=QgsProcessingParameterNumber.Double,
            defaultValue=1.0,
            minValue=0.0001,
        ))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT,
            "Centroidi con statistiche",
        ))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_ELLIPSES,
            "Ellissi di deviazione standard (planimetriche)",
            optional=True,
            createByDefault=True,
        ))

    # --------------------------------------------------------- esecuzione

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, self.INPUT, context)
        if source is None:
            raise QgsProcessingException("Layer di input non valido")

        crs = source.sourceCrs()
        if crs.isGeographic():
            feedback.pushWarning(
                "ATTENZIONE: il CRS del layer e' geografico. Le statistiche "
                "metriche saranno espresse in gradi: riproiettare in un CRS "
                "proiettato per ottenere valori in metri."
            )

        group_field = (self.parameterAsString(
            parameters, self.GROUP_FIELD, context) or "").strip() or None
        group_expr_str = (self.parameterAsString(
            parameters, self.GROUP_EXPRESSION, context) or "").strip() or None
        include_null = self.parameterAsBoolean(
            parameters, self.INCLUDE_NULL_GROUP, context)
        ellipse_scale = self.parameterAsDouble(
            parameters, self.ELLIPSE_SCALE, context)

        # ------ Feature request con subset di attributi
        request = QgsFeatureRequest()
        group_field_idx = -1
        group_expr = None
        if group_expr_str:
            group_expr = QgsExpression(group_expr_str)
            if group_expr.hasParserError():
                raise QgsProcessingException(
                    "Espressione non valida: " + group_expr.parserErrorString())
            needed = list(group_expr.referencedAttributeIndexes(source.fields()))
            if needed:
                request.setSubsetOfAttributes(needed)
        elif group_field:
            group_field_idx = source.fields().indexFromName(group_field)
            if group_field_idx < 0:
                raise QgsProcessingException(
                    "Campo di raggruppamento '{}' non trovato".format(group_field))
            request.setSubsetOfAttributes([group_field_idx])
        else:
            request.setNoAttributes()

        # ------ Output Z handling
        layer_has_z = QgsWkbTypes.hasZ(source.wkbType())

        # ------ Expression context
        expr_ctx = None
        if group_expr is not None:
            expr_ctx = QgsExpressionContext()
            expr_ctx.appendScopes(
                QgsExpressionContextUtils.globalProjectLayerScopes(None))
            group_expr.prepare(expr_ctx)

        # ------ Schema centroidi
        # Primo campo SEMPRE 'group_by' (stringa) per uniformare la tabella
        # tra modalita' "campo", "espressione" e "selezione/tutti".
        out_fields = QgsFields()
        out_fields.append(QgsField("group_by", QVariant.String))
        for fname in ("n", "n_z"):
            out_fields.append(QgsField(fname, QVariant.Int))
        for fname in ("mean_x", "mean_y", "mean_z",
                      "sigma_x", "sigma_y", "sigma_z", "sigma_xy",
                      "sigma_p", "sigma_3d",
                      "sigma_max", "sigma_min", "theta_deg",
                      "anisotropy", "CEP50", "SEP",
                      "R95_2d", "R95_3d",
                      "max_dist_2d", "max_dist_3d",
                      "rmsd_2d", "rmsd_3d"):
            out_fields.append(QgsField(fname, QVariant.Double))

        centroid_wkb = QgsWkbTypes.PointZ if layer_has_z else QgsWkbTypes.Point
        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT, context,
            out_fields, centroid_wkb, crs,
        )
        if sink is None:
            raise QgsProcessingException("Sink centroidi non valido")

        # ------ Schema ellissi
        ell_fields = QgsFields()
        ell_fields.append(QgsField("group_by",   QVariant.String))
        ell_fields.append(QgsField("n",          QVariant.Int))
        ell_fields.append(QgsField("sigma_max",  QVariant.Double))
        ell_fields.append(QgsField("sigma_min",  QVariant.Double))
        ell_fields.append(QgsField("theta_deg",  QVariant.Double))
        ell_fields.append(QgsField("scale",      QVariant.Double))

        ell_sink, ell_dest_id = self.parameterAsSink(
            parameters, self.OUTPUT_ELLIPSES, context,
            ell_fields, QgsWkbTypes.Polygon, crs,
        )  # ell_sink puo' essere None se output disattivato

        # ------ Passata di accumulo
        accs    = defaultdict(RunningStats3D)
        pts_buf = defaultdict(list)   # serve a max_dist/percentili
        n_null_skipped = 0
        n_empty_geom   = 0

        total = source.featureCount() or 0
        step  = 100.0 / total if total else 0.0

        for i, feat in enumerate(source.getFeatures(request)):
            if feedback.isCanceled():
                break

            geom = feat.geometry()
            if geom is None or geom.isEmpty():
                n_empty_geom += 1
                continue

            if group_expr is not None:
                expr_ctx.setFeature(feat)
                key = group_expr.evaluate(expr_ctx)
                if group_expr.hasEvalError():
                    feedback.pushWarning(
                        "Errore valutazione espressione: " +
                        group_expr.evalErrorString())
                    continue
            elif group_field:
                key = feat[group_field]
            else:
                key = "<all features>"

            if key is None or (isinstance(key, str) and key == ""):
                if not include_null:
                    n_null_skipped += 1
                    continue
                key = "<NULL>"

            has_z_geom = geom.constGet().is3D()
            for v in geom.vertices():
                x = v.x()
                y = v.y()
                z = v.z() if has_z_geom else None
                if z is not None and math.isnan(z):
                    z = None
                accs[key].add(x, y, z)
                pts_buf[key].append((x, y, z))

            if step:
                feedback.setProgress(int(i * step))

        if not accs:
            raise QgsProcessingException(
                "Nessuna feature elaborabile (controllare selezione/filtri)")

        if n_null_skipped:
            feedback.pushInfo(
                "Feature scartate (chiave gruppo NULL): {}".format(n_null_skipped))
        if n_empty_geom:
            feedback.pushInfo(
                "Feature scartate (geometria nulla/vuota): {}".format(n_empty_geom))

        # ------ Emissione centroidi ed ellissi
        ngroups = len(accs)
        for j, (key, acc) in enumerate(accs.items()):
            if feedback.isCanceled():
                break

            stats = derived_stats(acc, pts_buf[key])

            # --- geometria centroide
            if layer_has_z:
                mz = stats["mean_z"] if stats["mean_z"] is not None else 0.0
                geom_out = QgsGeometry(QgsPoint(stats["mean_x"],
                                                stats["mean_y"], mz))
            else:
                geom_out = QgsGeometry.fromPointXY(QgsPointXY(
                    stats["mean_x"], stats["mean_y"]))

            feat_out = QgsFeature(out_fields)
            feat_out.setGeometry(geom_out)

            # Chiave di raggruppamento sempre come stringa
            key_attr = key if isinstance(key, str) else str(key)

            feat_out.setAttributes([
                key_attr,
                stats["n"], stats["n_z"],
                stats["mean_x"], stats["mean_y"], stats["mean_z"],
                stats["sigma_x"], stats["sigma_y"], stats["sigma_z"],
                stats["sigma_xy"], stats["sigma_p"], stats["sigma_3d"],
                stats["sigma_max"], stats["sigma_min"], stats["theta_deg"],
                stats["anisotropy"], stats["CEP50"], stats["SEP"],
                stats["R95_2d"], stats["R95_3d"],
                stats["max_dist_2d"], stats["max_dist_3d"],
                stats["rmsd_2d"], stats["rmsd_3d"],
            ])
            sink.addFeature(feat_out, QgsFeatureSink.FastInsert)

            # Log di debug con coordinate esatte (utile per confronto
            # con qgis:meancoordinates a verifica)
            if stats["n_z"] > 0:
                feedback.pushInfo(
                    "Gruppo '{}': n={} (n_z={}) centroide "
                    "X={:.6f} Y={:.6f} Z={:.6f}".format(
                        key_attr, stats["n"], stats["n_z"],
                        stats["mean_x"], stats["mean_y"], stats["mean_z"]))
            else:
                feedback.pushInfo(
                    "Gruppo '{}': n={} centroide X={:.6f} Y={:.6f}".format(
                        key_attr, stats["n"],
                        stats["mean_x"], stats["mean_y"]))

            # --- ellisse
            if ell_sink is not None and stats["sigma_max"] > 0:
                theta_rad = math.radians(stats["theta_deg"])
                coords = _ellipse_coords(
                    stats["mean_x"], stats["mean_y"],
                    stats["sigma_max"], stats["sigma_min"],
                    theta_rad, scale=ellipse_scale,
                )
                if coords:
                    ring = [QgsPointXY(x, y) for (x, y) in coords]
                    poly_geom = QgsGeometry.fromPolygonXY([ring])
                    ell_feat = QgsFeature(ell_fields)
                    ell_feat.setGeometry(poly_geom)
                    ell_feat.setAttributes([
                        key_attr, stats["n"],
                        stats["sigma_max"], stats["sigma_min"],
                        stats["theta_deg"], ellipse_scale,
                    ])
                    ell_sink.addFeature(ell_feat, QgsFeatureSink.FastInsert)

            feedback.setProgress(int(100 * (j + 1) / ngroups))

        feedback.pushInfo(
            "Elaborati {} gruppi, {} punti totali ({} con Z).".format(
                ngroups,
                sum(a.n for a in accs.values()),
                sum(a.n_z for a in accs.values()),
            )
        )

        result = {self.OUTPUT: dest_id}
        if ell_sink is not None:
            result[self.OUTPUT_ELLIPSES] = ell_dest_id
        return result

    # ----------------------------------------------------------- metadati

    def name(self):
        return "coord_std_dev_xyz"

    def displayName(self):
        return ("Scarto quadratico medio coordinate XYZ "
                "(per gruppo, espressione o selezione)")

    def group(self):
        return "Statistiche punti"

    def groupId(self):
        return "point_statistics"

    def shortHelpString(self):
        return (
            "Calcola statistiche di dispersione planimetrica e altimetrica "
            "per gruppi di punti (intero layer, selezione, valore di un "
            "campo, o espressione QGIS).\n\n"
            "PLANIMETRIA: sigma_x, sigma_y, sigma_xy (campionari, n-1), "
            "sigma_p = sqrt(sx^2+sy^2) (EQMP), autovalori della matrice di "
            "covarianza 2D (sigma_max, sigma_min, theta_deg), anisotropia, "
            "CEP50 (formula RAND), R95 empirico, max_dist, rmsd.\n\n"
            "ALTIMETRIA (se almeno un punto del gruppo ha Z valido): "
            "n_z, mean_z, sigma_z, sigma_3d, SEP, R95_3d, max_dist_3d, "
            "rmsd_3d. Le statistiche 3D sono calcolate sul subset di punti "
            "con Z valido per garantire coerenza tra n, medie e covarianze.\n\n"
            "Raggruppamento (in ordine di priorita'):\n"
            "  1. Espressione QGIS (se specificata)\n"
            "  2. Campo di raggruppamento (se specificato)\n"
            "  3. Toggle 'Selected features only' del parametro layer\n"
            "  4. Tutti i punti del layer in un unico gruppo\n\n"
            "Output:\n"
            "  - Centroidi con tutte le statistiche come attributi\n"
            "  - Ellissi di deviazione standard (opzionale): polilinee "
            "poligonali derivate dagli autovalori della matrice di "
            "covarianza 2D, scalate per il fattore scelto.\n\n"
            "FATTORE MOLTIPLICATIVO DEI SEMIASSI DELL'ELLISSE:\n"
            "Moltiplica entrambi i semiassi (sigma_max e sigma_min). Non "
            "ruota e non sposta l'ellisse, ne cambia solo la dimensione.\n"
            "  - 1.0   = ellisse standard di errore (default; convenzione "
            "topografica usata nei report di compensazione di reti)\n"
            "  - 2.448 = ellisse di confidenza al 95 % (gauss. bivariata)\n"
            "  - 3.035 = ellisse di confidenza al 99 %\n"
            "Attenzione: in 2D le percentuali di confidenza NON coincidono "
            "con quelle del caso 1D (1\u03c3 \u2248 39 %, 2\u03c3 \u2248 86 %, 3\u03c3 \u2248 99 %). "
            "Lasciare 1.0 se non si ha un'esigenza specifica.\n\n"
            "Algoritmo: accumulatore online di Welford-Chan, numericamente "
            "stabile anche su coordinate UTM (10^6 m).\n\n"
            "Algoritmi nativi QGIS Processing correlati (nessuno copre lo "
            "stesso caso d'uso):\n"
            "  - qgis:meancoordinates    : solo centroidi\n"
            "  - qgis:basicstatisticsforfields : su un campo, non sulle coord.\n"
            "  - qgis:statisticsbycategories   : aggrega un campo per categoria"
        )

    def createInstance(self):
        return CoordinateStandardDeviation()
