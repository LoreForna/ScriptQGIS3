# coord_std_dev_xyz

QGIS Processing script per il calcolo dello **scarto quadratico medio (SQM) di
coordinate XYZ** secondo la convenzione topografica italiana, con
raggruppamento opzionale per campo, espressione QGIS o selezione.

Per ciascun gruppo di punti restituisce un **centroide** con statistiche
planimetriche e altimetriche complete e, opzionalmente, un'**ellisse di
deviazione standard** (poligono) scalabile a 1σ / 2σ / 3σ.

---

## Statistiche calcolate

### Planimetria (sempre disponibile)

| Campo | Significato |
|---|---|
| `n` | numero di punti del gruppo |
| `mean_x`, `mean_y` | coordinate del centroide |
| `sigma_x`, `sigma_y` | SQM campionari delle coordinate (denominatore *n−1*) |
| `sigma_xy` | covarianza campionaria |
| `sigma_p` | √(σx² + σy²) — Errore Quadratico Medio Planimetrico (EQMP) |
| `sigma_max`, `sigma_min` | semiassi dell'ellisse di deviazione standard (autovalori della matrice di covarianza 2D) |
| `theta_deg` | orientamento dell'asse maggiore (0° = Est, antiorario) |
| `anisotropy` | rapporto σ_max / σ_min (NULL se σ_min = 0) |
| `CEP50` | Circular Error Probable 50% — formula RAND: 0.5614·σ_max + 0.6175·σ_min |
| `R95_2d` | 95° percentile empirico delle distanze planimetriche dal centroide |
| `max_dist_2d` | distanza massima dal centroide |
| `rmsd_2d` | scarto quadratico medio delle distanze (denominatore *n*) |

### Altimetria (se almeno un punto del gruppo ha Z valido)

| Campo | Significato |
|---|---|
| `n_z` | numero di punti con Z definito |
| `mean_z` | quota media |
| `sigma_z` | SQM campionario delle quote (denominatore *n_z − 1*) |
| `sigma_3d` | √(σx² + σy² + σz²) — Errore Quadratico Medio Sferico (EQMS), calcolato sul **subset** di punti con Z |
| `SEP` | Spherical Error Probable — formula Mood: 0.51·(σx + σy + σz) |
| `R95_3d` | 95° percentile empirico delle distanze 3D |
| `max_dist_3d` | distanza 3D massima |
| `rmsd_3d` | analogo 3D di rmsd |

> **Coerenza altimetrica.** Su layer 3D misti (alcuni vertici con Z, altri
> senza), le statistiche planimetriche si calcolano su **tutti** i punti del
> gruppo, mentre le statistiche altimetriche e sferiche si calcolano solo sul
> **subset** dei punti con Z valido (con `n_z`, medie e covarianze coerenti tra
> loro). Questo evita il classico errore di mescolare denominatori diversi nel
> calcolo dell'EQMS.

---

## Installazione

1. Aprire QGIS (versione 3.x).
2. Pannello **Processing Toolbox** → menu Python in alto → **Aggiungi script al Toolbox…**
3. Selezionare `coord_std_dev_xyz.py`.

Lo script appare nel gruppo **Statistiche punti** del toolbox utente.

---

## Uso

### Parametri

| Parametro | Descrizione |
|---|---|
| **Layer puntuale** | layer di input (CRS proiettato consigliato; supporta Z) |
| **Campo di raggruppamento** | opzionale; se vuoto, tutti i punti formano un unico gruppo (o la sola selezione, se attiva) |
| **Espressione di raggruppamento** | opzionale; ha **priorità** sul campo. Utile per chiavi composite, es. `"USM_" || us \|\| "_" \|\| fase` |
| **Includi feature con chiave NULL** | se disattivato, le feature con chiave gruppo vuota o NULL vengono scartate e contate nel log |
| **Fattore moltiplicativo per i semiassi dell'ellisse** | scala dell'ellisse di output (default 1 = 1σ, mettere 2 o 3 per ellissi 2σ/3σ) |
| **Centroidi con statistiche** | output obbligatorio (PointZ se il layer è 3D, Point altrimenti) |
| **Ellissi di deviazione standard** | output opzionale (Polygon) |

### Ordine di priorità per il raggruppamento

1. Espressione QGIS (se specificata)
2. Campo di raggruppamento (se specificato)
3. Toggle **Selected features only** del parametro layer
4. Tutti i punti del layer in un unico gruppo

---

## Algoritmo

Accumulatore **online di Welford-Knuth-Chan** in O(1) per punto e O(K) per
gruppo, **numericamente stabile** anche su coordinate UTM o Gauss-Boaga
(10⁶–10⁷ m). Due sub-accumulatori indipendenti gestiscono separatamente la
parte 2D piena e il subset 3D, evitando perdita di cifre da "somma quadrati −
n·media²".

Gli **autovalori della matrice di covarianza 2D** sono calcolati in **forma
chiusa** (formula della matrice 2x2) e confrontati nei test contro
`numpy.linalg.eigh`: corrispondenza a 10⁻¹² per σ_max, σ_min e θ.

---

## Convenzioni topografiche adottate

- **Stimatori campionari** (denominatore *n−1*) per σ_x, σ_y, σ_z, σ_xy
  (convenzione standard di metrologia topografica)
- **EQMP** = √(σx² + σy²)
- **EQMS** = √(σx² + σy² + σz²), calcolato sul subset 3D
- **DRMS** (= `rmsd_2d/3d`) con denominatore *n*, distinto da `std_distance`
- **CEP50 — formula RAND**:
  `0.5614·σ_max + 0.6175·σ_min`. Più accurata di 1.1774·σ (che vale solo
  nel caso isotropo). Errore vs mediana di Rayleigh: 0.012% (verificato).
- **SEP — formula di Mood**: `0.51·(σ_x + σ_y + σ_z)` sul subset 3D.
  Errore vs χ²_inv(0.5, df=3)^0.5 nel caso isotropo: 1.28% (verificato).
- **R95** empirico: 95° percentile delle distanze dal centroide,
  più robusto del 2σ in caso di distribuzioni non-gaussiane.

---

## Verifica e test

Lo script include una suite di test in puro Python (`test_coord_std_dev_xyz.py`)
che può essere eseguita fuori dall'ambiente QGIS (richiede solo `numpy`):

```bash
python3 test_coord_std_dev_xyz.py
```

La suite copre **139 controlli** in 10 sezioni:

- **A** — verifica aritmetica manuale su 3 punti 3D (tutti i valori
  calcolati a mano, σ_x = √3, σ_y = √(16/3), σ_max = √((25+√193)/6), …)
- **B** — regression: quadrato unitario, tre punti collineari
- **C** — stabilità Welford su 5000 punti UTM (E=500000, N=4500000)
- **D** — autovalori 2x2 closed-form vs `numpy.linalg.eigh`
- **E** — percentili e ellisse (vertici, chiusura, area = π·a·b, rotazione)
- **F** — CEP50 e SEP vs grandezze teoriche
- **G** — edge case (n=1, n=2, Z=NaN totale, anisotropia 10:1)
- **H** — 3D misto (vertici con Z e senza Z nello stesso gruppo)
- **I** — caso topografico reale (5 rilievi GNSS, UTM, metri)
- **J** — invarianza per traslazione 3D di (10⁶, 2·10⁶, 10³) m

Risultato atteso: `RISULTATO: 139/139 controlli superati`.

---

## File inclusi

- `coord_std_dev_xyz.py` — lo script QGIS Processing
- `test_coord_std_dev_xyz.py` — suite di verifica (richiede numpy)
- `README.md` — questo file

---

## Algoritmi nativi QGIS Processing correlati

(Nessuno copre lo stesso caso d'uso.)

- `qgis:meancoordinates` — solo centroidi, nessuna dispersione
- `qgis:basicstatisticsforfields` — su un campo, non sulle coordinate
- `qgis:statisticsbycategories` — aggrega un campo per categoria

---

## Note implementative

- **`QVariant`**: lo script usa `QVariant.Int/Double/String` per i tipi di
  campo. In QGIS 3.38+ questo emette un `DeprecationWarning` che non
  pregiudica il funzionamento. La transizione a `QMetaType.Type.*`
  (QGIS 4 / Qt6) è meccanica.
- **CRS geografico**: se il layer ha un CRS geografico, lo script emette un
  avviso. Le statistiche metriche sarebbero in gradi: riproiettare in un CRS
  proiettato prima dell'uso.
- **Performance**: `QgsFeatureRequest.setSubsetOfAttributes` (o
  `setNoAttributes` se non c'è raggruppamento) riduce l'I/O attributi su
  layer molto pesanti.
