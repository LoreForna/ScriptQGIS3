<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>MoveRaster</name>
    <message>
        <source>Move Layer (Raster + Vector)</source>
        <translation>Move Layer (Raster + Vector)</translation>
    </message>
    <message>
        <source>Move raster and associated geometries</source>
        <translation>Move raster and associated geometries</translation>
    </message>
    <message>
        <source>Undo Move</source>
        <translation>Undo Move</translation>
    </message>
    <message>
        <source>Restore previous position</source>
        <translation>Restore previous position</translation>
    </message>
    <message>
        <source>Toggle Mode (Corner/Center)</source>
        <translation>Toggle Mode (Corner/Center)</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Help</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Center</translation>
    </message>
    <message>
        <source>Upper Left Corner</source>
        <translation>Upper Left Corner</translation>
    </message>
    <message>
        <source>Mode: {}</source>
        <translation>Mode: {}</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Warning</translation>
    </message>
    <message>
        <source>Select at least one layer!</source>
        <translation>Select at least one layer!</translation>
    </message>
    <message>
        <source>center</source>
        <translation>center</translation>
    </message>
    <message>
        <source>upper left corner</source>
        <translation>upper left corner</translation>
    </message>
    <message>
        <source> (selected only)</source>
        <translation> (selected only)</translation>
    </message>
    <message>
        <source>Click on the map to move layers (mode: {}){}</source>
        <translation>Click on the map to move layers (mode: {}){}</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Undo</translation>
    </message>
    <message>
        <source>No move to undo.</source>
        <translation>No move to undo.</translation>
    </message>
    <message>
        <source>Move undone!</source>
        <translation>Move undone!</translation>
    </message>
    <message>
        <source>Undo Error</source>
        <translation>Undo Error</translation>
    </message>
    <message>
        <source>Error during undo:
{}</source>
        <translation>Error during undo:
{}</translation>
    </message>
    <message>
        <source>Help - MoveRaster</source>
        <translation>Help - MoveRaster</translation>
    </message>
    <message>
        <source>This plugin allows you to move together:</source>
        <translation>This plugin allows you to move together:</translation>
    </message>
    <message>
        <source>  - A raster layer (GeoTIFF or with world file)</source>
        <translation>  - A raster layer (GeoTIFF or with world file)</translation>
    </message>
    <message>
        <source>  - One or more associated vector layers</source>
        <translation>  - One or more associated vector layers</translation>
    </message>
    <message>
        <source>  - Only selected geometries (optional)</source>
        <translation>  - Only selected geometries (optional)</translation>
    </message>
    <message>
        <source>SUPPORTED FORMATS:</source>
        <translation>SUPPORTED FORMATS:</translation>
    </message>
    <message>
        <source>- GeoTIFF (.tif, .tiff) - modifies internal geotransform</source>
        <translation>- GeoTIFF (.tif, .tiff) - modifies internal geotransform</translation>
    </message>
    <message>
        <source>- PNG/JPG with world file (.pgw, .jgw, .wld)</source>
        <translation>- PNG/JPG with world file (.pgw, .jgw, .wld)</translation>
    </message>
    <message>
        <source>- Other formats with world file</source>
        <translation>- Other formats with world file</translation>
    </message>
    <message>
        <source>USAGE:</source>
        <translation>USAGE:</translation>
    </message>
    <message>
        <source>1. Click on 'Move Layer' button</source>
        <translation>1. Click on 'Move Layer' button</translation>
    </message>
    <message>
        <source>2. In the selection window:</source>
        <translation>2. In the selection window:</translation>
    </message>
    <message>
        <source>   - Choose the raster to move</source>
        <translation>   - Choose the raster to move</translation>
    </message>
    <message>
        <source>   - Select associated vector layers</source>
        <translation>   - Select associated vector layers</translation>
    </message>
    <message>
        <source>   - Choose mode (corner/center)</source>
        <translation>   - Choose mode (corner/center)</translation>
    </message>
    <message>
        <source>   - Check 'Selected geometries only' if needed</source>
        <translation>   - Check 'Selected geometries only' if needed</translation>
    </message>
    <message>
        <source>3. Click OK</source>
        <translation>3. Click OK</translation>
    </message>
    <message>
        <source>4. Click on the map at destination point</source>
        <translation>4. Click on the map at destination point</translation>
    </message>
    <message>
        <source>SELECTED GEOMETRIES ONLY:</source>
        <translation>SELECTED GEOMETRIES ONLY:</translation>
    </message>
    <message>
        <source>If you have selected features in vector layers,</source>
        <translation>If you have selected features in vector layers,</translation>
    </message>
    <message>
        <source>you can choose to move only those instead of</source>
        <translation>you can choose to move only those instead of</translation>
    </message>
    <message>
        <source>all geometries in the layer.</source>
        <translation>all geometries in the layer.</translation>
    </message>
    <message>
        <source>MODE:</source>
        <translation>MODE:</translation>
    </message>
    <message>
        <source>- Upper Left Corner: clicked point becomes</source>
        <translation>- Upper Left Corner: clicked point becomes</translation>
    </message>
    <message>
        <source>  the upper left corner of the raster</source>
        <translation>  the upper left corner of the raster</translation>
    </message>
    <message>
        <source>- Center: clicked point becomes the center</source>
        <translation>- Center: clicked point becomes the center</translation>
    </message>
    <message>
        <source>  of the raster</source>
        <translation>  of the raster</translation>
    </message>
    <message>
        <source>UNDO:</source>
        <translation>UNDO:</translation>
    </message>
    <message>
        <source>Click 'Undo Move' to restore</source>
        <translation>Click 'Undo Move' to restore</translation>
    </message>
    <message>
        <source>previous position (up to 10 levels).</source>
        <translation>previous position (up to 10 levels).</translation>
    </message>
    <message>
        <source>NOTE: Files are modified directly.</source>
        <translation>NOTE: Files are modified directly.</translation>
    </message>
    <message>
        <source>Backup is recommended!</source>
        <translation>Backup is recommended!</translation>
    </message>
    <message>
        <source>Select Layers to Move</source>
        <translation>Select Layers to Move</translation>
    </message>
    <message>
        <source>Raster Layer (reference)</source>
        <translation>Raster Layer (reference)</translation>
    </message>
    <message>
        <source>Vector Layers (to move together)</source>
        <translation>Vector Layers (to move together)</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Select All</translation>
    </message>
    <message>
        <source>Deselect All</source>
        <translation>Deselect All</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Options</translation>
    </message>
    <message>
        <source>Use raster center (instead of upper left corner)</source>
        <translation>Use raster center (instead of upper left corner)</translation>
    </message>
    <message>
        <source>Move selected geometries only</source>
        <translation>Move selected geometries only</translation>
    </message>
    <message>
        <source>If active, moves only selected features in vector layers.</source>
        <translation>If active, moves only selected features in vector layers.</translation>
    </message>
    <message>
        <source>Otherwise moves all geometries of selected layers.</source>
        <translation>Otherwise moves all geometries of selected layers.</translation>
    </message>
    <message>
        <source>Move selected geometries only ({} selected)</source>
        <translation>Move selected geometries only ({} selected)</translation>
    </message>
    <message>
        <source>Move selected geometries only (no active selection)</source>
        <translation>Move selected geometries only (no active selection)</translation>
    </message>
    <message>
        <source>Move selected geometries only (no selection in chosen layers)</source>
        <translation>Move selected geometries only (no selection in chosen layers)</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <source>selected</source>
        <translation>selected</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>No reference extent!</source>
        <translation>No reference extent!</translation>
    </message>
    <message>
        <source>Raster type: {}</source>
        <translation>Raster type: {}</translation>
    </message>
    <message>
        <source>Selected geometries only: {} features</source>
        <translation>Selected geometries only: {} features</translation>
    </message>
    <message>
        <source>Total geometries: {} features</source>
        <translation>Total geometries: {} features</translation>
    </message>
    <message>
        <source>Confirm Move</source>
        <translation>Confirm Move</translation>
    </message>
    <message>
        <source>Move {} layers?</source>
        <translation>Move {} layers?</translation>
    </message>
    <message>
        <source>{} layers moved successfully!{}</source>
        <translation>{} layers moved successfully!{}</translation>
    </message>
    <message>
        <source>Some layers may not have been moved correctly</source>
        <translation>Some layers may not have been moved correctly</translation>
    </message>
    <message>
        <source>Raster Error</source>
        <translation>Raster Error</translation>
    </message>
    <message>
        <source>Error moving raster:
{}</source>
        <translation>Error moving raster:
{}</translation>
    </message>
    <message>
        <source>Cannot open {} in write mode</source>
        <translation>Cannot open {} in write mode</translation>
    </message>
    <message>
        <source>GeoTIFF Error</source>
        <translation>GeoTIFF Error</translation>
    </message>
    <message>
        <source>Error modifying GeoTIFF:
{}</source>
        <translation>Error modifying GeoTIFF:
{}</translation>
    </message>
    <message>
        <source>World File Error</source>
        <translation>World File Error</translation>
    </message>
    <message>
        <source>Error modifying world file:
{}</source>
        <translation>Error modifying world file:
{}</translation>
    </message>
    <message>
        <source>Vector Error</source>
        <translation>Vector Error</translation>
    </message>
    <message>
        <source>Error moving layer {}:
{}</source>
        <translation>Error moving layer {}:
{}</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Language</translation>
    </message>
    <message>
        <source>Tutorial</source>
        <translation>Tutorial</translation>
    </message>
    <message>
        <source>Language Changed</source>
        <translation>Language Changed</translation>
    </message>
    <message>
        <source>Language changed to: {}</source>
        <translation>Language changed to: {}</translation>
    </message>
    <message>
        <source>Please reload the plugin for changes to take effect.</source>
        <translation>Please reload the plugin for changes to take effect.</translation>
    </message>
    <message>
        <source>Select Language</source>
        <translation>Select Language</translation>
    </message>
    <message>
        <source>Choose language:</source>
        <translation>Choose language:</translation>
    </message>
    <message>
        <source>Note: Reload plugin after changing language.</source>
        <translation>Note: Reload plugin after changing language.</translation>
    </message>
    <message>
        <source>Previous</source>
        <translation>Previous</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Next</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Base Point</source>
        <translation>Base Point</translation>
    </message>
    <message>
        <source>Move by Base Point</source>
        <translation>Move by Base Point</translation>
    </message>
    <message>
        <source>Click a base point on the raster, then click the destination point</source>
        <translation>Click a base point on the raster, then click the destination point</translation>
    </message>
    <message>
        <source>Toggle Mode (Corner/Center/Base Point)</source>
        <translation>Toggle Mode (Corner/Center/Base Point)</translation>
    </message>
    <message>
        <source>Click on the raster to set the base point, then click the destination. Right click / Esc to cancel.</source>
        <translation>Click on the raster to set the base point, then click the destination. Right click / Esc to cancel.</translation>
    </message>
    <message>
        <source>Click the base point on the raster, then the destination point{}</source>
        <translation>Click the base point on the raster, then the destination point{}</translation>
    </message>
    <message>
        <source>- Base Point: first click a point on the raster,</source>
        <translation>- Base Point: first click a point on the raster,</translation>
    </message>
    <message>
        <source>  then click where that point must go</source>
        <translation>  then click where that point must go</translation>
    </message>
    <message>
        <source>  (snapping is honoured; right click resets</source>
        <translation>  (snapping is honoured; right click resets</translation>
    </message>
    <message>
        <source>  the base point, Esc cancels)</source>
        <translation>  the base point, Esc cancels)</translation>
    </message>
    <message>
        <source>MOVE BY BASE POINT (menu):</source>
        <translation>MOVE BY BASE POINT (menu):</translation>
    </message>
    <message>
        <source>Quick tool without dialog: click on any visible</source>
        <translation>Quick tool without dialog: click on any visible</translation>
    </message>
    <message>
        <source>raster to pick it and set the base point,</source>
        <translation>raster to pick it and set the base point,</translation>
    </message>
    <message>
        <source>then click the destination.</source>
        <translation>then click the destination.</translation>
    </message>
    <message>
        <source>Reference point:</source>
        <translation>Reference point:</translation>
    </message>
    <message>
        <source>1st click: base point on the raster - 2nd click: destination</source>
        <translation>1st click: base point on the raster - 2nd click: destination</translation>
    </message>
    <message>
        <source>Move cancelled</source>
        <translation>Move cancelled</translation>
    </message>
    <message>
        <source>Base point cleared: click a new base point</source>
        <translation>Base point cleared: click a new base point</translation>
    </message>
    <message>
        <source>No visible raster under the clicked point</source>
        <translation>No visible raster under the clicked point</translation>
    </message>
    <message>
        <source>The base point must be on the raster: click inside it</source>
        <translation>The base point must be on the raster: click inside it</translation>
    </message>
    <message>
        <source>Base point set ({:.3f}, {:.3f}) on '{}'. Now click the destination point.</source>
        <translation>Base point set ({:.3f}, {:.3f}) on '{}'. Now click the destination point.</translation>
    </message>
    <message>
        <source>Base point: {:.3f}, {:.3f}</source>
        <translation>Base point: {:.3f}, {:.3f}</translation>
    </message>
    <message>
        <source>Destination: {:.3f}, {:.3f}</source>
        <translation>Destination: {:.3f}, {:.3f}</translation>
    </message>
    <message>
        <source>Click another destination, right click to reset the base point, Esc to cancel</source>
        <translation>Click another destination, right click to reset the base point, Esc to cancel</translation>
    </message>
</context>
</TS>
