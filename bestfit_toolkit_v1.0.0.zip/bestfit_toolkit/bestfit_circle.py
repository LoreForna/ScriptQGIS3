from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterNumber,
    QgsProcessingParameterEnum,
    QgsProcessingParameterField,
    QgsProcessingParameterBoolean,
    QgsFeature, QgsGeometry, QgsWkbTypes,
    QgsFields, QgsField, QgsPointXY,
)
try:
    from qgis.PyQt.QtCore import QVariant
except ImportError:
    # QGIS 4 / PyQt6: QVariant non esiste piu' — usa QMetaType
    from qgis.PyQt.QtCore import QMetaType
    class QVariant:
        Double = QMetaType.Type.Double
        Int    = QMetaType.Type.Int
        String = QMetaType.Type.QString
        Bool   = QMetaType.Type.Bool
import numpy as np


class BestFitCircle(QgsProcessingAlgorithm):

    INPUT             = 'INPUT'
    WEIGHT_FIELD      = 'WEIGHT_FIELD'
    OUTPUT_CIRCLE     = 'OUTPUT_CIRCLE'
    OUTPUT_POINTS     = 'OUTPUT_POINTS'
    OUTPUT_TYPE       = 'OUTPUT_TYPE'
    FIT_METHOD        = 'FIT_METHOD'
    N_SEGMENTS        = 'N_SEGMENTS'
    USE_RANSAC        = 'USE_RANSAC'
    RANSAC_THRESHOLD  = 'RANSAC_THRESHOLD'
    OUTLIER_THRESHOLD = 'OUTLIER_THRESHOLD'

    TYPE_OPTIONS   = ['Cerchio completo', 'Arco (minimum enclosing arc)']
    METHOD_OPTIONS = ['Pratt (raccomandato)', 'Kasa (algebrico classico)']

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, 'Layer di punti (2D o 3D)',
            [QgsProcessing.TypeVectorPoint]))

        self.addParameter(QgsProcessingParameterField(
            self.WEIGHT_FIELD,
            'Campo peso (opzionale; valori più alti = punti più affidabili)',
            parentLayerParameterName=self.INPUT,
            type=QgsProcessingParameterField.Numeric,
            optional=True))

        self.addParameter(QgsProcessingParameterEnum(
            self.OUTPUT_TYPE, 'Tipo di output',
            options=self.TYPE_OPTIONS, defaultValue=0))

        self.addParameter(QgsProcessingParameterEnum(
            self.FIT_METHOD, 'Metodo di fit',
            options=self.METHOD_OPTIONS, defaultValue=0))

        self.addParameter(QgsProcessingParameterNumber(
            self.N_SEGMENTS,
            'Numero di segmenti (risoluzione della polilinea)',
            defaultValue=72, minValue=8,
            type=QgsProcessingParameterNumber.Integer))

        self.addParameter(QgsProcessingParameterBoolean(
            self.USE_RANSAC,
            'Usa RANSAC (robusto agli outlier)',
            defaultValue=False))

        self.addParameter(QgsProcessingParameterNumber(
            self.RANSAC_THRESHOLD,
            'RANSAC: soglia inlier (unità mappa, 0 = auto)',
            defaultValue=0.0, minValue=0.0,
            type=QgsProcessingParameterNumber.Double))

        self.addParameter(QgsProcessingParameterNumber(
            self.OUTLIER_THRESHOLD,
            'Soglia outlier (× RMSE)',
            defaultValue=2.5, minValue=0.0,
            type=QgsProcessingParameterNumber.Double))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_CIRCLE, 'Cerchio/Arco best-fit',
            QgsProcessing.TypeVectorLine))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_POINTS, 'Punti con residui',
            QgsProcessing.TypeVectorPoint))

    def shortHelpString(self):
        return """

<p>Calcola il cerchio o l'arco di cerchio che meglio approssima una nuvola di punti, lavorando esclusivamente nel piano XY (la coordinata Z viene ignorata). Con 3 punti il risultato coincide col cerchio esatto; con più punti viene applicata una regressione algebrica.</p>

<h4>Metodi di fit</h4>
<ul>
  <li><b>Pratt</b> (default): minimizza l'errore algebrico rispettando il vincolo B²+C²−4AD=1. È più accurato di Kasa quando i punti coprono solo un arco parziale (Kasa tende a sottostimare il raggio in quel caso).</li>
  <li><b>Kasa</b>: linearizza x²+y²=A·x+B·y+C e risolve con minimi quadrati. Veloce e semplice; ottimo se i punti coprono il cerchio completo.</li>
</ul>
<p>I punti vengono <b>centrati e normalizzati</b> per garantire stabilità numerica con coordinate di grandi valori (es. UTM).</p>

<h4>Arco di cerchio (Minimum Enclosing Arc)</h4>
<p>L'arco viene calcolato come il <b>minimum enclosing arc</b>: gli angoli dei punti vengono ordinati, si individua il gap angolare massimo tra punti consecutivi e l'arco copre tutto il resto. Funziona anche quando i punti non sono in ordine sequenziale.</p>

<h4>RANSAC (opzionale)</h4>
<p>Se attivato, esegue <b>RANSAC</b> prima del fit finale: campiona ripetutamente terne di punti, calcola il cerchio esatto e identifica gli inlier; il fit finale è applicato solo agli inlier del miglior modello. Soglia 0 = auto da MAD.</p>

<h4>Parametri</h4>
<ul>
  <li><b>Layer di punti</b>: layer vettoriale di punti 2D o 3D (Z ignorata).</li>
  <li><b>Campo peso</b>: opzionale, valori più alti = punti più affidabili.</li>
  <li><b>Tipo di output</b>: cerchio completo (360°) o arco minimo.</li>
  <li><b>Metodo di fit</b>: Pratt o Kasa.</li>
  <li><b>Numero di segmenti</b>: risoluzione della polilinea (default 72 = 1 vertice ogni 5°).</li>
  <li><b>Usa RANSAC</b>: attiva il fit robusto agli outlier.</li>
  <li><b>RANSAC: soglia inlier</b>: distanza radiale max per considerare un punto inlier. 0 = auto.</li>
  <li><b>Soglia outlier (× RMSE)</b>: moltiplicatore di RMSE oltre il quale un punto è marcato come outlier.</li>
</ul>

<h4>Output — Cerchio/Arco best-fit</h4>
<ul>
  <li><b>center_x / center_y</b>: coordinate del centro.</li>
  <li><b>radius</b>: raggio in unità mappa.</li>
  <li><b>rmse</b>: errore quadratico medio dei residui radiali.</li>
  <li><b>residual_median</b>, <b>residual_iqr</b>: statistiche robuste dei residui.</li>
  <li><b>arc_start_deg</b> / <b>arc_end_deg</b> / <b>arc_span_deg</b>: angoli e ampiezza dell'arco.</li>
  <li><b>n_points</b>, <b>n_used</b>, <b>n_outliers</b>: numerosità.</li>
  <li><b>output_type</b>: <i>circle</i> o <i>arc</i>.</li>
  <li><b>fit_method</b>: <i>pratt</i> o <i>kasa</i>.</li>
  <li><b>used_ransac</b>: True se è stato usato RANSAC.</li>
</ul>

<h4>Output — Punti con residui</h4>
<ul>
  <li><b>fid</b>, <b>residual</b>, <b>angle_deg</b>, <b>proj_x/y</b>.</li>
  <li><b>is_outlier</b>: True se residuo &gt; soglia × RMSE.</li>
  <li><b>is_inlier</b>: (solo con RANSAC) True se selezionato come inlier.</li>
  <li><b>weight</b>: (solo con campo peso) peso usato nel fit.</li>
</ul>

<p><b>Nota CRS:</b> Per risultati corretti il layer deve essere in un CRS proiettato (metri). In CRS geografici (gradi) il fit è distorto; viene mostrato un warning.</p>
"""

    # ── Fit Kasa (algebrico classico) ─────────────────────────────────────────
    @staticmethod
    def _fit_circle_kasa(xy, weights=None):
        """
        Fit algebrico di Kasa con centramento e normalizzazione.
        Linearizza x² + y² = A·x + B·y + C.
        Con 3 punti restituisce il cerchio esatto (RMSE=0).
        """
        x_mean = float(xy[:, 0].mean())
        y_mean = float(xy[:, 1].mean())
        scale  = float(np.sqrt(((xy[:, 0] - x_mean)**2 +
                                (xy[:, 1] - y_mean)**2).mean()))
        if scale < 1e-10:
            raise Exception("I punti sono coincidenti o troppo vicini.")

        xn = (xy[:, 0] - x_mean) / scale
        yn = (xy[:, 1] - y_mean) / scale
        rhs   = xn**2 + yn**2
        A_mat = np.column_stack([xn, yn, np.ones(len(xn))])

        if weights is not None:
            w = np.sqrt(weights)
            A_mat = A_mat * w[:, None]
            rhs   = rhs * w

        res, _, _, _ = np.linalg.lstsq(A_mat, rhs, rcond=None)

        cx_n = float(res[0]) / 2.0
        cy_n = float(res[1]) / 2.0
        r2_n = float(res[2]) + cx_n**2 + cy_n**2
        if r2_n <= 0:
            raise Exception("Punti collineari: impossibile fittare un cerchio.")

        cx = cx_n * scale + x_mean
        cy = cy_n * scale + y_mean
        r  = float(np.sqrt(r2_n)) * scale
        return cx, cy, r

    # ── Fit Pratt ────────────────────────────────────────────────────────────
    @staticmethod
    def _fit_circle_pratt(xy, weights=None):
        """
        Fit algebrico di Pratt: minimizza l'errore algebrico A(x²+y²)+Bx+Cy+D
        con vincolo B²+C²-4AD=1. Più accurato di Kasa per archi parziali.
        """
        x_mean = float(xy[:, 0].mean())
        y_mean = float(xy[:, 1].mean())
        scale  = float(np.sqrt(((xy[:, 0] - x_mean)**2 +
                                (xy[:, 1] - y_mean)**2).mean()))
        if scale < 1e-10:
            raise Exception("I punti sono coincidenti o troppo vicini.")

        xn = (xy[:, 0] - x_mean) / scale
        yn = (xy[:, 1] - y_mean) / scale
        z  = xn**2 + yn**2

        D_mat = np.column_stack([z, xn, yn, np.ones(len(xn))])
        if weights is not None:
            w = np.sqrt(weights)
            D_mat = D_mat * w[:, None]

        M = (D_mat.T @ D_mat) / len(xn)
        # Constraint matrix Pratt: B²+C²-4AD=1
        Cmat = np.array([
            [0.0, 0.0, 0.0, -2.0],
            [0.0, 1.0, 0.0,  0.0],
            [0.0, 0.0, 1.0,  0.0],
            [-2.0, 0.0, 0.0, 0.0],
        ])
        try:
            Cinv = np.linalg.inv(Cmat)
        except np.linalg.LinAlgError:
            raise Exception("Constraint matrix singolare (caso impossibile).")

        eigvals, eigvecs = np.linalg.eig(Cinv @ M)
        # autovettore con autovalore reale positivo minimo
        real_mask = np.abs(eigvals.imag) < 1e-9
        real_eigs = eigvals.real[real_mask]
        real_vecs = eigvecs[:, real_mask].real
        positive  = real_eigs > 1e-12
        if positive.any():
            idx_local = np.argmin(real_eigs[positive])
            sol = real_vecs[:, positive][:, idx_local]
        else:
            # fallback: autovalore con valore assoluto minimo
            idx = int(np.argmin(np.abs(eigvals.real)))
            sol = eigvecs[:, idx].real

        A_, B_, C_, D_ = sol
        if abs(A_) < 1e-12:
            raise Exception("Cerchio degenere (A≈0): punti probabilmente collineari.")
        cx_n = -B_ / (2.0 * A_)
        cy_n = -C_ / (2.0 * A_)
        r2_n = (B_**2 + C_**2 - 4.0 * A_ * D_) / (4.0 * A_**2)
        if r2_n <= 0:
            raise Exception("Punti collineari: impossibile fittare un cerchio.")
        r_n = float(np.sqrt(r2_n))

        cx = cx_n * scale + x_mean
        cy = cy_n * scale + y_mean
        r  = r_n * scale
        return cx, cy, r

    @classmethod
    def _fit_circle(cls, xy, method, weights=None):
        if method == 1:  # Kasa
            return cls._fit_circle_kasa(xy, weights)
        return cls._fit_circle_pratt(xy, weights)

    # ── Minimum enclosing arc ────────────────────────────────────────────────
    @staticmethod
    def _minimum_enclosing_arc(angles_raw):
        """L'arco più corto che contiene tutti i punti proiettati sul cerchio."""
        angles_norm = angles_raw % (2.0 * np.pi)
        ang_sorted  = np.sort(angles_norm)
        gaps        = np.diff(ang_sorted)
        wrap_gap    = ang_sorted[0] + 2.0 * np.pi - ang_sorted[-1]
        all_gaps    = np.append(gaps, wrap_gap)
        k           = int(np.argmax(all_gaps))
        if k == len(ang_sorted) - 1:
            theta_start = float(ang_sorted[0])
            theta_end   = float(ang_sorted[-1])
        else:
            theta_start = float(ang_sorted[k + 1])
            theta_end   = float(ang_sorted[k]) + 2.0 * np.pi
        return theta_start, theta_end

    # ── RANSAC ───────────────────────────────────────────────────────────────
    @classmethod
    def _ransac_circle(cls, xy, threshold, max_iters, rng):
        """RANSAC su cerchio. Modello = cerchio per 3 punti random (Kasa esatto)."""
        n = len(xy)
        if n < 3:
            return None
        best_inliers = None
        best_count   = -1
        for _ in range(max_iters):
            idx = rng.choice(n, size=3, replace=False)
            try:
                cx, cy, r = cls._fit_circle_kasa(xy[idx])
            except Exception:
                continue
            d        = np.linalg.norm(xy - np.array([cx, cy]), axis=1)
            res      = np.abs(d - r)
            inliers  = res <= threshold
            count    = int(inliers.sum())
            if count > best_count:
                best_count   = count
                best_inliers = inliers
        return best_inliers

    def processAlgorithm(self, parameters, context, feedback):
        source     = self.parameterAsSource(parameters, self.INPUT, context)
        out_type   = self.parameterAsEnum(parameters, self.OUTPUT_TYPE, context)
        method     = self.parameterAsEnum(parameters, self.FIT_METHOD, context)
        n_segments = self.parameterAsInt(parameters, self.N_SEGMENTS, context)
        use_ransac = self.parameterAsBoolean(parameters, self.USE_RANSAC, context)
        ransac_th  = self.parameterAsDouble(parameters, self.RANSAC_THRESHOLD, context)
        outlier_k  = self.parameterAsDouble(parameters, self.OUTLIER_THRESHOLD, context)
        weight_fld = self.parameterAsString(parameters, self.WEIGHT_FIELD, context)

        method_name = 'kasa' if method == 1 else 'pratt'

        # ── 0. Verifica CRS ────────────────────────────────────────────────────
        crs = source.sourceCrs()
        if crs.isGeographic():
            feedback.pushWarning(
                "ATTENZIONE: il CRS è geografico (gradi). Distanze e residui non "
                "saranno in unità metriche e i risultati potranno essere distorti. "
                "Riproietta il layer in un CRS proiettato (es. UTM) prima del fit.")

        # ── 1. Raccolta coordinate XY (Z ignorata) e pesi ──────────────────────
        ids, xy, weights = [], [], []
        for feat in source.getFeatures():
            geom = feat.geometry()
            pt   = geom.constGet()
            ids.append(feat.id())
            xy.append([float(pt.x()), float(pt.y())])
            if weight_fld:
                w = feat[weight_fld]
                try:
                    w = float(w) if w is not None else 1.0
                except (TypeError, ValueError):
                    w = 1.0
                if w <= 0 or w != w:
                    w = 1.0
                weights.append(w)

        if len(xy) < 3:
            raise Exception("Servono almeno 3 punti per fittare un cerchio.")

        xy          = np.array(xy, dtype=float)
        weights_arr = np.array(weights, dtype=float) if weights else None
        feedback.pushInfo(f"Punti letti: {len(xy)}")
        feedback.pushInfo(f"Metodo fit:  {method_name}")

        # ── 2. RANSAC opzionale ────────────────────────────────────────────────
        used_ransac    = False
        ransac_inliers = None
        if use_ransac:
            if ransac_th <= 0.0:
                # auto-soglia da MAD su fit preliminare
                pre_cx, pre_cy, pre_r = self._fit_circle(xy, method, weights_arr)
                pre_res = np.abs(np.linalg.norm(xy - [pre_cx, pre_cy], axis=1) - pre_r)
                mad     = float(np.median(np.abs(pre_res - np.median(pre_res))))
                ransac_th = max(2.5 * 1.4826 * mad, 1e-9)
                feedback.pushInfo(f"RANSAC soglia auto: {ransac_th:.6f}")

            rng     = np.random.default_rng(42)
            n_iters = max(100, min(5000, len(xy) * 50))
            inliers = self._ransac_circle(xy, ransac_th, n_iters, rng)
            if inliers is None or int(inliers.sum()) < 3:
                feedback.pushWarning(
                    "RANSAC non ha trovato abbastanza inlier. Uso fit standard.")
            else:
                used_ransac    = True
                ransac_inliers = inliers
                n_inl = int(inliers.sum())
                feedback.pushInfo(
                    f"RANSAC: {n_inl}/{len(xy)} inlier "
                    f"({100.0 * n_inl / len(xy):.1f}%)")

        # ── 3. Fit finale (su inlier se RANSAC) ───────────────────────────────
        if used_ransac:
            fit_xy      = xy[ransac_inliers]
            fit_weights = weights_arr[ransac_inliers] if weights_arr is not None else None
        else:
            fit_xy      = xy
            fit_weights = weights_arr
        cx, cy, radius = self._fit_circle(fit_xy, method, fit_weights)
        feedback.pushInfo(f"Centro:  ({cx:.6f}, {cy:.6f})")
        feedback.pushInfo(f"Raggio:  {radius:.6f} unità mappa")

        # ── 4. Angoli e residui radiali (su TUTTI i punti) ────────────────────
        diff             = xy - np.array([cx, cy])
        angles_raw       = np.arctan2(diff[:, 1], diff[:, 0])
        dist_from_center = np.linalg.norm(diff, axis=1)
        residuals        = np.abs(dist_from_center - radius)
        rmse             = float(np.sqrt((residuals**2).mean()))

        # ── 5. Statistiche estese ─────────────────────────────────────────────
        res_median = float(np.median(residuals))
        res_std    = float(residuals.std())
        q1, q3     = np.percentile(residuals, [25, 75])
        iqr        = float(q3 - q1)

        outlier_threshold = outlier_k * rmse
        is_outlier_arr    = residuals > outlier_threshold
        n_outliers        = int(is_outlier_arr.sum())

        feedback.pushInfo(f"Punti totali:     {len(xy)}")
        feedback.pushInfo(f"Punti usati fit:  {len(fit_xy)}")
        feedback.pushInfo(f"Residuo medio:    {residuals.mean():.6f}")
        feedback.pushInfo(f"Residuo mediano:  {res_median:.6f}")
        feedback.pushInfo(f"Residuo max:      {residuals.max():.6f}")
        feedback.pushInfo(f"Residuo std:      {res_std:.6f}")
        feedback.pushInfo(f"IQR residui:      {iqr:.6f}")
        feedback.pushInfo(f"RMSE:             {rmse:.6f}")
        feedback.pushInfo(
            f"Outlier (>{outlier_k}·RMSE): {n_outliers}/{len(xy)}")

        # ── 6. Intervallo angolare ────────────────────────────────────────────
        if out_type == 0:
            theta_start = float(angles_raw[0])
            theta_end   = theta_start + 2.0 * np.pi
            arc_span    = 360.0
            feedback.pushInfo("Output: cerchio completo.")
        else:
            theta_start, theta_end = self._minimum_enclosing_arc(angles_raw)
            arc_span = float(np.degrees(theta_end - theta_start))
            feedback.pushInfo(
                f"Output: arco da {np.degrees(theta_start):.2f}° "
                f"a {np.degrees(theta_end):.2f}° "
                f"(ampiezza {arc_span:.2f}°).")

        # ── 7. Polilinea ──────────────────────────────────────────────────────
        thetas   = np.linspace(theta_start, theta_end, n_segments + 1)
        poly_pts = [
            QgsPointXY(float(cx + radius * np.cos(th)),
                       float(cy + radius * np.sin(th)))
            for th in thetas
        ]
        if out_type == 1:
            poly_pts[0]  = QgsPointXY(
                float(cx + radius * np.cos(theta_start)),
                float(cy + radius * np.sin(theta_start)))
            poly_pts[-1] = QgsPointXY(
                float(cx + radius * np.cos(theta_end)),
                float(cy + radius * np.sin(theta_end)))

        # ── 8. Output cerchio/arco ────────────────────────────────────────────
        fields_circ = QgsFields()
        for name in ('center_x', 'center_y', 'radius', 'rmse',
                     'residual_median', 'residual_iqr',
                     'arc_start_deg', 'arc_end_deg', 'arc_span_deg'):
            fields_circ.append(QgsField(name, QVariant.Double))
        fields_circ.append(QgsField('n_points',    QVariant.Int))
        fields_circ.append(QgsField('n_used',      QVariant.Int))
        fields_circ.append(QgsField('n_outliers',  QVariant.Int))
        fields_circ.append(QgsField('output_type', QVariant.String))
        fields_circ.append(QgsField('fit_method',  QVariant.String))
        fields_circ.append(QgsField('used_ransac', QVariant.Bool))

        (sink_circ, dest_circ) = self.parameterAsSink(
            parameters, self.OUTPUT_CIRCLE, context,
            fields_circ, QgsWkbTypes.LineString, source.sourceCrs())

        if sink_circ is None:
            raise Exception("Impossibile creare il layer di output per il cerchio/arco.")

        f_circ = QgsFeature(fields_circ)
        f_circ.setGeometry(QgsGeometry.fromPolylineXY(poly_pts))
        f_circ.setAttributes([
            float(cx), float(cy),
            float(radius), float(rmse),
            float(res_median), float(iqr),
            float(np.degrees(theta_start) % 360),
            float(np.degrees(theta_end)   % 360),
            float(arc_span),
            int(len(xy)), int(len(fit_xy)), int(n_outliers),
            'circle' if out_type == 0 else 'arc',
            method_name,
            bool(used_ransac),
        ])
        sink_circ.addFeature(f_circ)
        feedback.pushInfo("Feature cerchio/arco aggiunta.")

        # ── 9. Output punti con residui ───────────────────────────────────────
        fields_pts = QgsFields()
        fields_pts.append(QgsField('fid',        QVariant.Int))
        fields_pts.append(QgsField('residual',   QVariant.Double))
        fields_pts.append(QgsField('angle_deg',  QVariant.Double))
        fields_pts.append(QgsField('proj_x',     QVariant.Double))
        fields_pts.append(QgsField('proj_y',     QVariant.Double))
        fields_pts.append(QgsField('is_outlier', QVariant.Bool))
        if used_ransac:
            fields_pts.append(QgsField('is_inlier', QVariant.Bool))
        if weights_arr is not None:
            fields_pts.append(QgsField('weight', QVariant.Double))

        (sink_pts, dest_pts) = self.parameterAsSink(
            parameters, self.OUTPUT_POINTS, context,
            fields_pts, QgsWkbTypes.Point, source.sourceCrs())

        if sink_pts is None:
            raise Exception("Impossibile creare il layer di output per i punti.")

        for i in range(len(xy)):
            d = float(dist_from_center[i])
            if d > 1e-10:
                proj_x = float(cx + radius * diff[i, 0] / d)
                proj_y = float(cy + radius * diff[i, 1] / d)
            else:
                proj_x, proj_y = float(cx + radius), float(cy)

            f = QgsFeature(fields_pts)
            f.setGeometry(QgsGeometry.fromPointXY(
                QgsPointXY(float(xy[i, 0]), float(xy[i, 1]))))
            attrs = [
                int(ids[i]),
                float(residuals[i]),
                float(np.degrees(angles_raw[i]) % 360),
                proj_x, proj_y,
                bool(is_outlier_arr[i]),
            ]
            if used_ransac:
                attrs.append(bool(ransac_inliers[i]))
            if weights_arr is not None:
                attrs.append(float(weights_arr[i]))
            f.setAttributes(attrs)
            sink_pts.addFeature(f)

        feedback.pushInfo(f"Punti con residui aggiunti: {len(xy)}")
        return {self.OUTPUT_CIRCLE: dest_circ, self.OUTPUT_POINTS: dest_pts}

    def name(self):           return 'bestfitcircle'
    def displayName(self):    return 'Best-fit Circle/Arc 2D'
    def group(self):          return 'Best-fit'
    def groupId(self):        return 'best-fit'
    def createInstance(self): return BestFitCircle()
