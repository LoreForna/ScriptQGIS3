from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterNumber,
    QgsProcessingParameterEnum,
    QgsProcessingParameterField,
    QgsProcessingParameterBoolean,
    QgsFeature, QgsGeometry, QgsWkbTypes,
    QgsFields, QgsField, QgsPointXY,
)
try:
    from qgis.PyQt.QtCore import QVariant
except ImportError:
    # QGIS 4 / PyQt6: QVariant non esiste piu' — usa QMetaType
    from qgis.PyQt.QtCore import QMetaType
    class QVariant:
        Double = QMetaType.Type.Double
        Int    = QMetaType.Type.Int
        String = QMetaType.Type.QString
        Bool   = QMetaType.Type.Bool
import numpy as np


class BestFitEllipse(QgsProcessingAlgorithm):

    INPUT             = 'INPUT'
    WEIGHT_FIELD      = 'WEIGHT_FIELD'
    OUTPUT_ELLIPSE    = 'OUTPUT_ELLIPSE'
    OUTPUT_POINTS     = 'OUTPUT_POINTS'
    OUTPUT_TYPE       = 'OUTPUT_TYPE'
    N_SEGMENTS        = 'N_SEGMENTS'
    USE_RANSAC        = 'USE_RANSAC'
    RANSAC_THRESHOLD  = 'RANSAC_THRESHOLD'
    OUTLIER_THRESHOLD = 'OUTLIER_THRESHOLD'

    TYPE_OPTIONS = ['Ellisse completa', 'Arco (minimum enclosing arc)']

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, 'Layer di punti (2D, Z ignorata)',
            [QgsProcessing.TypeVectorPoint]))

        self.addParameter(QgsProcessingParameterField(
            self.WEIGHT_FIELD,
            'Campo peso (opzionale)',
            parentLayerParameterName=self.INPUT,
            type=QgsProcessingParameterField.Numeric,
            optional=True))

        self.addParameter(QgsProcessingParameterEnum(
            self.OUTPUT_TYPE, 'Tipo di output',
            options=self.TYPE_OPTIONS, defaultValue=0))

        self.addParameter(QgsProcessingParameterNumber(
            self.N_SEGMENTS,
            'Numero di segmenti (risoluzione della polilinea)',
            defaultValue=72, minValue=8,
            type=QgsProcessingParameterNumber.Integer))

        self.addParameter(QgsProcessingParameterBoolean(
            self.USE_RANSAC,
            'Usa RANSAC (robusto agli outlier)',
            defaultValue=False))

        self.addParameter(QgsProcessingParameterNumber(
            self.RANSAC_THRESHOLD,
            'RANSAC: soglia inlier (unità mappa, 0 = auto)',
            defaultValue=0.0, minValue=0.0,
            type=QgsProcessingParameterNumber.Double))

        self.addParameter(QgsProcessingParameterNumber(
            self.OUTLIER_THRESHOLD,
            'Soglia outlier (× RMSE)',
            defaultValue=2.5, minValue=0.0,
            type=QgsProcessingParameterNumber.Double))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_ELLIPSE, 'Ellisse/Arco best-fit',
            QgsProcessing.TypeVectorLine))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_POINTS, 'Punti con residui',
            QgsProcessing.TypeVectorPoint))

    def shortHelpString(self):
        return """

<p>Calcola l'<b>ellisse</b> (o un suo arco) che meglio approssima una nuvola di punti nel piano XY. Generalizzazione del cerchio: utile per absidi non circolari, anfiteatri, ovali, mandorle, e qualunque forma curva non perfettamente circolare.</p>

<h4>Metodo di calcolo</h4>
<p>Si usa il fit algebrico diretto di <b>Fitzgibbon</b> (1996): l'equazione conica generale</p>
<pre>  A·x² + B·xy + C·y² + D·x + E·y + F = 0</pre>
<p>è risolta sotto il vincolo <b>4AC − B² = 1</b> che garantisce che la conica sia un'ellisse (mai parabola/iperbole). I punti vengono <b>centrati e normalizzati</b> per stabilità numerica.</p>

<p>Da (A,B,C,D,E,F) si ricavano <b>centro</b>, <b>semiasse maggiore</b>, <b>semiasse minore</b> e <b>angolo di rotazione</b>.</p>

<h4>Residui (approssimati)</h4>
<p>Il residuo di ogni punto è la distanza tra il punto e la sua <b>proiezione lungo l'angolo parametrico</b> sull'ellisse — non la distanza ortogonale esatta (che richiederebbe un solver iterativo). L'approssimazione è in genere sufficiente per una valutazione qualitativa della bontà del fit.</p>

<h4>Arco (Minimum Enclosing Arc)</h4>
<p>Stessa logica del cerchio ma su angoli parametrici dell'ellisse: gli angoli vengono ordinati, si individua il gap massimo e l'arco copre il resto.</p>

<h4>RANSAC (opzionale)</h4>
<p>Servono almeno <b>5 punti</b> per definire univocamente un'ellisse. RANSAC campiona quintetti random, fitta e identifica gli inlier; il fit finale è applicato solo agli inlier del miglior modello.</p>

<h4>Output — Ellisse/Arco</h4>
<ul>
  <li><b>center_x / center_y</b>: centro dell'ellisse.</li>
  <li><b>semi_major</b>, <b>semi_minor</b>: semiassi (semi_major ≥ semi_minor).</li>
  <li><b>rotation_deg</b>: angolo dell'asse maggiore rispetto all'asse X (0–180°).</li>
  <li><b>eccentricity</b>: eccentricità dell'ellisse (0 = cerchio, →1 = ellisse molto allungata).</li>
  <li><b>rmse</b>, <b>residual_median</b>, <b>residual_iqr</b>.</li>
  <li><b>arc_start_deg / arc_end_deg / arc_span_deg</b>: angoli parametrici dell'arco.</li>
  <li><b>n_points</b>, <b>n_used</b>, <b>n_outliers</b>, <b>output_type</b>, <b>used_ransac</b>.</li>
</ul>

<h4>Output — Punti con residui</h4>
<ul>
  <li><b>fid</b>, <b>residual</b>, <b>angle_deg</b> (angolo parametrico), <b>proj_x/y</b>.</li>
  <li><b>is_outlier</b>, <b>is_inlier</b> (con RANSAC), <b>weight</b> (con campo peso).</li>
</ul>

<p><b>Nota CRS:</b> Per risultati corretti il layer deve essere in un CRS proiettato (metri).</p>
"""

    @staticmethod
    def _fit_ellipse_fitzgibbon(xy, weights=None):
        """
        Fit algebrico di Fitzgibbon (1996) con vincolo 4AC-B²=1.
        Ritorna: (cx, cy, a, b, theta) con a >= b e theta in [0, pi).
        """
        x = xy[:, 0]; y = xy[:, 1]
        x_mean = float(x.mean()); y_mean = float(y.mean())
        scale  = float(max(np.abs(x - x_mean).max(),
                           np.abs(y - y_mean).max(), 1e-12))
        if scale < 1e-12:
            raise Exception("I punti sono coincidenti.")
        xn = (x - x_mean) / scale
        yn = (y - y_mean) / scale

        D_mat = np.column_stack([xn**2, xn*yn, yn**2, xn, yn, np.ones(len(xn))])
        if weights is not None:
            w = np.sqrt(weights)
            D_mat = D_mat * w[:, None]

        S = D_mat.T @ D_mat
        Cmat = np.zeros((6, 6))
        Cmat[0, 2] = 2.0
        Cmat[2, 0] = 2.0
        Cmat[1, 1] = -1.0

        try:
            Sinv = np.linalg.inv(S)
        except np.linalg.LinAlgError:
            raise Exception("Matrice del sistema singolare: punti collineari?")

        eigvals, eigvecs = np.linalg.eig(Sinv @ Cmat)
        real_mask = np.abs(eigvals.imag) < 1e-9
        real_eigs = eigvals.real
        cand = np.where(real_mask & (real_eigs > 1e-12))[0]
        if len(cand) == 0:
            raise Exception("Fit ellisse fallito (no autovalore positivo).")
        # Fitzgibbon: prendi l'autovettore con autovalore positivo (massimo)
        idx = cand[int(np.argmax(real_eigs[cand]))]
        sol = eigvecs[:, idx].real

        A_, B_, C_, D_, E_, F_ = sol
        disc = B_**2 - 4.0 * A_ * C_
        if disc >= 0:
            raise Exception(f"Conica non è un'ellisse (B²-4AC={disc:.3e}).")

        # Centro nelle coordinate normalizzate
        xc_n = (2.0 * C_ * D_ - B_ * E_) / disc
        yc_n = (2.0 * A_ * E_ - B_ * D_) / disc

        num = 2.0 * (A_ * E_**2 + C_ * D_**2 - B_ * D_ * E_ + disc * F_)
        s_  = np.sqrt((A_ - C_)**2 + B_**2)
        d1  = disc * ((A_ + C_) + s_)
        d2  = disc * ((A_ + C_) - s_)
        # Le quantità num/d possono essere negative per problemi numerici
        a_n = float(np.sqrt(abs(num / d1)))
        b_n = float(np.sqrt(abs(num / d2)))

        if a_n >= b_n:
            theta = 0.5 * np.arctan2(B_, A_ - C_)
        else:
            a_n, b_n = b_n, a_n
            theta = 0.5 * np.arctan2(B_, A_ - C_) + np.pi / 2.0

        # Riporta a coordinate originali
        xc = xc_n * scale + x_mean
        yc = yc_n * scale + y_mean
        a  = a_n * scale
        b  = b_n * scale
        theta = float(theta % np.pi)
        return xc, yc, a, b, theta

    @staticmethod
    def _ellipse_residuals(xy, xc, yc, a, b, theta):
        """
        Per ogni punto calcola: angolo parametrico, proiezione approssimata
        sull'ellisse (lungo lo stesso angolo parametrico), residuo.
        """
        cos_t = np.cos(theta); sin_t = np.sin(theta)
        dx = xy[:, 0] - xc
        dy = xy[:, 1] - yc
        # Sistema locale dell'ellisse (asse maggiore = x_local)
        xl = dx * cos_t + dy * sin_t
        yl = -dx * sin_t + dy * cos_t
        # Angolo parametrico
        t_param = np.arctan2(yl / b, xl / a)
        # Proiezione sull'ellisse con stesso angolo parametrico
        pxl = a * np.cos(t_param)
        pyl = b * np.sin(t_param)
        # Riporta alle coordinate globali
        proj_x = xc + pxl * cos_t - pyl * sin_t
        proj_y = yc + pxl * sin_t + pyl * cos_t
        residual = np.sqrt((xy[:, 0] - proj_x)**2 + (xy[:, 1] - proj_y)**2)
        return t_param, proj_x, proj_y, residual

    @staticmethod
    def _minimum_enclosing_arc(angles_raw):
        angles_norm = angles_raw % (2.0 * np.pi)
        ang_sorted  = np.sort(angles_norm)
        gaps        = np.diff(ang_sorted)
        wrap_gap    = ang_sorted[0] + 2.0 * np.pi - ang_sorted[-1]
        all_gaps    = np.append(gaps, wrap_gap)
        k           = int(np.argmax(all_gaps))
        if k == len(ang_sorted) - 1:
            return float(ang_sorted[0]), float(ang_sorted[-1])
        return float(ang_sorted[k + 1]), float(ang_sorted[k]) + 2.0 * np.pi

    @classmethod
    def _ransac_ellipse(cls, xy, threshold, max_iters, rng):
        n = len(xy)
        if n < 5:
            return None
        best_inliers = None
        best_count   = -1
        for _ in range(max_iters):
            idx = rng.choice(n, size=5, replace=False)
            try:
                cx, cy, a, b, th = cls._fit_ellipse_fitzgibbon(xy[idx])
            except Exception:
                continue
            _, _, _, res = cls._ellipse_residuals(xy, cx, cy, a, b, th)
            inliers = res <= threshold
            count   = int(inliers.sum())
            if count > best_count:
                best_count   = count
                best_inliers = inliers
        return best_inliers

    def processAlgorithm(self, parameters, context, feedback):
        source     = self.parameterAsSource(parameters, self.INPUT, context)
        out_type   = self.parameterAsEnum(parameters, self.OUTPUT_TYPE, context)
        n_segments = self.parameterAsInt(parameters, self.N_SEGMENTS, context)
        use_ransac = self.parameterAsBoolean(parameters, self.USE_RANSAC, context)
        ransac_th  = self.parameterAsDouble(parameters, self.RANSAC_THRESHOLD, context)
        outlier_k  = self.parameterAsDouble(parameters, self.OUTLIER_THRESHOLD, context)
        weight_fld = self.parameterAsString(parameters, self.WEIGHT_FIELD, context)

        crs = source.sourceCrs()
        if crs.isGeographic():
            feedback.pushWarning(
                "ATTENZIONE: il CRS è geografico. Riproietta in CRS proiettato.")

        # ── 1. Raccolta coordinate ────────────────────────────────────────────
        ids, xy, weights = [], [], []
        for feat in source.getFeatures():
            geom = feat.geometry()
            pt   = geom.constGet()
            ids.append(feat.id())
            xy.append([float(pt.x()), float(pt.y())])
            if weight_fld:
                w = feat[weight_fld]
                try:
                    w = float(w) if w is not None else 1.0
                except (TypeError, ValueError):
                    w = 1.0
                if w <= 0 or w != w:
                    w = 1.0
                weights.append(w)

        if len(xy) < 5:
            raise Exception("Servono almeno 5 punti per fittare un'ellisse.")
        xy          = np.array(xy, dtype=float)
        weights_arr = np.array(weights, dtype=float) if weights else None
        feedback.pushInfo(f"Punti letti: {len(xy)}")

        # ── 2. RANSAC opzionale ───────────────────────────────────────────────
        used_ransac    = False
        ransac_inliers = None
        if use_ransac:
            if ransac_th <= 0.0:
                pre = self._fit_ellipse_fitzgibbon(xy, weights_arr)
                _, _, _, pre_res = self._ellipse_residuals(xy, *pre)
                mad = float(np.median(np.abs(pre_res - np.median(pre_res))))
                ransac_th = max(2.5 * 1.4826 * mad, 1e-9)
                feedback.pushInfo(f"RANSAC soglia auto: {ransac_th:.6f}")
            rng     = np.random.default_rng(42)
            n_iters = max(200, min(5000, len(xy) * 50))
            inliers = self._ransac_ellipse(xy, ransac_th, n_iters, rng)
            if inliers is None or int(inliers.sum()) < 5:
                feedback.pushWarning(
                    "RANSAC non ha trovato abbastanza inlier. Uso fit standard.")
            else:
                used_ransac    = True
                ransac_inliers = inliers
                feedback.pushInfo(
                    f"RANSAC: {int(inliers.sum())}/{len(xy)} inlier "
                    f"({100.0 * inliers.sum() / len(xy):.1f}%)")

        # ── 3. Fit finale ─────────────────────────────────────────────────────
        if used_ransac:
            fit_xy      = xy[ransac_inliers]
            fit_weights = weights_arr[ransac_inliers] if weights_arr is not None else None
        else:
            fit_xy      = xy
            fit_weights = weights_arr
        cx, cy, a, b, theta = self._fit_ellipse_fitzgibbon(fit_xy, fit_weights)
        feedback.pushInfo(
            f"Centro: ({cx:.6f}, {cy:.6f})  "
            f"a={a:.6f}  b={b:.6f}  rot={np.degrees(theta):.2f}°")

        # ── 4. Residui (su TUTTI i punti) ─────────────────────────────────────
        t_param, proj_x, proj_y, residuals = self._ellipse_residuals(
            xy, cx, cy, a, b, theta)
        rmse = float(np.sqrt((residuals**2).mean()))
        eccentricity = float(np.sqrt(1.0 - (b / a)**2)) if a > 0 else 0.0

        # ── 5. Statistiche ────────────────────────────────────────────────────
        res_median = float(np.median(residuals))
        q1, q3     = np.percentile(residuals, [25, 75])
        iqr        = float(q3 - q1)
        outlier_threshold = outlier_k * rmse
        is_outlier_arr    = residuals > outlier_threshold
        n_outliers        = int(is_outlier_arr.sum())

        feedback.pushInfo(f"Eccentricità:    {eccentricity:.4f}")
        feedback.pushInfo(f"Residuo medio:   {residuals.mean():.6f}")
        feedback.pushInfo(f"Residuo mediano: {res_median:.6f}")
        feedback.pushInfo(f"RMSE:            {rmse:.6f}")
        feedback.pushInfo(
            f"Outlier (>{outlier_k}·RMSE): {n_outliers}/{len(xy)}")

        # ── 6. Intervallo angolare ────────────────────────────────────────────
        if out_type == 0:
            theta_start = 0.0
            theta_end   = 2.0 * np.pi
            arc_span    = 360.0
            feedback.pushInfo("Output: ellisse completa.")
        else:
            theta_start, theta_end = self._minimum_enclosing_arc(t_param)
            arc_span = float(np.degrees(theta_end - theta_start))
            feedback.pushInfo(
                f"Output: arco da {np.degrees(theta_start):.2f}° "
                f"a {np.degrees(theta_end):.2f}° "
                f"(ampiezza {arc_span:.2f}°).")

        # ── 7. Polilinea ──────────────────────────────────────────────────────
        cos_t = np.cos(theta); sin_t = np.sin(theta)
        ts = np.linspace(theta_start, theta_end, n_segments + 1)
        pxl = a * np.cos(ts)
        pyl = b * np.sin(ts)
        gx = cx + pxl * cos_t - pyl * sin_t
        gy = cy + pxl * sin_t + pyl * cos_t
        poly_pts = [QgsPointXY(float(gx[i]), float(gy[i])) for i in range(len(ts))]

        # ── 8. Output ellisse/arco ────────────────────────────────────────────
        fields_el = QgsFields()
        for name in ('center_x', 'center_y', 'semi_major', 'semi_minor',
                     'rotation_deg', 'eccentricity',
                     'rmse', 'residual_median', 'residual_iqr',
                     'arc_start_deg', 'arc_end_deg', 'arc_span_deg'):
            fields_el.append(QgsField(name, QVariant.Double))
        fields_el.append(QgsField('n_points',    QVariant.Int))
        fields_el.append(QgsField('n_used',      QVariant.Int))
        fields_el.append(QgsField('n_outliers',  QVariant.Int))
        fields_el.append(QgsField('output_type', QVariant.String))
        fields_el.append(QgsField('used_ransac', QVariant.Bool))

        (sink_el, dest_el) = self.parameterAsSink(
            parameters, self.OUTPUT_ELLIPSE, context,
            fields_el, QgsWkbTypes.LineString, source.sourceCrs())

        f_el = QgsFeature(fields_el)
        f_el.setGeometry(QgsGeometry.fromPolylineXY(poly_pts))
        f_el.setAttributes([
            float(cx), float(cy), float(a), float(b),
            float(np.degrees(theta) % 180.0), float(eccentricity),
            rmse, res_median, iqr,
            float(np.degrees(theta_start) % 360),
            float(np.degrees(theta_end)   % 360),
            float(arc_span),
            len(xy), len(fit_xy), n_outliers,
            'ellipse' if out_type == 0 else 'arc',
            bool(used_ransac),
        ])
        sink_el.addFeature(f_el)

        # ── 9. Output punti con residui ───────────────────────────────────────
        fields_pts = QgsFields()
        fields_pts.append(QgsField('fid',        QVariant.Int))
        fields_pts.append(QgsField('residual',   QVariant.Double))
        fields_pts.append(QgsField('angle_deg',  QVariant.Double))
        fields_pts.append(QgsField('proj_x',     QVariant.Double))
        fields_pts.append(QgsField('proj_y',     QVariant.Double))
        fields_pts.append(QgsField('is_outlier', QVariant.Bool))
        if used_ransac:
            fields_pts.append(QgsField('is_inlier', QVariant.Bool))
        if weights_arr is not None:
            fields_pts.append(QgsField('weight', QVariant.Double))

        (sink_pts, dest_pts) = self.parameterAsSink(
            parameters, self.OUTPUT_POINTS, context,
            fields_pts, QgsWkbTypes.Point, source.sourceCrs())

        for i in range(len(xy)):
            f = QgsFeature(fields_pts)
            f.setGeometry(QgsGeometry.fromPointXY(
                QgsPointXY(float(xy[i, 0]), float(xy[i, 1]))))
            attrs = [
                int(ids[i]),
                float(residuals[i]),
                float(np.degrees(t_param[i]) % 360),
                float(proj_x[i]), float(proj_y[i]),
                bool(is_outlier_arr[i]),
            ]
            if used_ransac:
                attrs.append(bool(ransac_inliers[i]))
            if weights_arr is not None:
                attrs.append(float(weights_arr[i]))
            f.setAttributes(attrs)
            sink_pts.addFeature(f)

        return {self.OUTPUT_ELLIPSE: dest_el, self.OUTPUT_POINTS: dest_pts}

    def name(self):           return 'bestfitellipse'
    def displayName(self):    return 'Best-fit Ellipse/Arc 2D (Fitzgibbon)'
    def group(self):          return 'Best-fit'
    def groupId(self):        return 'best-fit'
    def createInstance(self): return BestFitEllipse()
