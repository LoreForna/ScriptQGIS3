from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterNumber,
    QgsProcessingParameterField,
    QgsProcessingParameterBoolean,
    QgsFeature, QgsGeometry, QgsWkbTypes,
    QgsFields, QgsField, QgsPoint, QgsPointXY,
    QgsPolygon, QgsLineString,
)
try:
    from qgis.PyQt.QtCore import QVariant
except ImportError:
    # QGIS 4 / PyQt6: QVariant non esiste piu' — usa QMetaType
    from qgis.PyQt.QtCore import QMetaType
    class QVariant:
        Double = QMetaType.Type.Double
        Int    = QMetaType.Type.Int
        String = QMetaType.Type.QString
        Bool   = QMetaType.Type.Bool
import numpy as np


class BestFitPlane(QgsProcessingAlgorithm):

    INPUT             = 'INPUT'
    WEIGHT_FIELD      = 'WEIGHT_FIELD'
    OUTPUT_PLANE      = 'OUTPUT_PLANE'
    OUTPUT_POINTS     = 'OUTPUT_POINTS'
    USE_RANSAC        = 'USE_RANSAC'
    RANSAC_THRESHOLD  = 'RANSAC_THRESHOLD'
    OUTLIER_THRESHOLD = 'OUTLIER_THRESHOLD'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, 'Layer di punti 3D',
            [QgsProcessing.TypeVectorPoint]))

        self.addParameter(QgsProcessingParameterField(
            self.WEIGHT_FIELD,
            'Campo peso (opzionale)',
            parentLayerParameterName=self.INPUT,
            type=QgsProcessingParameterField.Numeric,
            optional=True))

        self.addParameter(QgsProcessingParameterBoolean(
            self.USE_RANSAC,
            'Usa RANSAC (robusto agli outlier)',
            defaultValue=False))

        self.addParameter(QgsProcessingParameterNumber(
            self.RANSAC_THRESHOLD,
            'RANSAC: soglia inlier (unità mappa, 0 = auto)',
            defaultValue=0.0, minValue=0.0,
            type=QgsProcessingParameterNumber.Double))

        self.addParameter(QgsProcessingParameterNumber(
            self.OUTLIER_THRESHOLD,
            'Soglia outlier (× RMSE)',
            defaultValue=2.5, minValue=0.0,
            type=QgsProcessingParameterNumber.Double))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_PLANE, 'Piano best-fit (rettangolo orientato)',
            QgsProcessing.TypeVectorPolygon))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_POINTS, 'Punti con residui',
            QgsProcessing.TypeVectorPoint))

    def shortHelpString(self):
        return """

<p>Calcola il <b>piano</b> che meglio approssima una nuvola di punti 3D, minimizzando le distanze ortogonali (Total Least Squares). Restituisce un rettangolo orientato sul piano che racchiude tutti i punti.</p>

<h4>Metodo di calcolo</h4>
<p>Si applica <b>PCA via SVD</b> sui punti centrati sul centroide. Gli autovettori sono gli assi principali della nuvola:</p>
<ol>
  <li><b>u1</b>: prima direzione del piano (massima varianza).</li>
  <li><b>u2</b>: seconda direzione del piano (varianza media).</li>
  <li><b>n = u3</b>: <b>normale al piano</b> (minima varianza). La distanza ortogonale di ogni punto dal piano è il suo residuo.</li>
</ol>

<h4>Strike e Dip (convenzione geologica)</h4>
<ul>
  <li><b>Dip</b>: inclinazione del piano (0° = orizzontale, 90° = verticale).</li>
  <li><b>Dip direction</b>: azimuth della linea di massima pendenza (verso il basso), 0–360° dal Nord in senso orario.</li>
  <li><b>Strike</b>: azimuth della linea orizzontale del piano = (dip_direction − 90°) mod 360 (regola della mano destra).</li>
</ul>

<h4>Output geometria</h4>
<p>Rettangolo 3D (PolygonZ) orientato lungo u1/u2 e dimensionato sui valori min/max delle proiezioni dei punti. Tutti i punti rientrano nella proiezione del rettangolo sul piano.</p>

<h4>Casi d'uso</h4>
<ul>
  <li>Pavimenti, lastricati, piani di calpestio archeologici (verifica planarità).</li>
  <li>Giaciture geologiche (faglie, strati, fratture).</li>
  <li>Pareti, muri, superfici di crollo.</li>
  <li>Adattamento di nuvole LIDAR/SfM a piani locali.</li>
</ul>

<h4>RANSAC (opzionale)</h4>
<p>Campiona terne random di punti, costruisce il piano per i 3 punti (prodotto vettoriale), conta gli inlier entro soglia e fa il fit finale solo sugli inlier del miglior modello. Soglia 0 = auto da MAD.</p>

<h4>Output — Piano</h4>
<ul>
  <li><b>centroid_x/y/z</b>, <b>normal_x/y/z</b>, <b>u1_x/y/z</b>, <b>u2_x/y/z</b>.</li>
  <li><b>strike_deg</b>, <b>dip_deg</b>, <b>dip_direction_deg</b>.</li>
  <li><b>rmse</b>, <b>residual_median</b>, <b>residual_iqr</b>.</li>
  <li><b>extent_u</b>, <b>extent_v</b>: dimensioni del rettangolo lungo u1 e u2.</li>
  <li><b>area</b>: area del rettangolo (= extent_u × extent_v).</li>
  <li><b>n_points</b>, <b>n_used</b>, <b>n_outliers</b>, <b>used_ransac</b>.</li>
</ul>

<h4>Output — Punti con residui</h4>
<ul>
  <li><b>fid</b>, <b>residual</b> (distanza ortogonale dal piano, con segno).</li>
  <li><b>residual_abs</b>: valore assoluto della distanza.</li>
  <li><b>u_param</b>, <b>v_param</b>: coordinate del punto nel sistema (u1, u2) del piano.</li>
  <li><b>proj_x/y/z</b>: proiezione del punto sul piano.</li>
  <li><b>is_outlier</b>, <b>is_inlier</b> (con RANSAC), <b>weight</b> (con campo peso).</li>
</ul>

<p><b>Nota CRS:</b> Per risultati corretti il layer deve essere in un CRS proiettato (metri).</p>
"""

    @staticmethod
    def _fit_plane_pca(coords, weights):
        """PCA (eventualmente pesata): restituisce centroide, u1, u2, normal."""
        if weights is None:
            centroid = coords.mean(axis=0)
            centered = coords - centroid
            _, _, Vt = np.linalg.svd(centered, full_matrices=False)
        else:
            w = weights / weights.sum()
            centroid = (w[:, None] * coords).sum(axis=0)
            centered = coords - centroid
            weighted = np.sqrt(weights)[:, None] * centered
            _, _, Vt = np.linalg.svd(weighted, full_matrices=False)
        u1     = Vt[0]
        u2     = Vt[1]
        normal = Vt[2]
        # Normale verso l'alto (Z+) per coerenza con strike/dip
        if normal[2] < 0:
            normal = -normal
        return centroid, u1, u2, normal

    @staticmethod
    def _ransac_plane(coords, threshold, max_iters, rng):
        """RANSAC: piano per 3 punti random."""
        n = len(coords)
        if n < 3:
            return None
        best_inliers = None
        best_count   = -1
        for _ in range(max_iters):
            idx = rng.choice(n, size=3, replace=False)
            p1, p2, p3 = coords[idx]
            v1 = p2 - p1
            v2 = p3 - p1
            normal = np.cross(v1, v2)
            norm   = np.linalg.norm(normal)
            if norm < 1e-12:
                continue
            normal /= norm
            dist = np.abs((coords - p1) @ normal)
            inliers = dist <= threshold
            count   = int(inliers.sum())
            if count > best_count:
                best_count   = count
                best_inliers = inliers
        return best_inliers

    def processAlgorithm(self, parameters, context, feedback):
        source     = self.parameterAsSource(parameters, self.INPUT, context)
        use_ransac = self.parameterAsBoolean(parameters, self.USE_RANSAC, context)
        ransac_th  = self.parameterAsDouble(parameters, self.RANSAC_THRESHOLD, context)
        outlier_k  = self.parameterAsDouble(parameters, self.OUTLIER_THRESHOLD, context)
        weight_fld = self.parameterAsString(parameters, self.WEIGHT_FIELD, context)

        # ── 0. Verifica CRS ────────────────────────────────────────────────────
        crs = source.sourceCrs()
        if crs.isGeographic():
            feedback.pushWarning(
                "ATTENZIONE: il CRS è geografico. Riproietta in CRS proiettato.")

        # ── 1. Raccolta coordinate 3D ─────────────────────────────────────────
        ids, coords, weights = [], [], []
        detected_z = False
        for feat in source.getFeatures():
            geom = feat.geometry()
            pt   = geom.constGet()
            has_z = (
                QgsWkbTypes.hasZ(geom.wkbType()) and pt.z() == pt.z()
            )
            z = pt.z() if has_z else 0.0
            if has_z and z != 0.0:
                detected_z = True
            ids.append(feat.id())
            coords.append([pt.x(), pt.y(), z])
            if weight_fld:
                w = feat[weight_fld]
                try:
                    w = float(w) if w is not None else 1.0
                except (TypeError, ValueError):
                    w = 1.0
                if w <= 0 or w != w:
                    w = 1.0
                weights.append(w)

        if len(coords) < 3:
            raise Exception("Servono almeno 3 punti per fittare un piano.")
        if not detected_z:
            feedback.pushWarning(
                "I punti non hanno coordinata Z reale: il fit del piano sarà "
                "degenere (piano orizzontale Z=0). Verifica che il layer sia 3D.")

        coords      = np.array(coords, dtype=float)
        weights_arr = np.array(weights, dtype=float) if weights else None

        # ── 2. RANSAC opzionale ───────────────────────────────────────────────
        used_ransac    = False
        ransac_inliers = None
        if use_ransac:
            if ransac_th <= 0.0:
                pre_c, _, _, pre_n = self._fit_plane_pca(coords, weights_arr)
                pre_res = np.abs((coords - pre_c) @ pre_n)
                mad = float(np.median(np.abs(pre_res - np.median(pre_res))))
                ransac_th = max(2.5 * 1.4826 * mad, 1e-9)
                feedback.pushInfo(f"RANSAC soglia auto: {ransac_th:.6f}")

            rng = np.random.default_rng(42)
            n_iters = max(200, min(5000, len(coords) * 50))
            inliers = self._ransac_plane(coords, ransac_th, n_iters, rng)
            if inliers is None or int(inliers.sum()) < 3:
                feedback.pushWarning(
                    "RANSAC non ha trovato abbastanza inlier. Uso fit standard.")
            else:
                used_ransac    = True
                ransac_inliers = inliers
                feedback.pushInfo(
                    f"RANSAC: {int(inliers.sum())}/{len(coords)} inlier "
                    f"({100.0 * inliers.sum() / len(coords):.1f}%)")

        # ── 3. Fit finale ─────────────────────────────────────────────────────
        if used_ransac:
            fit_coords  = coords[ransac_inliers]
            fit_weights = weights_arr[ransac_inliers] if weights_arr is not None else None
        else:
            fit_coords  = coords
            fit_weights = weights_arr

        centroid, u1, u2, normal = self._fit_plane_pca(fit_coords, fit_weights)

        # ── 4. Residui (su TUTTI i punti) ─────────────────────────────────────
        centered  = coords - centroid
        signed    = centered @ normal           # distanza con segno
        residuals = np.abs(signed)
        rmse      = float(np.sqrt((residuals ** 2).mean()))

        # ── 5. Coordinate nel sistema del piano (u1, u2) ──────────────────────
        u_param = centered @ u1
        v_param = centered @ u2
        proj    = coords - np.outer(signed, normal)

        # ── 6. Statistiche ────────────────────────────────────────────────────
        res_median = float(np.median(residuals))
        q1, q3     = np.percentile(residuals, [25, 75])
        iqr        = float(q3 - q1)
        outlier_threshold = outlier_k * rmse
        is_outlier_arr    = residuals > outlier_threshold
        n_outliers        = int(is_outlier_arr.sum())

        feedback.pushInfo(f"Centroide: {centroid.round(3)}")
        feedback.pushInfo(f"Normale:   {normal.round(4)}")
        feedback.pushInfo(f"u1:        {u1.round(4)}")
        feedback.pushInfo(f"u2:        {u2.round(4)}")
        feedback.pushInfo(f"Punti totali / fit: {len(coords)} / {len(fit_coords)}")
        feedback.pushInfo(f"RMSE:      {rmse:.6f}")
        feedback.pushInfo(f"Residuo mediano: {res_median:.6f}")
        feedback.pushInfo(f"Outlier (>{outlier_k}·RMSE): {n_outliers}/{len(coords)}")

        # ── 7. Strike e Dip ───────────────────────────────────────────────────
        nz_clamped = float(min(1.0, max(-1.0, normal[2])))
        dip = float(np.degrees(np.arccos(nz_clamped)))  # 0° = orizzontale
        # Dip direction: direzione orizzontale di massima pendenza (verso il basso)
        # = azimuth della proiezione XY di -normal? No: dato che normale verso l'alto,
        # ci si muove sul piano nella direzione (n_x, n_y) per scendere. Quindi:
        if abs(normal[0]) < 1e-12 and abs(normal[1]) < 1e-12:
            dip_dir = 0.0  # piano orizzontale: dip direction indefinita
        else:
            dip_dir = float(np.degrees(np.arctan2(normal[0], normal[1])) % 360.0)
        strike = (dip_dir - 90.0) % 360.0
        feedback.pushInfo(f"Dip: {dip:.2f}° | Dip dir: {dip_dir:.2f}° | Strike: {strike:.2f}°")

        # ── 8. Rettangolo orientato sul piano ─────────────────────────────────
        u_min, u_max = float(u_param.min()), float(u_param.max())
        v_min, v_max = float(v_param.min()), float(v_param.max())
        extent_u = u_max - u_min
        extent_v = v_max - v_min
        area     = extent_u * extent_v

        corners_uv = [
            (u_min, v_min),
            (u_max, v_min),
            (u_max, v_max),
            (u_min, v_max),
            (u_min, v_min),  # chiusura
        ]
        corners_3d = [centroid + u * u1 + v * u2 for (u, v) in corners_uv]

        # ── 9. Costruzione PolygonZ ───────────────────────────────────────────
        ring = QgsLineString()
        for c in corners_3d:
            ring.addVertex(QgsPoint(float(c[0]), float(c[1]), float(c[2])))
        polygon = QgsPolygon()
        polygon.setExteriorRing(ring)
        plane_geom = QgsGeometry(polygon)

        # ── 10. Output piano ──────────────────────────────────────────────────
        fields_pl = QgsFields()
        for name in ('centroid_x', 'centroid_y', 'centroid_z',
                     'normal_x', 'normal_y', 'normal_z',
                     'u1_x', 'u1_y', 'u1_z',
                     'u2_x', 'u2_y', 'u2_z',
                     'strike_deg', 'dip_deg', 'dip_direction_deg',
                     'rmse', 'residual_median', 'residual_iqr',
                     'extent_u', 'extent_v', 'area'):
            fields_pl.append(QgsField(name, QVariant.Double))
        fields_pl.append(QgsField('n_points',    QVariant.Int))
        fields_pl.append(QgsField('n_used',      QVariant.Int))
        fields_pl.append(QgsField('n_outliers',  QVariant.Int))
        fields_pl.append(QgsField('used_ransac', QVariant.Bool))

        (sink_pl, dest_pl) = self.parameterAsSink(
            parameters, self.OUTPUT_PLANE, context,
            fields_pl, QgsWkbTypes.PolygonZ, source.sourceCrs())

        f_pl = QgsFeature(fields_pl)
        f_pl.setGeometry(plane_geom)
        f_pl.setAttributes([
            float(centroid[0]), float(centroid[1]), float(centroid[2]),
            float(normal[0]), float(normal[1]), float(normal[2]),
            float(u1[0]), float(u1[1]), float(u1[2]),
            float(u2[0]), float(u2[1]), float(u2[2]),
            strike, dip, dip_dir,
            rmse, res_median, iqr,
            float(extent_u), float(extent_v), float(area),
            len(coords), len(fit_coords), n_outliers,
            bool(used_ransac),
        ])
        sink_pl.addFeature(f_pl)

        # ── 11. Output punti ──────────────────────────────────────────────────
        fields_pts = QgsFields()
        fields_pts.append(QgsField('fid',          QVariant.Int))
        fields_pts.append(QgsField('residual',     QVariant.Double))
        fields_pts.append(QgsField('residual_abs', QVariant.Double))
        fields_pts.append(QgsField('u_param',      QVariant.Double))
        fields_pts.append(QgsField('v_param',      QVariant.Double))
        fields_pts.append(QgsField('proj_x',       QVariant.Double))
        fields_pts.append(QgsField('proj_y',       QVariant.Double))
        fields_pts.append(QgsField('proj_z',       QVariant.Double))
        fields_pts.append(QgsField('is_outlier',   QVariant.Bool))
        if used_ransac:
            fields_pts.append(QgsField('is_inlier', QVariant.Bool))
        if weights_arr is not None:
            fields_pts.append(QgsField('weight', QVariant.Double))

        (sink_pts, dest_pts) = self.parameterAsSink(
            parameters, self.OUTPUT_POINTS, context,
            fields_pts, QgsWkbTypes.PointZ, source.sourceCrs())

        for i in range(len(coords)):
            pt = coords[i]
            f  = QgsFeature(fields_pts)
            f.setGeometry(QgsGeometry.fromPoint(QgsPoint(pt[0], pt[1], pt[2])))
            attrs = [
                int(ids[i]),
                float(signed[i]),
                float(residuals[i]),
                float(u_param[i]), float(v_param[i]),
                float(proj[i, 0]), float(proj[i, 1]), float(proj[i, 2]),
                bool(is_outlier_arr[i]),
            ]
            if used_ransac:
                attrs.append(bool(ransac_inliers[i]))
            if weights_arr is not None:
                attrs.append(float(weights_arr[i]))
            f.setAttributes(attrs)
            sink_pts.addFeature(f)

        return {self.OUTPUT_PLANE: dest_pl, self.OUTPUT_POINTS: dest_pts}

    def name(self):           return 'bestfitplane'
    def displayName(self):    return 'Best-fit Plane 3D (PCA)'
    def group(self):          return 'Best-fit'
    def groupId(self):        return 'best-fit'
    def createInstance(self): return BestFitPlane()
