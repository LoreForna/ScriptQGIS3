from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsFeature, QgsGeometry, QgsWkbTypes,
    QgsFields, QgsField, QgsPointXY,
)
try:
    from qgis.PyQt.QtCore import QVariant
except ImportError:
    # QGIS 4 / PyQt6: QVariant non esiste piu' — usa QMetaType
    from qgis.PyQt.QtCore import QMetaType
    class QVariant:
        Double = QMetaType.Type.Double
        Int    = QMetaType.Type.Int
        String = QMetaType.Type.QString
        Bool   = QMetaType.Type.Bool
import numpy as np


class BestFitPolyline(QgsProcessingAlgorithm):

    INPUT             = 'INPUT'
    OUTPUT_SEGMENTS   = 'OUTPUT_SEGMENTS'
    OUTPUT_POLYLINE   = 'OUTPUT_POLYLINE'
    OUTPUT_POINTS     = 'OUTPUT_POINTS'
    MAX_SEGMENTS      = 'MAX_SEGMENTS'
    MIN_INLIERS       = 'MIN_INLIERS'
    THRESHOLD         = 'THRESHOLD'
    CONNECT_SEGMENTS  = 'CONNECT_SEGMENTS'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, 'Layer di punti 2D (Z ignorata)',
            [QgsProcessing.TypeVectorPoint]))

        self.addParameter(QgsProcessingParameterNumber(
            self.MAX_SEGMENTS,
            'Numero massimo di segmenti',
            defaultValue=5, minValue=1,
            type=QgsProcessingParameterNumber.Integer))

        self.addParameter(QgsProcessingParameterNumber(
            self.MIN_INLIERS,
            'Punti minimi per accettare un segmento',
            defaultValue=4, minValue=2,
            type=QgsProcessingParameterNumber.Integer))

        self.addParameter(QgsProcessingParameterNumber(
            self.THRESHOLD,
            'Soglia inlier (unità mappa, 0 = auto)',
            defaultValue=0.0, minValue=0.0,
            type=QgsProcessingParameterNumber.Double))

        self.addParameter(QgsProcessingParameterBoolean(
            self.CONNECT_SEGMENTS,
            'Connetti i segmenti in una spezzata continua',
            defaultValue=True))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_SEGMENTS, 'Segmenti (uno per feature)',
            QgsProcessing.TypeVectorLine))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_POLYLINE, 'Spezzata connessa',
            QgsProcessing.TypeVectorLine))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_POINTS, 'Punti con id segmento',
            QgsProcessing.TypeVectorPoint))

    def shortHelpString(self):
        return """

<p>Approssima una nuvola di punti con una <b>spezzata multi-segmento</b>: utile quando i punti formano una <b>L</b>, uno <b>zigzag</b> o un <b>perimetro spigoloso</b> (es. perimetro di un edificio, muri perimetrali con angoli).</p>

<h4>Metodo: Sequential RANSAC</h4>
<ol>
  <li>Cerca con RANSAC la retta con più inlier tra tutti i punti.</li>
  <li>Fitta una retta PCA esatta sugli inlier; estremi del segmento in t_min/t_max lungo la retta.</li>
  <li>Rimuove gli inlier dal pool e ripete sui punti rimanenti.</li>
  <li>Termina quando: i punti rimanenti sono meno della soglia minima, oppure è raggiunto il numero massimo di segmenti.</li>
</ol>

<h4>Connessione dei segmenti (opzionale)</h4>
<p>Se attivata, i segmenti vengono ordinati e collegati ai vertici più vicini, producendo una polilinea continua. Se disattivata, ogni segmento resta indipendente.</p>

<h4>Parametri</h4>
<ul>
  <li><b>Numero massimo di segmenti</b>: limite superiore al numero di rette estratte.</li>
  <li><b>Punti minimi per accettare un segmento</b>: un segmento con meno di N inlier viene scartato.</li>
  <li><b>Soglia inlier</b>: distanza max per considerare un punto inlier (0 = auto da MAD globale).</li>
  <li><b>Connetti i segmenti</b>: produce anche la spezzata continua oltre ai segmenti separati.</li>
</ul>

<h4>Output</h4>
<ul>
  <li><b>Segmenti</b>: un feature per segmento, con <i>segment_id, n_inliers, length, rmse, dir_x/y, azimuth_deg</i>.</li>
  <li><b>Spezzata connessa</b>: un'unica polilinea che unisce i segmenti per estremi più vicini.</li>
  <li><b>Punti con id segmento</b>: copia dei punti con <i>fid, segment_id</i> (-1 se non assegnato a nessun segmento), <i>residual</i>, <i>proj_x/y</i>.</li>
</ul>

<p><b>Nota:</b> L'algoritmo è 2D (Z ignorata). Per dati 3D, considera una pre-proiezione su un piano best-fit.</p>
"""

    @staticmethod
    def _fit_pca_line(coords):
        """Restituisce centroide, direzione (XY), residui e estremi (t_min, t_max)."""
        centroid = coords.mean(axis=0)
        centered = coords - centroid
        _, _, Vt = np.linalg.svd(centered, full_matrices=False)
        direction = Vt[0]
        t_vals    = centered @ direction
        proj      = centroid + np.outer(t_vals, direction)
        residuals = np.linalg.norm(coords - proj, axis=1)
        return centroid, direction, t_vals, proj, residuals

    @staticmethod
    def _ransac_line_2d(coords, threshold, max_iters, rng):
        n = len(coords)
        if n < 2:
            return None
        best_inliers = None
        best_count   = -1
        for _ in range(max_iters):
            i, j = rng.choice(n, size=2, replace=False)
            d = coords[j] - coords[i]
            norm = np.linalg.norm(d)
            if norm < 1e-12:
                continue
            d = d / norm
            diff = coords - coords[i]
            t = diff @ d
            proj = coords[i] + np.outer(t, d)
            dist = np.linalg.norm(coords - proj, axis=1)
            inliers = dist <= threshold
            count = int(inliers.sum())
            if count > best_count:
                best_count   = count
                best_inliers = inliers
        return best_inliers

    def processAlgorithm(self, parameters, context, feedback):
        source        = self.parameterAsSource(parameters, self.INPUT, context)
        max_segments  = self.parameterAsInt(parameters, self.MAX_SEGMENTS, context)
        min_inliers   = self.parameterAsInt(parameters, self.MIN_INLIERS, context)
        threshold     = self.parameterAsDouble(parameters, self.THRESHOLD, context)
        connect       = self.parameterAsBoolean(parameters, self.CONNECT_SEGMENTS, context)

        crs = source.sourceCrs()
        if crs.isGeographic():
            feedback.pushWarning(
                "ATTENZIONE: il CRS è geografico. Riproietta in CRS proiettato.")

        # ── 1. Raccolta coordinate (XY) ───────────────────────────────────────
        ids, xy = [], []
        for feat in source.getFeatures():
            geom = feat.geometry()
            pt   = geom.constGet()
            ids.append(feat.id())
            xy.append([float(pt.x()), float(pt.y())])
        if len(xy) < min_inliers:
            raise Exception(
                f"Servono almeno {min_inliers} punti (minimo accettabile per un segmento).")
        xy = np.array(xy, dtype=float)
        feedback.pushInfo(f"Punti letti: {len(xy)}")

        # ── 2. Soglia automatica se richiesta ─────────────────────────────────
        if threshold <= 0.0:
            # Soglia globale: una frazione della scala caratteristica della nuvola
            extent = float(np.linalg.norm(xy.max(axis=0) - xy.min(axis=0)))
            threshold = max(extent * 0.005, 1e-9)
            feedback.pushInfo(
                f"Soglia auto: {threshold:.6f} (~0.5% diagonale = {extent:.3f}).")

        # ── 3. Sequential RANSAC ─────────────────────────────────────────────
        rng = np.random.default_rng(42)
        n_iters_per_segment = max(200, min(3000, len(xy) * 30))

        remaining_idx = list(range(len(xy)))
        segments = []  # list of dicts
        seg_id_per_point = [-1] * len(xy)
        residual_per_point = [float('nan')] * len(xy)
        proj_per_point = [(float('nan'), float('nan'))] * len(xy)

        for k in range(max_segments):
            if len(remaining_idx) < min_inliers:
                feedback.pushInfo(
                    f"Stop: rimasti {len(remaining_idx)} punti < min ({min_inliers}).")
                break
            pts = xy[remaining_idx]
            inliers_mask = self._ransac_line_2d(pts, threshold, n_iters_per_segment, rng)
            if inliers_mask is None or int(inliers_mask.sum()) < min_inliers:
                feedback.pushInfo(
                    f"Stop: nessun segmento valido (max inlier "
                    f"{0 if inliers_mask is None else int(inliers_mask.sum())}).")
                break

            inlier_idx_local = np.where(inliers_mask)[0]
            inlier_idx_global = [remaining_idx[i] for i in inlier_idx_local]
            inlier_pts = xy[inlier_idx_global]

            centroid, direction, t_vals, proj, residuals = self._fit_pca_line(inlier_pts)
            t_lo, t_hi = float(t_vals.min()), float(t_vals.max())
            p1 = centroid + direction * t_lo
            p2 = centroid + direction * t_hi
            length  = t_hi - t_lo
            rmse    = float(np.sqrt((residuals**2).mean()))
            azimuth = float(np.degrees(np.arctan2(direction[0], direction[1])) % 360.0)

            segments.append({
                'id':       k,
                'p1':       p1,
                'p2':       p2,
                'centroid': centroid,
                'direction': direction,
                'n_inliers': len(inlier_idx_global),
                'length':   length,
                'rmse':     rmse,
                'azimuth':  azimuth,
            })

            for local_i, global_i in enumerate(inlier_idx_global):
                seg_id_per_point[global_i]   = k
                residual_per_point[global_i] = float(residuals[local_i])
                proj_per_point[global_i]     = (float(proj[local_i, 0]),
                                                float(proj[local_i, 1]))

            feedback.pushInfo(
                f"Segmento {k}: {len(inlier_idx_global)} inlier, "
                f"length={length:.3f}, rmse={rmse:.4f}, az={azimuth:.1f}°")

            # Rimuovi inlier dal pool
            remaining_set = set(remaining_idx) - set(inlier_idx_global)
            remaining_idx = sorted(remaining_set)

        if not segments:
            raise Exception("Nessun segmento estratto: prova ad alzare la soglia.")

        feedback.pushInfo(
            f"Segmenti totali: {len(segments)}. "
            f"Punti non assegnati: {len(remaining_idx)}.")

        # ── 4. Output segmenti ────────────────────────────────────────────────
        fields_seg = QgsFields()
        fields_seg.append(QgsField('segment_id', QVariant.Int))
        fields_seg.append(QgsField('n_inliers',  QVariant.Int))
        fields_seg.append(QgsField('length',     QVariant.Double))
        fields_seg.append(QgsField('rmse',       QVariant.Double))
        fields_seg.append(QgsField('dir_x',      QVariant.Double))
        fields_seg.append(QgsField('dir_y',      QVariant.Double))
        fields_seg.append(QgsField('azimuth_deg', QVariant.Double))

        (sink_seg, dest_seg) = self.parameterAsSink(
            parameters, self.OUTPUT_SEGMENTS, context,
            fields_seg, QgsWkbTypes.LineString, source.sourceCrs())

        for seg in segments:
            f = QgsFeature(fields_seg)
            f.setGeometry(QgsGeometry.fromPolylineXY([
                QgsPointXY(float(seg['p1'][0]), float(seg['p1'][1])),
                QgsPointXY(float(seg['p2'][0]), float(seg['p2'][1])),
            ]))
            f.setAttributes([
                int(seg['id']),
                int(seg['n_inliers']),
                float(seg['length']),
                float(seg['rmse']),
                float(seg['direction'][0]),
                float(seg['direction'][1]),
                float(seg['azimuth']),
            ])
            sink_seg.addFeature(f)

        # ── 5. Output spezzata connessa ──────────────────────────────────────
        fields_pl = QgsFields()
        fields_pl.append(QgsField('n_segments', QVariant.Int))
        fields_pl.append(QgsField('total_length', QVariant.Double))
        fields_pl.append(QgsField('mean_rmse', QVariant.Double))

        (sink_pl, dest_pl) = self.parameterAsSink(
            parameters, self.OUTPUT_POLYLINE, context,
            fields_pl, QgsWkbTypes.LineString, source.sourceCrs())

        if connect and len(segments) >= 1:
            polyline = self._connect_segments(segments)
            f_pl = QgsFeature(fields_pl)
            f_pl.setGeometry(QgsGeometry.fromPolylineXY(
                [QgsPointXY(float(p[0]), float(p[1])) for p in polyline]))
            total_len  = float(sum(s['length'] for s in segments))
            mean_rmse  = float(np.mean([s['rmse'] for s in segments]))
            f_pl.setAttributes([len(segments), total_len, mean_rmse])
            sink_pl.addFeature(f_pl)

        # ── 6. Output punti ───────────────────────────────────────────────────
        fields_pts = QgsFields()
        fields_pts.append(QgsField('fid',        QVariant.Int))
        fields_pts.append(QgsField('segment_id', QVariant.Int))
        fields_pts.append(QgsField('residual',   QVariant.Double))
        fields_pts.append(QgsField('proj_x',     QVariant.Double))
        fields_pts.append(QgsField('proj_y',     QVariant.Double))

        (sink_pts, dest_pts) = self.parameterAsSink(
            parameters, self.OUTPUT_POINTS, context,
            fields_pts, QgsWkbTypes.Point, source.sourceCrs())

        for i in range(len(xy)):
            f = QgsFeature(fields_pts)
            f.setGeometry(QgsGeometry.fromPointXY(
                QgsPointXY(float(xy[i, 0]), float(xy[i, 1]))))
            res = residual_per_point[i]
            px, py = proj_per_point[i]
            f.setAttributes([
                int(ids[i]),
                int(seg_id_per_point[i]),
                None if res != res else float(res),
                None if px != px else float(px),
                None if py != py else float(py),
            ])
            sink_pts.addFeature(f)

        return {
            self.OUTPUT_SEGMENTS: dest_seg,
            self.OUTPUT_POLYLINE: dest_pl,
            self.OUTPUT_POINTS:   dest_pts,
        }

    @staticmethod
    def _connect_segments(segments):
        """
        Concatena segmenti in una spezzata cercando ad ogni passo
        l'estremo più vicino del segmento successivo. Greedy.
        """
        if len(segments) == 1:
            return [segments[0]['p1'], segments[0]['p2']]

        used = [False] * len(segments)
        # Seed: segmento 0 nell'orientamento p1→p2
        used[0] = True
        polyline = [segments[0]['p1'], segments[0]['p2']]

        for _ in range(len(segments) - 1):
            current_end = polyline[-1]
            best_idx  = None
            best_dist = float('inf')
            best_swap = False
            for k, seg in enumerate(segments):
                if used[k]:
                    continue
                d1 = float(np.linalg.norm(seg['p1'] - current_end))
                d2 = float(np.linalg.norm(seg['p2'] - current_end))
                if d1 < best_dist:
                    best_dist, best_idx, best_swap = d1, k, False
                if d2 < best_dist:
                    best_dist, best_idx, best_swap = d2, k, True
            if best_idx is None:
                break
            seg = segments[best_idx]
            if best_swap:
                polyline.append(seg['p1'])
            else:
                polyline.append(seg['p2'])
            used[best_idx] = True
        return polyline

    def name(self):           return 'bestfitpolyline'
    def displayName(self):    return 'Best-fit Polyline (multi-segment RANSAC)'
    def group(self):          return 'Best-fit'
    def groupId(self):        return 'best-fit'
    def createInstance(self): return BestFitPolyline()
