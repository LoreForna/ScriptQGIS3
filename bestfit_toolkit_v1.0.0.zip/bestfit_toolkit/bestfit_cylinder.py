from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterNumber,
    QgsProcessingParameterEnum,
    QgsProcessingParameterField,
    QgsProcessingParameterBoolean,
    QgsFeature, QgsGeometry, QgsWkbTypes,
    QgsFields, QgsField, QgsPoint,
    QgsMultiLineString, QgsLineString,
)
try:
    from qgis.PyQt.QtCore import QVariant
except ImportError:
    # QGIS 4 / PyQt6: QVariant non esiste piu' — usa QMetaType
    from qgis.PyQt.QtCore import QMetaType
    class QVariant:
        Double = QMetaType.Type.Double
        Int    = QMetaType.Type.Int
        String = QMetaType.Type.QString
        Bool   = QMetaType.Type.Bool
import numpy as np


class BestFitCylinder(QgsProcessingAlgorithm):

    INPUT             = 'INPUT'
    WEIGHT_FIELD      = 'WEIGHT_FIELD'
    OUTPUT_CYLINDER   = 'OUTPUT_CYLINDER'
    OUTPUT_POINTS     = 'OUTPUT_POINTS'
    AXIS_MODE         = 'AXIS_MODE'
    AXIS_AZIMUTH      = 'AXIS_AZIMUTH'
    AXIS_PLUNGE       = 'AXIS_PLUNGE'
    REFINE_AXIS       = 'REFINE_AXIS'
    N_GENERATRICES    = 'N_GENERATRICES'
    N_SEGMENTS        = 'N_SEGMENTS'
    USE_RANSAC        = 'USE_RANSAC'
    RANSAC_THRESHOLD  = 'RANSAC_THRESHOLD'
    OUTLIER_THRESHOLD = 'OUTLIER_THRESHOLD'

    AXIS_OPTIONS = [
        'PCA (direzione di massima varianza)',
        'Verticale (Z+)',
        'Personalizzato (azimuth + plunge)',
    ]

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, 'Layer di punti 3D',
            [QgsProcessing.TypeVectorPoint]))

        self.addParameter(QgsProcessingParameterField(
            self.WEIGHT_FIELD,
            'Campo peso (opzionale)',
            parentLayerParameterName=self.INPUT,
            type=QgsProcessingParameterField.Numeric,
            optional=True))

        self.addParameter(QgsProcessingParameterEnum(
            self.AXIS_MODE,
            'Modalità asse iniziale',
            options=self.AXIS_OPTIONS, defaultValue=1))

        self.addParameter(QgsProcessingParameterNumber(
            self.AXIS_AZIMUTH,
            'Asse personalizzato — azimuth (gradi, dal Nord)',
            defaultValue=0.0, minValue=0.0, maxValue=360.0,
            type=QgsProcessingParameterNumber.Double))

        self.addParameter(QgsProcessingParameterNumber(
            self.AXIS_PLUNGE,
            'Asse personalizzato — plunge (gradi, 0 = orizzontale, 90 = verticale)',
            defaultValue=90.0, minValue=0.0, maxValue=90.0,
            type=QgsProcessingParameterNumber.Double))

        self.addParameter(QgsProcessingParameterBoolean(
            self.REFINE_AXIS,
            'Raffina asse iterativamente (consigliato)',
            defaultValue=True))

        self.addParameter(QgsProcessingParameterNumber(
            self.N_GENERATRICES,
            'Numero di generatrici (linee verticali)',
            defaultValue=12, minValue=2,
            type=QgsProcessingParameterNumber.Integer))

        self.addParameter(QgsProcessingParameterNumber(
            self.N_SEGMENTS,
            'Segmenti per cerchio',
            defaultValue=72, minValue=8,
            type=QgsProcessingParameterNumber.Integer))

        self.addParameter(QgsProcessingParameterBoolean(
            self.USE_RANSAC,
            'Usa RANSAC (robusto agli outlier)',
            defaultValue=False))

        self.addParameter(QgsProcessingParameterNumber(
            self.RANSAC_THRESHOLD,
            'RANSAC: soglia inlier (unità mappa, 0 = auto)',
            defaultValue=0.0, minValue=0.0,
            type=QgsProcessingParameterNumber.Double))

        self.addParameter(QgsProcessingParameterNumber(
            self.OUTLIER_THRESHOLD,
            'Soglia outlier (× RMSE)',
            defaultValue=2.5, minValue=0.0,
            type=QgsProcessingParameterNumber.Double))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_CYLINDER, 'Cilindro best-fit (wireframe)',
            QgsProcessing.TypeVectorLine))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_POINTS, 'Punti con residui',
            QgsProcessing.TypeVectorPoint))

    def shortHelpString(self):
        return """

<p>Calcola il <b>cilindro</b> 3D che meglio approssima una nuvola di punti, definito da un asse (linea) e un raggio. Pensato per oggetti allungati come <b>colonne</b>, <b>tronchi/alberi</b>, <b>tubazioni</b>, <b>condotte</b>, <b>silos</b>.</p>

<h4>Metodo</h4>
<p>L'algoritmo procede in due fasi:</p>
<ol>
  <li><b>Stima iniziale dell'asse</b>:
    <ul>
      <li><i>PCA</i>: il primo autovettore della nuvola (massima varianza) è la direzione dell'asse.</li>
      <li><i>Verticale</i>: asse forzato lungo Z+ (default per colonne/alberi).</li>
      <li><i>Personalizzato</i>: l'utente fornisce azimuth (0–360°, dal Nord) e plunge (0–90°).</li>
    </ul>
  </li>
  <li><b>Fit del cerchio</b> nel piano perpendicolare all'asse, con i punti proiettati. Si ottiene il centro (sull'asse) e il raggio.</li>
  <li><b>Raffinamento iterativo</b> (opzionale, default ON): aggiusta la direzione dell'asse minimizzando i residui, alternando fit-cerchio e ottimizzazione gradiente sull'asse, fino a convergenza o 20 iterazioni.</li>
</ol>

<h4>Output geometria</h4>
<p>MultiLineStringZ con: cerchio inferiore + cerchio superiore + N generatrici (linee verticali sui lati) + asse al centro. La quota inferiore/superiore è data dalle proiezioni min/max dei punti sull'asse.</p>

<h4>RANSAC (opzionale)</h4>
<p>Strato esterno di robustezza: campiona terne di punti, fitta un cerchio nel piano XY perpendicolare all'asse iniziale e identifica gli inlier. Il fit finale (con eventuale raffinamento) è applicato solo agli inlier.</p>

<h4>Output — Cilindro</h4>
<ul>
  <li><b>axis_x/y/z</b>: punto sull'asse (centro del segmento di cilindro).</li>
  <li><b>dir_x/y/z</b>: vettore unitario dell'asse.</li>
  <li><b>azimuth_deg</b>, <b>plunge_deg</b>: orientazione dell'asse.</li>
  <li><b>radius</b>, <b>height</b>: dimensioni.</li>
  <li><b>volume</b> = π·r²·h, <b>lateral_surface</b> = 2·π·r·h.</li>
  <li><b>rmse</b>, <b>residual_median</b>, <b>residual_iqr</b>.</li>
  <li><b>n_points</b>, <b>n_used</b>, <b>n_outliers</b>, <b>used_ransac</b>, <b>refined</b>.</li>
</ul>

<h4>Output — Punti con residui</h4>
<ul>
  <li><b>fid</b>, <b>residual</b> (= | distanza_da_asse − raggio |).</li>
  <li><b>t_axis</b>: ascissa del punto lungo l'asse, dal centro.</li>
  <li><b>angle_deg</b>: angolo del punto attorno all'asse (0–360°).</li>
  <li><b>proj_x/y/z</b>: proiezione del punto sulla superficie del cilindro.</li>
  <li><b>is_outlier</b>, <b>is_inlier</b> (con RANSAC), <b>weight</b> (con campo peso).</li>
</ul>

<p><b>Nota CRS:</b> Il layer deve essere in un CRS proiettato (metri) e i punti devono avere Z reale.</p>
"""

    @staticmethod
    def _orthonormal_basis(d):
        """Restituisce due vettori unitari u1, u2 ortogonali a d (e tra loro)."""
        d = d / np.linalg.norm(d)
        # Scelta del vettore "ausiliario" il meno parallelo a d
        if abs(d[2]) < 0.9:
            tmp = np.array([0.0, 0.0, 1.0])
        else:
            tmp = np.array([1.0, 0.0, 0.0])
        u1 = np.cross(d, tmp); u1 /= np.linalg.norm(u1)
        u2 = np.cross(d, u1);  u2 /= np.linalg.norm(u2)
        return u1, u2

    @staticmethod
    def _fit_circle_2d(xy, weights=None):
        """Kasa fit con normalizzazione (vedi bestfit_circle)."""
        x_mean = float(xy[:, 0].mean())
        y_mean = float(xy[:, 1].mean())
        scale  = float(np.sqrt(((xy[:, 0] - x_mean)**2 +
                                (xy[:, 1] - y_mean)**2).mean()))
        if scale < 1e-10:
            raise Exception("Punti coincidenti nel piano della sezione.")
        xn = (xy[:, 0] - x_mean) / scale
        yn = (xy[:, 1] - y_mean) / scale
        rhs   = xn**2 + yn**2
        A_mat = np.column_stack([xn, yn, np.ones(len(xn))])
        if weights is not None:
            w = np.sqrt(weights)
            A_mat = A_mat * w[:, None]
            rhs   = rhs * w
        res, _, _, _ = np.linalg.lstsq(A_mat, rhs, rcond=None)
        cx_n = float(res[0]) / 2.0
        cy_n = float(res[1]) / 2.0
        r2_n = float(res[2]) + cx_n**2 + cy_n**2
        if r2_n <= 0:
            raise Exception("Punti collineari nel piano della sezione.")
        cx = cx_n * scale + x_mean
        cy = cy_n * scale + y_mean
        r  = float(np.sqrt(r2_n)) * scale
        return cx, cy, r

    @classmethod
    def _fit_cylinder_given_axis(cls, coords, direction, weights=None):
        """Fit cilindro con asse fissato. Restituisce (axis_point, radius)."""
        u1, u2 = cls._orthonormal_basis(direction)
        proj_uv = np.column_stack([coords @ u1, coords @ u2])
        cu, cv, r = cls._fit_circle_2d(proj_uv, weights)
        # Punto sull'asse = cu*u1 + cv*u2 (la componente lungo l'asse è arbitraria;
        # la fissiamo a 0 nel sistema globale → proiezione del centro sull'asse passa
        # per origine. Per rendere invariante alla scelta del punto, usiamo la
        # proiezione sull'asse del centroide dei punti).
        axis_point = cu * u1 + cv * u2
        return axis_point, float(r), u1, u2

    @classmethod
    def _residuals_cyl(cls, coords, axis_point, direction, radius):
        """Distanza di ogni punto dalla superficie del cilindro (segnata? assoluta?)."""
        d = direction / np.linalg.norm(direction)
        # Proiezione su asse (componente lungo d)
        delta = coords - axis_point
        t_axis = delta @ d
        # Proiezione perpendicolare
        perp = delta - np.outer(t_axis, d)
        dist_axis = np.linalg.norm(perp, axis=1)
        residual = np.abs(dist_axis - radius)
        return t_axis, dist_axis, perp, residual

    @classmethod
    def _refine_axis(cls, coords, direction, weights, max_iters, tol):
        """
        Raffinamento numerico dell'asse: parametrizza la direzione con
        2 angoli (theta, phi) e minimizza la somma dei quadrati dei residui.
        Usa una semplice ricerca a discesa con perturbazione finita.
        """
        d = direction / np.linalg.norm(direction)
        # Parametrizza in spherical (theta = azimuth in XY, phi = dal piano XY)
        # Inizializzazione
        theta = float(np.arctan2(d[0], d[1]))
        phi   = float(np.arcsin(np.clip(d[2], -1.0, 1.0)))

        def axis_from(theta, phi):
            return np.array([
                np.cos(phi) * np.sin(theta),
                np.cos(phi) * np.cos(theta),
                np.sin(phi),
            ])

        def cost(theta, phi):
            d2 = axis_from(theta, phi)
            try:
                ap, r, _, _ = cls._fit_cylinder_given_axis(coords, d2, weights)
            except Exception:
                return float('inf'), None, None
            _, _, _, res = cls._residuals_cyl(coords, ap, d2, r)
            return float((res**2).sum()), ap, r

        best_cost, best_ap, best_r = cost(theta, phi)
        step = np.radians(5.0)
        for it in range(max_iters):
            improved = False
            for dt in (-step, 0.0, step):
                for dp in (-step, 0.0, step):
                    if dt == 0.0 and dp == 0.0:
                        continue
                    c, ap, r = cost(theta + dt, phi + dp)
                    if c < best_cost - tol:
                        best_cost = c
                        best_ap   = ap
                        best_r    = r
                        theta    += dt
                        phi      += dp
                        improved = True
                        break
                if improved:
                    break
            if not improved:
                step /= 2.0
                if step < np.radians(0.05):
                    break

        d_final = axis_from(theta, phi)
        return d_final, best_ap, best_r

    @classmethod
    def _ransac_cylinder(cls, coords, axis_init, threshold, max_iters, rng):
        """RANSAC: cerchi per 3 punti random nel piano perpendicolare ad axis_init."""
        n = len(coords)
        if n < 3:
            return None
        u1, u2 = cls._orthonormal_basis(axis_init)
        proj = np.column_stack([coords @ u1, coords @ u2])
        best_inliers = None
        best_count   = -1
        for _ in range(max_iters):
            idx = rng.choice(n, size=3, replace=False)
            try:
                cu, cv, r = cls._fit_circle_2d(proj[idx])
            except Exception:
                continue
            d = np.linalg.norm(proj - np.array([cu, cv]), axis=1)
            res = np.abs(d - r)
            inliers = res <= threshold
            count = int(inliers.sum())
            if count > best_count:
                best_count   = count
                best_inliers = inliers
        return best_inliers

    def processAlgorithm(self, parameters, context, feedback):
        source         = self.parameterAsSource(parameters, self.INPUT, context)
        axis_mode      = self.parameterAsEnum(parameters, self.AXIS_MODE, context)
        axis_az        = self.parameterAsDouble(parameters, self.AXIS_AZIMUTH, context)
        axis_pl        = self.parameterAsDouble(parameters, self.AXIS_PLUNGE, context)
        refine         = self.parameterAsBoolean(parameters, self.REFINE_AXIS, context)
        n_gen          = self.parameterAsInt(parameters, self.N_GENERATRICES, context)
        n_segments     = self.parameterAsInt(parameters, self.N_SEGMENTS, context)
        use_ransac     = self.parameterAsBoolean(parameters, self.USE_RANSAC, context)
        ransac_th      = self.parameterAsDouble(parameters, self.RANSAC_THRESHOLD, context)
        outlier_k      = self.parameterAsDouble(parameters, self.OUTLIER_THRESHOLD, context)
        weight_fld     = self.parameterAsString(parameters, self.WEIGHT_FIELD, context)

        crs = source.sourceCrs()
        if crs.isGeographic():
            feedback.pushWarning(
                "ATTENZIONE: il CRS è geografico. Riproietta in CRS proiettato.")

        # ── 1. Raccolta coordinate ────────────────────────────────────────────
        ids, xyz, weights = [], [], []
        detected_z = False
        for feat in source.getFeatures():
            geom = feat.geometry()
            pt   = geom.constGet()
            has_z = (
                QgsWkbTypes.hasZ(geom.wkbType()) and pt.z() == pt.z()
            )
            z = pt.z() if has_z else 0.0
            if has_z and z != 0.0:
                detected_z = True
            ids.append(feat.id())
            xyz.append([float(pt.x()), float(pt.y()), z])
            if weight_fld:
                w = feat[weight_fld]
                try:
                    w = float(w) if w is not None else 1.0
                except (TypeError, ValueError):
                    w = 1.0
                if w <= 0 or w != w:
                    w = 1.0
                weights.append(w)

        if len(xyz) < 6:
            raise Exception("Servono almeno 6 punti per fittare un cilindro.")
        if not detected_z:
            feedback.pushWarning("I punti non hanno Z reale: il fit sarà degenere.")

        xyz         = np.array(xyz, dtype=float)
        weights_arr = np.array(weights, dtype=float) if weights else None

        # Centriamo tutto sul centroide per stabilità numerica
        centroid = xyz.mean(axis=0)
        coords   = xyz - centroid
        feedback.pushInfo(f"Punti letti: {len(xyz)}")

        # ── 2. Direzione iniziale dell'asse ───────────────────────────────────
        if axis_mode == 1:
            axis0 = np.array([0.0, 0.0, 1.0])
            feedback.pushInfo("Asse iniziale: verticale (Z+).")
        elif axis_mode == 2:
            az = np.radians(axis_az)
            pl = np.radians(axis_pl)
            axis0 = np.array([
                np.cos(pl) * np.sin(az),
                np.cos(pl) * np.cos(az),
                np.sin(pl),
            ])
            feedback.pushInfo(
                f"Asse iniziale: az={axis_az:.1f}° pl={axis_pl:.1f}°  -> {axis0.round(4)}")
        else:
            _, _, Vt = np.linalg.svd(coords, full_matrices=False)
            axis0 = Vt[0]
            if axis0[2] < 0:
                axis0 = -axis0
            feedback.pushInfo(f"Asse iniziale (PCA): {axis0.round(4)}")

        # ── 3. RANSAC opzionale (sui punti centrati) ──────────────────────────
        used_ransac    = False
        ransac_inliers = None
        if use_ransac:
            if ransac_th <= 0.0:
                ap_pre, r_pre, _, _ = self._fit_cylinder_given_axis(coords, axis0, weights_arr)
                _, _, _, pre_res = self._residuals_cyl(coords, ap_pre, axis0, r_pre)
                mad = float(np.median(np.abs(pre_res - np.median(pre_res))))
                ransac_th = max(2.5 * 1.4826 * mad, 1e-9)
                feedback.pushInfo(f"RANSAC soglia auto: {ransac_th:.6f}")
            rng = np.random.default_rng(42)
            n_iters = max(200, min(5000, len(coords) * 50))
            inliers = self._ransac_cylinder(coords, axis0, ransac_th, n_iters, rng)
            if inliers is None or int(inliers.sum()) < 6:
                feedback.pushWarning(
                    "RANSAC non ha trovato abbastanza inlier. Uso fit standard.")
            else:
                used_ransac    = True
                ransac_inliers = inliers
                feedback.pushInfo(
                    f"RANSAC: {int(inliers.sum())}/{len(coords)} inlier "
                    f"({100.0 * inliers.sum() / len(coords):.1f}%)")

        # ── 4. Fit finale ─────────────────────────────────────────────────────
        if used_ransac:
            fit_coords  = coords[ransac_inliers]
            fit_weights = weights_arr[ransac_inliers] if weights_arr is not None else None
        else:
            fit_coords  = coords
            fit_weights = weights_arr

        axis_point, radius, _, _ = self._fit_cylinder_given_axis(fit_coords, axis0, fit_weights)
        direction = axis0.copy()
        refined = False
        if refine:
            try:
                direction, axis_point, radius = self._refine_axis(
                    fit_coords, direction, fit_weights, max_iters=20, tol=1e-9)
                refined = True
                feedback.pushInfo(f"Asse raffinato: {direction.round(4)}")
            except Exception as e:
                feedback.pushWarning(f"Raffinamento fallito: {e}. Uso asse iniziale.")

        direction = direction / np.linalg.norm(direction)
        if direction[2] < 0:
            direction = -direction
            # axis_point è invariato (è solo un punto, non dipende dal verso)

        feedback.pushInfo(f"Raggio: {radius:.6f}")

        # ── 5. Residui (su TUTTI i punti, in coords centrati) ─────────────────
        t_axis, dist_axis, perp, residuals = self._residuals_cyl(
            coords, axis_point, direction, radius)
        rmse = float(np.sqrt((residuals**2).mean()))

        # ── 6. Statistiche ────────────────────────────────────────────────────
        res_median = float(np.median(residuals))
        q1, q3     = np.percentile(residuals, [25, 75])
        iqr        = float(q3 - q1)
        outlier_threshold = outlier_k * rmse
        is_outlier_arr    = residuals > outlier_threshold
        n_outliers        = int(is_outlier_arr.sum())

        feedback.pushInfo(f"RMSE: {rmse:.6f} | Residuo mediano: {res_median:.6f}")
        feedback.pushInfo(
            f"Outlier (>{outlier_k}·RMSE): {n_outliers}/{len(coords)}")

        # ── 7. Estensione lungo l'asse ────────────────────────────────────────
        t_lo, t_hi = float(t_axis.min()), float(t_axis.max())
        height = t_hi - t_lo

        # Punti estremi del segmento d'asse (in coords originali)
        axis_point_world = axis_point + centroid
        p_top    = axis_point_world + direction * t_hi
        p_bottom = axis_point_world + direction * t_lo
        # Centro del segmento (per attributo)
        axis_center_world = axis_point_world + direction * ((t_lo + t_hi) / 2.0)

        # Azimuth e plunge dell'asse
        az_out = float(np.degrees(np.arctan2(direction[0], direction[1])) % 360.0)
        pl_out = float(np.degrees(np.arcsin(min(1.0, max(-1.0, direction[2])))))

        # ── 8. Wireframe cilindro ─────────────────────────────────────────────
        u1, u2 = self._orthonormal_basis(direction)
        thetas = np.linspace(0.0, 2.0 * np.pi, n_segments + 1)
        multi  = QgsMultiLineString()

        # Cerchio inferiore e superiore
        for end_pt in (p_bottom, p_top):
            ls = QgsLineString()
            for th in thetas:
                v = end_pt + radius * (np.cos(th) * u1 + np.sin(th) * u2)
                ls.addVertex(QgsPoint(float(v[0]), float(v[1]), float(v[2])))
            multi.addGeometry(ls)

        # Generatrici
        gen_thetas = np.linspace(0.0, 2.0 * np.pi, n_gen, endpoint=False)
        for th in gen_thetas:
            offset = radius * (np.cos(th) * u1 + np.sin(th) * u2)
            ls = QgsLineString()
            ls.addVertex(QgsPoint(float(p_bottom[0] + offset[0]),
                                  float(p_bottom[1] + offset[1]),
                                  float(p_bottom[2] + offset[2])))
            ls.addVertex(QgsPoint(float(p_top[0] + offset[0]),
                                  float(p_top[1] + offset[1]),
                                  float(p_top[2] + offset[2])))
            multi.addGeometry(ls)

        # Asse al centro
        ls_axis = QgsLineString()
        ls_axis.addVertex(QgsPoint(float(p_bottom[0]), float(p_bottom[1]), float(p_bottom[2])))
        ls_axis.addVertex(QgsPoint(float(p_top[0]),    float(p_top[1]),    float(p_top[2])))
        multi.addGeometry(ls_axis)

        cyl_geom = QgsGeometry(multi)

        # ── 9. Output cilindro ────────────────────────────────────────────────
        fields_cy = QgsFields()
        for name in ('axis_x', 'axis_y', 'axis_z',
                     'dir_x', 'dir_y', 'dir_z',
                     'azimuth_deg', 'plunge_deg',
                     'radius', 'height',
                     'rmse', 'residual_median', 'residual_iqr',
                     'volume', 'lateral_surface'):
            fields_cy.append(QgsField(name, QVariant.Double))
        fields_cy.append(QgsField('n_points',    QVariant.Int))
        fields_cy.append(QgsField('n_used',      QVariant.Int))
        fields_cy.append(QgsField('n_outliers',  QVariant.Int))
        fields_cy.append(QgsField('used_ransac', QVariant.Bool))
        fields_cy.append(QgsField('refined',     QVariant.Bool))

        (sink_cy, dest_cy) = self.parameterAsSink(
            parameters, self.OUTPUT_CYLINDER, context,
            fields_cy, QgsWkbTypes.MultiLineStringZ, source.sourceCrs())

        f_cy = QgsFeature(fields_cy)
        f_cy.setGeometry(cyl_geom)
        f_cy.setAttributes([
            float(axis_center_world[0]), float(axis_center_world[1]), float(axis_center_world[2]),
            float(direction[0]), float(direction[1]), float(direction[2]),
            az_out, pl_out,
            float(radius), float(height),
            rmse, res_median, iqr,
            float(np.pi * radius**2 * height),
            float(2.0 * np.pi * radius * height),
            len(coords), len(fit_coords), n_outliers,
            bool(used_ransac), bool(refined),
        ])
        sink_cy.addFeature(f_cy)

        # ── 10. Output punti con residui ──────────────────────────────────────
        fields_pts = QgsFields()
        fields_pts.append(QgsField('fid',        QVariant.Int))
        fields_pts.append(QgsField('residual',   QVariant.Double))
        fields_pts.append(QgsField('t_axis',     QVariant.Double))
        fields_pts.append(QgsField('angle_deg',  QVariant.Double))
        fields_pts.append(QgsField('proj_x',     QVariant.Double))
        fields_pts.append(QgsField('proj_y',     QVariant.Double))
        fields_pts.append(QgsField('proj_z',     QVariant.Double))
        fields_pts.append(QgsField('is_outlier', QVariant.Bool))
        if used_ransac:
            fields_pts.append(QgsField('is_inlier', QVariant.Bool))
        if weights_arr is not None:
            fields_pts.append(QgsField('weight', QVariant.Double))

        (sink_pts, dest_pts) = self.parameterAsSink(
            parameters, self.OUTPUT_POINTS, context,
            fields_pts, QgsWkbTypes.PointZ, source.sourceCrs())

        # Per ogni punto: proiezione sulla superficie del cilindro
        # = punto sull'asse alla quota t + radius * versore_radiale
        # Versore radiale = perp[i] / |perp[i]|
        for i in range(len(coords)):
            pt_world = xyz[i]
            f = QgsFeature(fields_pts)
            f.setGeometry(QgsGeometry.fromPoint(QgsPoint(pt_world[0], pt_world[1], pt_world[2])))

            d_axis = float(dist_axis[i])
            if d_axis > 1e-10:
                radial_unit = perp[i] / d_axis
            else:
                radial_unit = u1.copy()
            # Proj nel sistema centrato + ricolloca in coords mondo
            proj_centered = axis_point + direction * t_axis[i] + radius * radial_unit
            proj_world    = proj_centered + centroid

            # Angolo del punto attorno all'asse: in coordinate (u1, u2)
            ang_u = float(perp[i] @ u1)
            ang_v = float(perp[i] @ u2)
            angle_deg = float(np.degrees(np.arctan2(ang_v, ang_u)) % 360.0)

            attrs = [
                int(ids[i]),
                float(residuals[i]),
                float(t_axis[i]),
                angle_deg,
                float(proj_world[0]), float(proj_world[1]), float(proj_world[2]),
                bool(is_outlier_arr[i]),
            ]
            if used_ransac:
                attrs.append(bool(ransac_inliers[i]))
            if weights_arr is not None:
                attrs.append(float(weights_arr[i]))
            f.setAttributes(attrs)
            sink_pts.addFeature(f)

        return {self.OUTPUT_CYLINDER: dest_cy, self.OUTPUT_POINTS: dest_pts}

    def name(self):           return 'bestfitcylinder'
    def displayName(self):    return 'Best-fit Cylinder 3D'
    def group(self):          return 'Best-fit'
    def groupId(self):        return 'best-fit'
    def createInstance(self): return BestFitCylinder()
