from qgis.core import QgsApplication
from .provider import BestFitProvider


class BestFitToolkitPlugin:
    def __init__(self, iface):
        self.iface    = iface
        self.provider = None

    def initProcessing(self):
        self.provider = BestFitProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):
        self.initProcessing()

    def unload(self):
        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None
