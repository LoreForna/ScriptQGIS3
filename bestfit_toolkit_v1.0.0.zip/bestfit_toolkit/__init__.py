def classFactory(iface):
    from .plugin import BestFitToolkitPlugin
    return BestFitToolkitPlugin(iface)
