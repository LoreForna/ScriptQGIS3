from qgis.core import QgsProcessingProvider, QgsApplication

from .bestfit_line     import BestFitLine
from .bestfit_circle   import BestFitCircle
from .bestfit_plane    import BestFitPlane
from .bestfit_ellipse  import BestFitEllipse
from .bestfit_sphere   import BestFitSphere
from .bestfit_cylinder import BestFitCylinder
from .bestfit_polyline import BestFitPolyline


class BestFitProvider(QgsProcessingProvider):

    def loadAlgorithms(self):
        for cls in (
            BestFitLine,
            BestFitCircle,
            BestFitPlane,
            BestFitEllipse,
            BestFitSphere,
            BestFitCylinder,
            BestFitPolyline,
        ):
            self.addAlgorithm(cls())

    def id(self):
        return 'bestfit'

    def name(self):
        return 'Best-fit Toolkit'

    def longName(self):
        return self.name()

    def icon(self):
        return QgsApplication.getThemeIcon('/processingAlgorithm.svg')
