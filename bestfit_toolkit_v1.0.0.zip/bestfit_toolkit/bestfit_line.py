from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterNumber,
    QgsProcessingParameterEnum,
    QgsProcessingParameterField,
    QgsProcessingParameterBoolean,
    QgsFeature, QgsGeometry, QgsWkbTypes,
    QgsFields, QgsField, QgsPoint, QgsPointXY,
)
try:
    from qgis.PyQt.QtCore import QVariant
except ImportError:
    # QGIS 4 / PyQt6: QVariant non esiste piu' — usa QMetaType
    from qgis.PyQt.QtCore import QMetaType
    class QVariant:
        Double = QMetaType.Type.Double
        Int    = QMetaType.Type.Int
        String = QMetaType.Type.QString
        Bool   = QMetaType.Type.Bool
import numpy as np


class BestFitLine(QgsProcessingAlgorithm):

    INPUT             = 'INPUT'
    WEIGHT_FIELD      = 'WEIGHT_FIELD'
    OUTPUT_LINE       = 'OUTPUT_LINE'
    OUTPUT_POINTS     = 'OUTPUT_POINTS'
    EXTENSION         = 'EXTENSION'
    OUTPUT_MODE       = 'OUTPUT_MODE'
    USE_RANSAC        = 'USE_RANSAC'
    RANSAC_THRESHOLD  = 'RANSAC_THRESHOLD'
    OUTLIER_THRESHOLD = 'OUTLIER_THRESHOLD'

    MODE_OPTIONS = ['2D', '3D']

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, 'Layer di punti (2D o 3D)',
            [QgsProcessing.TypeVectorPoint]))

        self.addParameter(QgsProcessingParameterField(
            self.WEIGHT_FIELD,
            'Campo peso (opzionale; valori più alti = punti più affidabili)',
            parentLayerParameterName=self.INPUT,
            type=QgsProcessingParameterField.Numeric,
            optional=True))

        self.addParameter(QgsProcessingParameterNumber(
            self.EXTENSION,
            'Estensione della retta (0 = automatica dai punti)',
            defaultValue=0.0,
            minValue=0.0,
            type=QgsProcessingParameterNumber.Double))

        self.addParameter(QgsProcessingParameterEnum(
            self.OUTPUT_MODE, 'Tipo di output geometria',
            options=self.MODE_OPTIONS,
            defaultValue=0))

        self.addParameter(QgsProcessingParameterBoolean(
            self.USE_RANSAC,
            'Usa RANSAC (robusto agli outlier)',
            defaultValue=False))

        self.addParameter(QgsProcessingParameterNumber(
            self.RANSAC_THRESHOLD,
            'RANSAC: soglia inlier (unità mappa, 0 = auto)',
            defaultValue=0.0,
            minValue=0.0,
            type=QgsProcessingParameterNumber.Double))

        self.addParameter(QgsProcessingParameterNumber(
            self.OUTLIER_THRESHOLD,
            'Soglia outlier (× RMSE)',
            defaultValue=2.5,
            minValue=0.0,
            type=QgsProcessingParameterNumber.Double))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_LINE, 'Retta best-fit',
            QgsProcessing.TypeVectorLine))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_POINTS, 'Punti con residui',
            QgsProcessing.TypeVectorPoint))

    def shortHelpString(self):
        return """

<p>Calcola la retta di regressione che meglio approssima una nuvola di punti 2D o 3D, minimizzando le distanze ortogonali di tutti i punti dalla retta (<b>Total Least Squares</b>, anche detto <i>orthogonal regression</i>).</p>

<h4>Metodo di calcolo</h4>
<p>Il calcolo si basa su <b>PCA (Principal Component Analysis)</b> tramite decomposizione SVD (Singular Value Decomposition) della matrice dei punti centrati sul loro centroide. Se è specificato un campo peso, la PCA è pesata.</p>
<ol>
  <li>Si calcola il <b>centroide</b> (eventualmente pesato) della nuvola di punti.</li>
  <li>Si <b>centra</b> la nuvola sottraendo il centroide a ogni punto.</li>
  <li>Si applica la <b>SVD</b>: il primo autovettore (direzione di massima varianza) è la direzione della retta best-fit.</li>
  <li>Ogni punto viene <b>proiettato ortogonalmente</b> sulla retta tramite il prodotto scalare con il vettore direzione.</li>
  <li>Il <b>residuo</b> di ogni punto è la distanza euclidea tra il punto originale e la sua proiezione (in 2D la coordinata Z viene ignorata anche per il residuo).</li>
</ol>

<h4>RANSAC (opzionale)</h4>
<p>Se attivato, esegue <b>RANSAC</b> prima del fit finale: campiona ripetutamente coppie di punti, identifica gli inlier (punti entro la soglia) e infine fa un re-fit PCA solo sugli inlier del miglior modello. Utile quando una parte dei punti è palesemente sbagliata (errori GPS, punti spostati, ecc.). Se la soglia è 0 viene calcolata automaticamente da MAD (median absolute deviation) di un fit preliminare.</p>

<h4>Estensione automatica (t_min / t_max)</h4>
<p>Con estensione 0 gli estremi del segmento corrispondono alle proiezioni dei punti con valore minimo e massimo lungo la direzione della retta. Garantisce che tutti i punti rientrino nel segmento indipendentemente dall'ordine in cui sono stati misurati.</p>

<h4>Parametri</h4>
<ul>
  <li><b>Layer di punti</b>: layer vettoriale di punti, con o senza coordinata Z. Se è attiva una selezione, vengono usati solo i punti selezionati.</li>
  <li><b>Campo peso</b>: campo numerico opzionale; valori più alti danno più peso al punto nel fit (es. inverso della varianza GPS).</li>
  <li><b>Estensione della retta</b>: lunghezza del segmento. 0 = automatica dai punti. Con valore manuale il segmento è centrato sul centroide.</li>
  <li><b>Tipo di output geometria</b>: 2D (Z ignorata) o 3D (LineStringZ).</li>
  <li><b>Usa RANSAC</b>: attiva il fit robusto agli outlier.</li>
  <li><b>RANSAC: soglia inlier</b>: distanza massima per considerare un punto inlier. 0 = auto da MAD.</li>
  <li><b>Soglia outlier (× RMSE)</b>: moltiplicatore di RMSE oltre il quale un punto è marcato come outlier nel layer di output (default 2.5).</li>
</ul>

<h4>Output</h4>
<h4>Retta best-fit</h4>
<p>Segmento (LineString o LineStringZ) con i seguenti attributi:</p>
<ul>
  <li><b>centroid_x/y/z</b>: coordinate del centroide.</li>
  <li><b>dir_x/y/z</b>: componenti del vettore unitario direzione.</li>
  <li><b>azimuth_deg</b>: azimuth della retta (0–360°, dal Nord in senso orario, sulla proiezione XY).</li>
  <li><b>plunge_deg</b>: angolo di immersione (0° = orizzontale, 90° = verticale; solo in modalità 3D).</li>
  <li><b>rmse</b>: errore quadratico medio dei residui ortogonali.</li>
  <li><b>residual_median</b>: mediana dei residui (robusta agli outlier).</li>
  <li><b>residual_iqr</b>: range interquartile dei residui.</li>
  <li><b>extension</b>: lunghezza effettiva del segmento.</li>
  <li><b>n_points</b>: numero di punti totali.</li>
  <li><b>n_used</b>: numero di punti usati nel fit (uguale a n_points se RANSAC non è attivo).</li>
  <li><b>n_outliers</b>: numero di punti con residuo &gt; soglia.</li>
  <li><b>mode</b>: modalità (2D o 3D).</li>
  <li><b>used_ransac</b>: True se il fit è stato fatto con RANSAC.</li>
</ul>

<h4>Punti con residui</h4>
<p>Copia del layer di input con i seguenti attributi aggiuntivi:</p>
<ul>
  <li><b>fid</b>: identificatore originale del feature.</li>
  <li><b>residual</b>: distanza euclidea punto-proiezione.</li>
  <li><b>t_param</b>: ascissa segnata lungo la retta misurata dal centroide.</li>
  <li><b>proj_x/y/z</b>: coordinate della proiezione ortogonale.</li>
  <li><b>is_outlier</b>: True se residuo &gt; soglia × RMSE.</li>
  <li><b>is_inlier</b>: (solo se RANSAC attivo) True se selezionato come inlier dal RANSAC.</li>
  <li><b>weight</b>: (solo se è stato passato un campo peso) peso usato nel fit.</li>
</ul>

<p><b>Nota CRS:</b> Per risultati corretti il layer deve essere in un CRS proiettato (metri). In CRS geografici (gradi) le distanze risultano distorte; viene mostrato un warning.</p>
"""

    @staticmethod
    def _fit_pca(coords, weights, use_z):
        """PCA (eventualmente pesata) su nuvola di punti."""
        if weights is None:
            centroid = coords.mean(axis=0)
            centered = coords - centroid
            _, _, Vt = np.linalg.svd(centered, full_matrices=False)
        else:
            w = weights / weights.sum()
            centroid = (w[:, None] * coords).sum(axis=0)
            centered = coords - centroid
            weighted = np.sqrt(weights)[:, None] * centered
            _, _, Vt = np.linalg.svd(weighted, full_matrices=False)

        direction = Vt[0].copy()
        if not use_z:
            direction[2] = 0.0
            n = np.linalg.norm(direction)
            if n > 1e-10:
                direction /= n
            else:
                # tutti i punti coincidono in XY: direzione fittizia
                direction = np.array([1.0, 0.0, 0.0])
        return centroid, direction

    @staticmethod
    def _residuals(coords, centroid, direction, use_z):
        centered = coords - centroid
        t_vals   = centered @ direction
        proj     = centroid + np.outer(t_vals, direction)
        diffs    = coords - proj
        if not use_z:
            res = np.linalg.norm(diffs[:, :2], axis=1)
        else:
            res = np.linalg.norm(diffs, axis=1)
        return t_vals, proj, res

    @staticmethod
    def _ransac_line(coords, threshold, max_iters, use_z, rng):
        """RANSAC su retta. Modello = retta passante per 2 punti random."""
        n = len(coords)
        if n < 2:
            return None
        best_inliers = None
        best_count   = -1
        for _ in range(max_iters):
            i, j = rng.choice(n, size=2, replace=False)
            d = coords[j] - coords[i]
            if not use_z:
                d = d.copy()
                d[2] = 0.0
            norm = np.linalg.norm(d)
            if norm < 1e-12:
                continue
            d = d / norm
            diff = coords - coords[i]
            t = diff @ d
            proj = coords[i] + np.outer(t, d)
            delta = coords - proj
            if not use_z:
                dist = np.linalg.norm(delta[:, :2], axis=1)
            else:
                dist = np.linalg.norm(delta, axis=1)
            inliers = dist <= threshold
            count = int(inliers.sum())
            if count > best_count:
                best_count   = count
                best_inliers = inliers
        return best_inliers

    def processAlgorithm(self, parameters, context, feedback):
        source     = self.parameterAsSource(parameters, self.INPUT, context)
        extension  = self.parameterAsDouble(parameters, self.EXTENSION, context)
        mode_idx   = self.parameterAsEnum(parameters, self.OUTPUT_MODE, context)
        use_ransac = self.parameterAsBoolean(parameters, self.USE_RANSAC, context)
        ransac_th  = self.parameterAsDouble(parameters, self.RANSAC_THRESHOLD, context)
        outlier_k  = self.parameterAsDouble(parameters, self.OUTLIER_THRESHOLD, context)
        weight_fld = self.parameterAsString(parameters, self.WEIGHT_FIELD, context)

        # ── 0. Verifica CRS ────────────────────────────────────────────────────
        crs = source.sourceCrs()
        if crs.isGeographic():
            feedback.pushWarning(
                "ATTENZIONE: il CRS è geografico (gradi). Distanze e residui non "
                "saranno in unità metriche e i risultati potranno essere distorti. "
                "Riproietta il layer in un CRS proiettato (es. UTM) prima del fit.")

        # ── 1. Raccolta coordinate e pesi ──────────────────────────────────────
        ids, coords, weights = [], [], []
        detected_z = False

        for feat in source.getFeatures():
            geom = feat.geometry()
            pt   = geom.constGet()
            feat_has_z = (
                QgsWkbTypes.hasZ(geom.wkbType()) and
                pt.z() == pt.z()  # NaN check
            )
            z = pt.z() if feat_has_z else 0.0
            if feat_has_z and z != 0.0:
                detected_z = True
            ids.append(feat.id())
            coords.append([pt.x(), pt.y(), z])
            if weight_fld:
                w = feat[weight_fld]
                try:
                    w = float(w) if w is not None else 1.0
                except (TypeError, ValueError):
                    w = 1.0
                if w <= 0 or w != w:  # esclude NaN o non positivi
                    w = 1.0
                weights.append(w)

        if len(coords) < 2:
            raise Exception("Servono almeno 2 punti.")

        coords      = np.array(coords, dtype=float)
        weights_arr = np.array(weights, dtype=float) if weights else None

        # ── 2. Modalità output ────────────────────────────────────────────────
        if mode_idx == 0:
            use_z = False
            feedback.pushInfo("Modalità: output 2D.")
        else:
            use_z = True
            if not detected_z:
                feedback.pushWarning(
                    "Forzato 3D ma i punti non hanno Z reale: Z=0 usato come fallback.")
            feedback.pushInfo("Modalità: output 3D.")

        # ── 3. RANSAC opzionale ────────────────────────────────────────────────
        used_ransac    = False
        ransac_inliers = None
        if use_ransac:
            if ransac_th <= 0.0:
                # auto-soglia da MAD su un fit preliminare
                pre_c, pre_d = self._fit_pca(coords, weights_arr, use_z)
                _, _, pre_res = self._residuals(coords, pre_c, pre_d, use_z)
                mad = float(np.median(np.abs(pre_res - np.median(pre_res))))
                ransac_th = max(2.5 * 1.4826 * mad, 1e-9)
                feedback.pushInfo(f"RANSAC soglia auto: {ransac_th:.4f}")

            rng     = np.random.default_rng(42)
            n_iters = max(100, min(5000, len(coords) * 50))
            inliers = self._ransac_line(coords, ransac_th, n_iters, use_z, rng)
            if inliers is None or int(inliers.sum()) < 2:
                feedback.pushWarning(
                    "RANSAC non ha trovato abbastanza inlier. Uso fit standard.")
            else:
                used_ransac    = True
                ransac_inliers = inliers
                n_inl = int(inliers.sum())
                feedback.pushInfo(
                    f"RANSAC: {n_inl}/{len(coords)} inlier "
                    f"({100.0 * n_inl / len(coords):.1f}%)")

        # ── 4. Fit PCA finale (su inlier se RANSAC) ───────────────────────────
        if used_ransac:
            fit_coords  = coords[ransac_inliers]
            fit_weights = weights_arr[ransac_inliers] if weights_arr is not None else None
        else:
            fit_coords  = coords
            fit_weights = weights_arr
        centroid, direction = self._fit_pca(fit_coords, fit_weights, use_z)

        # ── 5. Residui (su TUTTI i punti) ─────────────────────────────────────
        t_vals, proj, residuals = self._residuals(coords, centroid, direction, use_z)
        rmse = float(np.sqrt((residuals ** 2).mean()))

        # ── 6. Statistiche estese ─────────────────────────────────────────────
        res_median = float(np.median(residuals))
        res_std    = float(residuals.std())
        q1, q3     = np.percentile(residuals, [25, 75])
        iqr        = float(q3 - q1)

        outlier_threshold = outlier_k * rmse
        is_outlier_arr    = residuals > outlier_threshold
        n_outliers        = int(is_outlier_arr.sum())

        feedback.pushInfo(f"Centroide:        {centroid.round(3)}")
        feedback.pushInfo(f"Direzione:        {direction.round(4)}")
        feedback.pushInfo(f"Punti totali:     {len(coords)}")
        feedback.pushInfo(f"Punti usati fit:  {len(fit_coords)}")
        feedback.pushInfo(f"Residuo medio:    {residuals.mean():.4f}")
        feedback.pushInfo(f"Residuo mediano:  {res_median:.4f}")
        feedback.pushInfo(f"Residuo max:      {residuals.max():.4f}")
        feedback.pushInfo(f"Residuo std:      {res_std:.4f}")
        feedback.pushInfo(f"IQR residui:      {iqr:.4f}")
        feedback.pushInfo(f"RMSE:             {rmse:.4f}")
        feedback.pushInfo(
            f"Outlier (>{outlier_k}·RMSE): {n_outliers}/{len(coords)}")

        # ── 7. Azimuth/plunge ─────────────────────────────────────────────────
        # Convenzione: trend (azimuth della proiezione XY dal Nord, senso orario);
        # plunge = angolo della linea sotto l'orizzontale (positivo verso il basso).
        # Si forza il verso con dz <= 0 per coerenza geologica.
        d_oriented = direction.copy()
        if d_oriented[2] > 0:
            d_oriented = -d_oriented
        azimuth = float(np.degrees(np.arctan2(d_oriented[0], d_oriented[1])) % 360.0)
        if use_z:
            plunge = float(np.degrees(np.arcsin(min(1.0, max(-1.0, -d_oriented[2])))))
        else:
            plunge = 0.0

        # ── 8. Estremi della retta ────────────────────────────────────────────
        if extension == 0.0:
            t_lo, t_hi = float(t_vals.min()), float(t_vals.max())
            p1 = centroid + direction * t_lo
            p2 = centroid + direction * t_hi
            extension = t_hi - t_lo
            feedback.pushInfo(
                f"Estensione automatica: {extension:.4f} unità mappa "
                f"(da t={t_lo:.4f} a t={t_hi:.4f}).")
        else:
            p1 = centroid - direction * extension / 2.0
            p2 = centroid + direction * extension / 2.0
            feedback.pushInfo(f"Estensione manuale: {extension:.4f} unità mappa.")

        # ── 9. Tipi geometria ────────────────────────────────────────────────
        geom_type_line  = QgsWkbTypes.LineStringZ if use_z else QgsWkbTypes.LineString
        geom_type_point = QgsWkbTypes.PointZ      if use_z else QgsWkbTypes.Point

        # ── 10. Output retta ─────────────────────────────────────────────────
        fields_line = QgsFields()
        for name in ('centroid_x', 'centroid_y', 'centroid_z',
                     'dir_x', 'dir_y', 'dir_z',
                     'azimuth_deg', 'plunge_deg',
                     'rmse', 'residual_median', 'residual_iqr',
                     'extension'):
            fields_line.append(QgsField(name, QVariant.Double))
        fields_line.append(QgsField('n_points',    QVariant.Int))
        fields_line.append(QgsField('n_used',      QVariant.Int))
        fields_line.append(QgsField('n_outliers',  QVariant.Int))
        fields_line.append(QgsField('mode',        QVariant.String))
        fields_line.append(QgsField('used_ransac', QVariant.Bool))

        (sink_line, dest_line) = self.parameterAsSink(
            parameters, self.OUTPUT_LINE, context,
            fields_line, geom_type_line, source.sourceCrs())

        f_line = QgsFeature(fields_line)
        if use_z:
            geom_line = QgsGeometry.fromPolyline([
                QgsPoint(p1[0], p1[1], p1[2]),
                QgsPoint(p2[0], p2[1], p2[2])
            ])
        else:
            geom_line = QgsGeometry.fromPolylineXY([
                QgsPointXY(p1[0], p1[1]),
                QgsPointXY(p2[0], p2[1])
            ])
        f_line.setGeometry(geom_line)
        f_line.setAttributes([
            float(centroid[0]), float(centroid[1]), float(centroid[2]),
            float(direction[0]), float(direction[1]), float(direction[2]),
            azimuth, plunge,
            rmse, res_median, iqr, float(extension),
            len(coords), len(fit_coords), n_outliers,
            '3D' if use_z else '2D', bool(used_ransac)
        ])
        sink_line.addFeature(f_line)

        # ── 11. Output punti con residui ─────────────────────────────────────
        fields_pts = QgsFields()
        fields_pts.append(QgsField('fid',        QVariant.Int))
        fields_pts.append(QgsField('residual',   QVariant.Double))
        fields_pts.append(QgsField('t_param',    QVariant.Double))
        fields_pts.append(QgsField('proj_x',     QVariant.Double))
        fields_pts.append(QgsField('proj_y',     QVariant.Double))
        fields_pts.append(QgsField('proj_z',     QVariant.Double))
        fields_pts.append(QgsField('is_outlier', QVariant.Bool))
        if used_ransac:
            fields_pts.append(QgsField('is_inlier', QVariant.Bool))
        if weights_arr is not None:
            fields_pts.append(QgsField('weight', QVariant.Double))

        (sink_pts, dest_pts) = self.parameterAsSink(
            parameters, self.OUTPUT_POINTS, context,
            fields_pts, geom_type_point, source.sourceCrs())

        for i in range(len(coords)):
            pt = coords[i]
            f  = QgsFeature(fields_pts)
            if use_z:
                f.setGeometry(QgsGeometry.fromPoint(
                    QgsPoint(pt[0], pt[1], pt[2])))
            else:
                f.setGeometry(QgsGeometry.fromPointXY(
                    QgsPointXY(pt[0], pt[1])))
            attrs = [
                int(ids[i]),
                float(residuals[i]),
                float(t_vals[i]),
                float(proj[i, 0]), float(proj[i, 1]), float(proj[i, 2]),
                bool(is_outlier_arr[i]),
            ]
            if used_ransac:
                attrs.append(bool(ransac_inliers[i]))
            if weights_arr is not None:
                attrs.append(float(weights_arr[i]))
            f.setAttributes(attrs)
            sink_pts.addFeature(f)

        return {self.OUTPUT_LINE: dest_line, self.OUTPUT_POINTS: dest_pts}

    def name(self):           return 'bestfitline'
    def displayName(self):    return 'Best-fit Line 2D/3D (PCA)'
    def group(self):          return 'Best-fit'
    def groupId(self):        return 'best-fit'
    def createInstance(self): return BestFitLine()
