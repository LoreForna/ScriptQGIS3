from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterNumber,
    QgsProcessingParameterField,
    QgsProcessingParameterBoolean,
    QgsFeature, QgsGeometry, QgsWkbTypes,
    QgsFields, QgsField, QgsPoint,
    QgsMultiLineString, QgsLineString,
)
try:
    from qgis.PyQt.QtCore import QVariant
except ImportError:
    # QGIS 4 / PyQt6: QVariant non esiste piu' — usa QMetaType
    from qgis.PyQt.QtCore import QMetaType
    class QVariant:
        Double = QMetaType.Type.Double
        Int    = QMetaType.Type.Int
        String = QMetaType.Type.QString
        Bool   = QMetaType.Type.Bool
import numpy as np


class BestFitSphere(QgsProcessingAlgorithm):

    INPUT             = 'INPUT'
    WEIGHT_FIELD      = 'WEIGHT_FIELD'
    OUTPUT_SPHERE     = 'OUTPUT_SPHERE'
    OUTPUT_POINTS     = 'OUTPUT_POINTS'
    N_PARALLELS       = 'N_PARALLELS'
    N_MERIDIANS       = 'N_MERIDIANS'
    N_SEGMENTS        = 'N_SEGMENTS'
    USE_RANSAC        = 'USE_RANSAC'
    RANSAC_THRESHOLD  = 'RANSAC_THRESHOLD'
    OUTLIER_THRESHOLD = 'OUTLIER_THRESHOLD'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, 'Layer di punti 3D',
            [QgsProcessing.TypeVectorPoint]))

        self.addParameter(QgsProcessingParameterField(
            self.WEIGHT_FIELD,
            'Campo peso (opzionale)',
            parentLayerParameterName=self.INPUT,
            type=QgsProcessingParameterField.Numeric,
            optional=True))

        self.addParameter(QgsProcessingParameterNumber(
            self.N_PARALLELS,
            'Numero di paralleli (cerchi orizzontali)',
            defaultValue=7, minValue=1,
            type=QgsProcessingParameterNumber.Integer))

        self.addParameter(QgsProcessingParameterNumber(
            self.N_MERIDIANS,
            'Numero di meridiani',
            defaultValue=12, minValue=2,
            type=QgsProcessingParameterNumber.Integer))

        self.addParameter(QgsProcessingParameterNumber(
            self.N_SEGMENTS,
            'Segmenti per cerchio',
            defaultValue=72, minValue=8,
            type=QgsProcessingParameterNumber.Integer))

        self.addParameter(QgsProcessingParameterBoolean(
            self.USE_RANSAC,
            'Usa RANSAC (robusto agli outlier)',
            defaultValue=False))

        self.addParameter(QgsProcessingParameterNumber(
            self.RANSAC_THRESHOLD,
            'RANSAC: soglia inlier (unità mappa, 0 = auto)',
            defaultValue=0.0, minValue=0.0,
            type=QgsProcessingParameterNumber.Double))

        self.addParameter(QgsProcessingParameterNumber(
            self.OUTLIER_THRESHOLD,
            'Soglia outlier (× RMSE)',
            defaultValue=2.5, minValue=0.0,
            type=QgsProcessingParameterNumber.Double))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_SPHERE, 'Sfera best-fit (wireframe)',
            QgsProcessing.TypeVectorLine))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_POINTS, 'Punti con residui',
            QgsProcessing.TypeVectorPoint))

    def shortHelpString(self):
        return """

<p>Calcola la <b>sfera</b> 3D che meglio approssima una nuvola di punti, minimizzando i residui radiali. Generalizzazione 3D del cerchio. La rappresentazione di output è un <b>wireframe</b> composto da paralleli e meridiani.</p>

<h4>Metodo di calcolo</h4>
<p>Si linearizza l'equazione della sfera: x² + y² + z² = a·x + b·y + c·z + d, dove cx=a/2, cy=b/2, cz=c/2, r²=d+cx²+cy²+cz². I punti vengono <b>centrati e normalizzati</b> per stabilità numerica con coordinate UTM. Il sistema lineare viene risolto con <b>numpy lstsq</b>.</p>

<p>Con <b>4 punti</b> non complanari il fit è esatto (RMSE=0). Con più punti è una regressione algebrica ai minimi quadrati.</p>

<h4>RANSAC (opzionale)</h4>
<p>Campiona quadruple di punti random, costruisce la sfera passante per i 4 punti e identifica gli inlier; il fit finale è applicato solo agli inlier del miglior modello.</p>

<h4>Output — Sfera (wireframe)</h4>
<p>MultiLineStringZ formato da N paralleli + N meridiani. Attributi:</p>
<ul>
  <li><b>center_x / y / z</b>, <b>radius</b>.</li>
  <li><b>rmse</b>, <b>residual_median</b>, <b>residual_iqr</b>.</li>
  <li><b>volume</b> = 4/3·π·r³, <b>surface</b> = 4·π·r².</li>
  <li><b>n_points</b>, <b>n_used</b>, <b>n_outliers</b>, <b>used_ransac</b>.</li>
</ul>

<h4>Output — Punti con residui</h4>
<ul>
  <li><b>fid</b>, <b>residual</b> (distanza radiale al cerchio = | dist_dal_centro − raggio |).</li>
  <li><b>theta_deg</b> (longitudine 0–360°), <b>phi_deg</b> (latitudine -90°–90°).</li>
  <li><b>proj_x/y/z</b>: proiezione radiale del punto sulla sfera.</li>
  <li><b>is_outlier</b>, <b>is_inlier</b> (con RANSAC), <b>weight</b> (con campo peso).</li>
</ul>

<h4>Casi d'uso</h4>
<ul>
  <li>Cupole, cisterne emisferiche, calotte, volte.</li>
  <li>Modellazione di volte intere o porzioni di esse.</li>
  <li>Verifica della sfericità di oggetti modellati 3D.</li>
</ul>

<p><b>Nota CRS:</b> Il layer deve essere in un CRS proiettato e i punti devono avere coordinata Z reale.</p>
"""

    @staticmethod
    def _fit_sphere(xyz, weights=None):
        """
        Fit algebrico 3D della sfera con centramento e normalizzazione.
        Linearizza x²+y²+z² = a·x+b·y+c·z+d.
        Ritorna (cx, cy, cz, r).
        """
        x_mean = float(xyz[:, 0].mean())
        y_mean = float(xyz[:, 1].mean())
        z_mean = float(xyz[:, 2].mean())
        scale  = float(np.sqrt(((xyz[:, 0] - x_mean)**2 +
                                (xyz[:, 1] - y_mean)**2 +
                                (xyz[:, 2] - z_mean)**2).mean()))
        if scale < 1e-10:
            raise Exception("Punti coincidenti o troppo vicini.")

        xn = (xyz[:, 0] - x_mean) / scale
        yn = (xyz[:, 1] - y_mean) / scale
        zn = (xyz[:, 2] - z_mean) / scale

        rhs   = xn**2 + yn**2 + zn**2
        A_mat = np.column_stack([xn, yn, zn, np.ones(len(xn))])

        if weights is not None:
            w = np.sqrt(weights)
            A_mat = A_mat * w[:, None]
            rhs   = rhs * w

        res, _, _, _ = np.linalg.lstsq(A_mat, rhs, rcond=None)
        cx_n = float(res[0]) / 2.0
        cy_n = float(res[1]) / 2.0
        cz_n = float(res[2]) / 2.0
        r2_n = float(res[3]) + cx_n**2 + cy_n**2 + cz_n**2
        if r2_n <= 0:
            raise Exception("Punti complanari o degenere: fit sfera impossibile.")
        cx = cx_n * scale + x_mean
        cy = cy_n * scale + y_mean
        cz = cz_n * scale + z_mean
        r  = float(np.sqrt(r2_n)) * scale
        return cx, cy, cz, r

    @classmethod
    def _ransac_sphere(cls, xyz, threshold, max_iters, rng):
        n = len(xyz)
        if n < 4:
            return None
        best_inliers = None
        best_count   = -1
        for _ in range(max_iters):
            idx = rng.choice(n, size=4, replace=False)
            try:
                cx, cy, cz, r = cls._fit_sphere(xyz[idx])
            except Exception:
                continue
            d   = np.linalg.norm(xyz - np.array([cx, cy, cz]), axis=1)
            res = np.abs(d - r)
            inliers = res <= threshold
            count   = int(inliers.sum())
            if count > best_count:
                best_count   = count
                best_inliers = inliers
        return best_inliers

    def processAlgorithm(self, parameters, context, feedback):
        source       = self.parameterAsSource(parameters, self.INPUT, context)
        n_parallels  = self.parameterAsInt(parameters, self.N_PARALLELS, context)
        n_meridians  = self.parameterAsInt(parameters, self.N_MERIDIANS, context)
        n_segments   = self.parameterAsInt(parameters, self.N_SEGMENTS, context)
        use_ransac   = self.parameterAsBoolean(parameters, self.USE_RANSAC, context)
        ransac_th    = self.parameterAsDouble(parameters, self.RANSAC_THRESHOLD, context)
        outlier_k    = self.parameterAsDouble(parameters, self.OUTLIER_THRESHOLD, context)
        weight_fld   = self.parameterAsString(parameters, self.WEIGHT_FIELD, context)

        crs = source.sourceCrs()
        if crs.isGeographic():
            feedback.pushWarning(
                "ATTENZIONE: il CRS è geografico. Riproietta in CRS proiettato.")

        # ── 1. Raccolta coordinate 3D ─────────────────────────────────────────
        ids, xyz, weights = [], [], []
        detected_z = False
        for feat in source.getFeatures():
            geom = feat.geometry()
            pt   = geom.constGet()
            has_z = (
                QgsWkbTypes.hasZ(geom.wkbType()) and pt.z() == pt.z()
            )
            z = pt.z() if has_z else 0.0
            if has_z and z != 0.0:
                detected_z = True
            ids.append(feat.id())
            xyz.append([float(pt.x()), float(pt.y()), z])
            if weight_fld:
                w = feat[weight_fld]
                try:
                    w = float(w) if w is not None else 1.0
                except (TypeError, ValueError):
                    w = 1.0
                if w <= 0 or w != w:
                    w = 1.0
                weights.append(w)

        if len(xyz) < 4:
            raise Exception("Servono almeno 4 punti per fittare una sfera.")
        if not detected_z:
            feedback.pushWarning(
                "I punti non hanno Z reale: il fit della sfera fallirà o sarà degenere.")

        xyz         = np.array(xyz, dtype=float)
        weights_arr = np.array(weights, dtype=float) if weights else None
        feedback.pushInfo(f"Punti letti: {len(xyz)}")

        # ── 2. RANSAC opzionale ───────────────────────────────────────────────
        used_ransac    = False
        ransac_inliers = None
        if use_ransac:
            if ransac_th <= 0.0:
                pre_cx, pre_cy, pre_cz, pre_r = self._fit_sphere(xyz, weights_arr)
                pre_res = np.abs(
                    np.linalg.norm(xyz - [pre_cx, pre_cy, pre_cz], axis=1) - pre_r)
                mad = float(np.median(np.abs(pre_res - np.median(pre_res))))
                ransac_th = max(2.5 * 1.4826 * mad, 1e-9)
                feedback.pushInfo(f"RANSAC soglia auto: {ransac_th:.6f}")
            rng     = np.random.default_rng(42)
            n_iters = max(200, min(5000, len(xyz) * 50))
            inliers = self._ransac_sphere(xyz, ransac_th, n_iters, rng)
            if inliers is None or int(inliers.sum()) < 4:
                feedback.pushWarning(
                    "RANSAC non ha trovato abbastanza inlier. Uso fit standard.")
            else:
                used_ransac    = True
                ransac_inliers = inliers
                feedback.pushInfo(
                    f"RANSAC: {int(inliers.sum())}/{len(xyz)} inlier "
                    f"({100.0 * inliers.sum() / len(xyz):.1f}%)")

        # ── 3. Fit finale ─────────────────────────────────────────────────────
        if used_ransac:
            fit_xyz     = xyz[ransac_inliers]
            fit_weights = weights_arr[ransac_inliers] if weights_arr is not None else None
        else:
            fit_xyz     = xyz
            fit_weights = weights_arr
        cx, cy, cz, radius = self._fit_sphere(fit_xyz, fit_weights)
        feedback.pushInfo(
            f"Centro: ({cx:.6f}, {cy:.6f}, {cz:.6f})  Raggio: {radius:.6f}")

        # ── 4. Residui (su TUTTI i punti) ─────────────────────────────────────
        diff             = xyz - np.array([cx, cy, cz])
        dist_from_center = np.linalg.norm(diff, axis=1)
        residuals        = np.abs(dist_from_center - radius)
        rmse             = float(np.sqrt((residuals**2).mean()))

        # Coordinate sferiche
        theta_rad = np.arctan2(diff[:, 1], diff[:, 0])         # longitudine
        # latitudine: arcsin(z / r). Limita per stabilità.
        ratio_z = np.clip(diff[:, 2] / np.maximum(dist_from_center, 1e-12), -1.0, 1.0)
        phi_rad = np.arcsin(ratio_z)

        # Proiezione radiale sulla sfera
        proj_xyz = np.empty_like(xyz)
        for i in range(len(xyz)):
            d = dist_from_center[i]
            if d > 1e-10:
                proj_xyz[i] = np.array([cx, cy, cz]) + radius * diff[i] / d
            else:
                proj_xyz[i] = np.array([cx + radius, cy, cz])

        # ── 5. Statistiche ────────────────────────────────────────────────────
        res_median = float(np.median(residuals))
        q1, q3     = np.percentile(residuals, [25, 75])
        iqr        = float(q3 - q1)
        outlier_threshold = outlier_k * rmse
        is_outlier_arr    = residuals > outlier_threshold
        n_outliers        = int(is_outlier_arr.sum())

        feedback.pushInfo(f"RMSE:            {rmse:.6f}")
        feedback.pushInfo(f"Residuo mediano: {res_median:.6f}")
        feedback.pushInfo(
            f"Outlier (>{outlier_k}·RMSE): {n_outliers}/{len(xyz)}")

        # ── 6. Wireframe sfera (paralleli + meridiani) ────────────────────────
        multi = QgsMultiLineString()

        # Paralleli (cerchi a phi costante)
        # Saltiamo i poli (phi = ±π/2) per evitare cerchi degeneri.
        if n_parallels == 1:
            phis = np.array([0.0])
        else:
            # Distribuiti in [-π/2, π/2] saltando i poli
            phis = np.linspace(-np.pi / 2.0, np.pi / 2.0, n_parallels + 2)[1:-1]
        thetas_full = np.linspace(0.0, 2.0 * np.pi, n_segments + 1)
        for phi in phis:
            r_par = radius * np.cos(phi)
            z_par = cz + radius * np.sin(phi)
            ls = QgsLineString()
            for th in thetas_full:
                ls.addVertex(QgsPoint(
                    float(cx + r_par * np.cos(th)),
                    float(cy + r_par * np.sin(th)),
                    float(z_par)))
            multi.addGeometry(ls)

        # Meridiani (cerchi su piani contenenti l'asse Z)
        meridian_thetas = np.linspace(0.0, np.pi, n_meridians, endpoint=False)
        phis_full = np.linspace(-np.pi / 2.0, np.pi / 2.0, n_segments // 2 + 1)
        # un meridiano è in realtà un cerchio massimo: due semicerchi opposti.
        # Per semplicità tracciamo entrambi i lati come unica polilinea da -π/2 a 3π/2.
        for theta_m in meridian_thetas:
            ls = QgsLineString()
            angles = np.linspace(0.0, 2.0 * np.pi, n_segments + 1)
            for ang in angles:
                # Punto sul cerchio massimo nel piano (theta_m): parametro = ang
                # Direzione "x_local" = (cos(theta_m), sin(theta_m), 0)
                # Direzione "z_local" = (0, 0, 1)
                ls.addVertex(QgsPoint(
                    float(cx + radius * np.cos(ang) * np.cos(theta_m)),
                    float(cy + radius * np.cos(ang) * np.sin(theta_m)),
                    float(cz + radius * np.sin(ang))))
            multi.addGeometry(ls)

        sphere_geom = QgsGeometry(multi)

        # ── 7. Output sfera ───────────────────────────────────────────────────
        fields_sp = QgsFields()
        for name in ('center_x', 'center_y', 'center_z', 'radius',
                     'rmse', 'residual_median', 'residual_iqr',
                     'volume', 'surface'):
            fields_sp.append(QgsField(name, QVariant.Double))
        fields_sp.append(QgsField('n_points',    QVariant.Int))
        fields_sp.append(QgsField('n_used',      QVariant.Int))
        fields_sp.append(QgsField('n_outliers',  QVariant.Int))
        fields_sp.append(QgsField('used_ransac', QVariant.Bool))

        (sink_sp, dest_sp) = self.parameterAsSink(
            parameters, self.OUTPUT_SPHERE, context,
            fields_sp, QgsWkbTypes.MultiLineStringZ, source.sourceCrs())

        f_sp = QgsFeature(fields_sp)
        f_sp.setGeometry(sphere_geom)
        f_sp.setAttributes([
            float(cx), float(cy), float(cz), float(radius),
            rmse, res_median, iqr,
            float((4.0 / 3.0) * np.pi * radius**3),
            float(4.0 * np.pi * radius**2),
            len(xyz), len(fit_xyz), n_outliers,
            bool(used_ransac),
        ])
        sink_sp.addFeature(f_sp)

        # ── 8. Output punti ───────────────────────────────────────────────────
        fields_pts = QgsFields()
        fields_pts.append(QgsField('fid',        QVariant.Int))
        fields_pts.append(QgsField('residual',   QVariant.Double))
        fields_pts.append(QgsField('theta_deg',  QVariant.Double))
        fields_pts.append(QgsField('phi_deg',    QVariant.Double))
        fields_pts.append(QgsField('proj_x',     QVariant.Double))
        fields_pts.append(QgsField('proj_y',     QVariant.Double))
        fields_pts.append(QgsField('proj_z',     QVariant.Double))
        fields_pts.append(QgsField('is_outlier', QVariant.Bool))
        if used_ransac:
            fields_pts.append(QgsField('is_inlier', QVariant.Bool))
        if weights_arr is not None:
            fields_pts.append(QgsField('weight', QVariant.Double))

        (sink_pts, dest_pts) = self.parameterAsSink(
            parameters, self.OUTPUT_POINTS, context,
            fields_pts, QgsWkbTypes.PointZ, source.sourceCrs())

        for i in range(len(xyz)):
            pt = xyz[i]
            f  = QgsFeature(fields_pts)
            f.setGeometry(QgsGeometry.fromPoint(QgsPoint(pt[0], pt[1], pt[2])))
            attrs = [
                int(ids[i]),
                float(residuals[i]),
                float(np.degrees(theta_rad[i]) % 360.0),
                float(np.degrees(phi_rad[i])),
                float(proj_xyz[i, 0]), float(proj_xyz[i, 1]), float(proj_xyz[i, 2]),
                bool(is_outlier_arr[i]),
            ]
            if used_ransac:
                attrs.append(bool(ransac_inliers[i]))
            if weights_arr is not None:
                attrs.append(float(weights_arr[i]))
            f.setAttributes(attrs)
            sink_pts.addFeature(f)

        return {self.OUTPUT_SPHERE: dest_sp, self.OUTPUT_POINTS: dest_pts}

    def name(self):           return 'bestfitsphere'
    def displayName(self):    return 'Best-fit Sphere 3D'
    def group(self):          return 'Best-fit'
    def groupId(self):        return 'best-fit'
    def createInstance(self): return BestFitSphere()
