"""
Filesystem scanner for vector and raster sources.

Walks a folder (optionally recursive), filters by supported extension,
and returns one metadata dict per file. The QGIS-dependent inspection
step is isolated in `_inspect_with_qgis()` / `_inspect_raster_with_qgis()`,
which are the only things that need `qgis.core`. Tests monkeypatch those
functions so the rest of the module stays unit-testable without a
running QGIS (Rule 4).
"""

from __future__ import annotations

import os
import zipfile
from collections.abc import Iterable
from pathlib import Path
from typing import Dict, List, Optional, Union

from ._paths import long_path as _long_path_impl
from .encoding_detector import detect_encoding

# Map supported extensions -> short format key used in result dicts.
# Lowercase, leading dot included.
SUPPORTED_EXTENSIONS: Dict[str, str] = {
    ".shp": "shp",
    ".tab": "tab",
    ".kml": "kml",
    ".kmz": "kmz",
    ".gml": "gml",
    ".geojson": "geojson",
    ".json": "geojson",
    ".dxf": "dxf",
    ".gpx": "gpx",
    ".mif": "mif",
}

# Raster extensions -> short format key.
SUPPORTED_RASTER_EXTENSIONS: Dict[str, str] = {
    ".tif": "geotiff",
    ".tiff": "geotiff",
    ".jp2": "jp2",
    ".ecw": "ecw",
    ".img": "img",
    ".asc": "asc",
    ".vrt": "vrt",
}

# Archives expanded virtually via GDAL's /vsizip/ and /vsirar/ filesystems.
# Each entry inside becomes a separate item.
_ARCHIVE_EXTENSIONS = {".zip", ".rar"}

# Inner extensions worth surfacing from an archive. Mirrors
# SUPPORTED_EXTENSIONS but excludes .kmz (already a zipped KML — handled
# by OGR directly).
_ARCHIVE_INNER_EXTENSIONS = set(SUPPORTED_EXTENSIONS) - {".kmz"}
# Backward-compatible alias (older tests / callers).
_ZIP_INNER_EXTENSIONS = _ARCHIVE_INNER_EXTENSIONS

# Extensions for which encoding detection makes sense.
# XML-/JSON-based formats are virtually always UTF-8.
_ENCODING_RELEVANT_EXTS = {".shp", ".tab", ".dxf", ".mif"}


def _long_path(path):
    """Backward-compat shim around the shared `_paths.long_path` helper."""
    return _long_path_impl(path)


def _vsizip_uri(zip_path: Path, inner: str) -> str:
    """Build a GDAL /vsizip/ URI. Forward slashes for OGR portability."""
    z = str(zip_path.resolve()).replace("\\", "/")
    return f"/vsizip/{z}/{inner.lstrip('/')}"


def _iter_zip_vector_entries(zip_path: Path) -> Iterable[Dict[str, object]]:
    """
    Yield one metadata dict per supported vector file inside `zip_path`.

    The dict has the same shape used by `scan_folder` results, plus
    `is_virtual=True` and `archive` (the zip Path) so callers can group/log.
    Failures (corrupt zip, IOError) are yielded as a single warning entry.
    """
    # Detect OneDrive / cloud "online-only" placeholders: the file
    # appears in directory listings but isn't materialised on disk.
    # On Windows the GetFileAttributesW call returns 0xFFFFFFFF (-1)
    # for these. We surface a friendly hint instead of a cryptic ENOENT.
    accessible_path = _long_path(zip_path)
    is_online_only_placeholder = False
    try:
        if not os.path.isfile(accessible_path):
            is_online_only_placeholder = True
    except OSError:
        is_online_only_placeholder = True

    try:
        if is_online_only_placeholder:
            raise FileNotFoundError("File not materialised on disk")
        with zipfile.ZipFile(accessible_path) as zf:
            names = zf.namelist()
    except (zipfile.BadZipFile, OSError) as exc:
        if is_online_only_placeholder or isinstance(exc, FileNotFoundError):
            warning = (
                "File non disponibile localmente. Probabilmente è un "
                "placeholder OneDrive/cloud non ancora scaricato: "
                "tasto destro sul file in Esplora risorse → "
                "'Mantieni sempre su questo dispositivo', poi riprova."
            )
        else:
            warning = f"Cannot open ZIP: {exc}"
        # Group by *parent directory of the zip*, not by zip stem.
        # That way multiple zips in the same folder produce one .gpkg.
        parent_label = zip_path.parent.name or "unsorted"
        yield {
            "path": zip_path,
            "format": "zip",
            "name": zip_path.stem,
            "item_type": "vector",
            "geometry_type": "Unknown",
            "crs": "Unknown",
            "feature_count": 0,
            "encoding": "UTF-8",
            "warnings": [warning],
            "is_virtual": True,
            "archive": zip_path,
            "archive_kind": "zip",
            "subfolder": parent_label,
            "is_unreadable": True,
        }
        return

    yield from _emit_archive_entries(zip_path, sorted(names), _vsizip_uri, "zip")


# ---------------------------------------------------------------------------
# RAR archives — GDAL /vsirar/ (requires GDAL >= 3.7 built with libarchive,
# e.g. QGIS 3.44+). zipfile cannot read RAR, so members are enumerated via
# gdal.ReadDirRecursive. Kept parallel to the ZIP path (which stays on the
# stdlib zipfile module, unchanged and fully tested).
# ---------------------------------------------------------------------------

_rar_supported_cache: Optional[bool] = None


def _gdal_vsi_prefixes() -> set:
    """Return GDAL's registered virtual-filesystem prefixes (lazy import)."""
    try:
        from osgeo import gdal  # type: ignore[import-not-found]
    except ImportError:
        return set()
    try:
        return set(gdal.GetFileSystemsPrefixes())
    except Exception:  # noqa: BLE001
        return set()


def rar_supported() -> bool:
    """True when this GDAL build exposes the /vsirar/ filesystem."""
    global _rar_supported_cache
    if _rar_supported_cache is None:
        _rar_supported_cache = "/vsirar/" in _gdal_vsi_prefixes()
    return _rar_supported_cache


def _reset_rar_support_cache() -> None:
    """Test hook: clear the cached capability probe."""
    global _rar_supported_cache
    _rar_supported_cache = None


def _vsirar_uri(rar_path: Path, inner: str) -> str:
    """Build a GDAL /vsirar/ URI. Forward slashes for OGR portability."""
    r = str(rar_path.resolve()).replace("\\", "/")
    return f"/vsirar/{r}/{inner.lstrip('/')}"


def _list_rar_members(rar_path: Path) -> List[str]:
    """List file members of a RAR archive via gdal.ReadDirRecursive.

    Isolated so tests can monkeypatch it without a real GDAL/libarchive.
    """
    from osgeo import gdal  # type: ignore[import-not-found]

    r = str(rar_path.resolve()).replace("\\", "/")
    listing = gdal.ReadDirRecursive(f"/vsirar/{r}")
    return list(listing or [])


def _iter_rar_vector_entries(rar_path: Path) -> Iterable[Dict[str, object]]:
    """
    Yield one metadata dict per supported vector file inside `rar_path`.

    Mirrors `_iter_zip_vector_entries`: same OneDrive-placeholder guard,
    same warning-entry shape on failure, plus a capability warning when
    this GDAL build lacks /vsirar/.
    """
    accessible_path = _long_path(rar_path)
    is_online_only_placeholder = False
    try:
        if not os.path.isfile(accessible_path):
            is_online_only_placeholder = True
    except OSError:
        is_online_only_placeholder = True

    parent_label = rar_path.parent.name or "unsorted"

    def _warning_entry(message: str) -> Dict[str, object]:
        return {
            "path": rar_path,
            "format": "rar",
            "name": rar_path.stem,
            "item_type": "vector",
            "geometry_type": "Unknown",
            "crs": "Unknown",
            "feature_count": 0,
            "encoding": "UTF-8",
            "warnings": [message],
            "is_virtual": True,
            "archive": rar_path,
            "archive_kind": "rar",
            "subfolder": parent_label,
            "is_unreadable": True,
        }

    if is_online_only_placeholder:
        yield _warning_entry(
            "File non disponibile localmente. Probabilmente è un "
            "placeholder OneDrive/cloud non ancora scaricato: "
            "tasto destro sul file in Esplora risorse → "
            "'Mantieni sempre su questo dispositivo', poi riprova."
        )
        return

    if not rar_supported():
        yield _warning_entry(
            "Il GDAL di questa installazione QGIS non supporta gli archivi "
            "RAR (/vsirar/, richiede GDAL ≥ 3.7 con libarchive — disponibile "
            "in QGIS 3.44+). Aggiorna QGIS oppure estrai/riconverti "
            "l'archivio in .zip."
        )
        return

    try:
        names = _list_rar_members(rar_path)
    except Exception as exc:  # noqa: BLE001
        yield _warning_entry(f"Cannot open RAR: {exc}")
        return

    yield from _emit_archive_entries(rar_path, sorted(names), _vsirar_uri, "rar")


def _emit_archive_entries(
    archive_path: Path, names, uri_builder, kind: str
) -> Iterable[Dict[str, object]]:
    """Shared body: turn archive member names into converter item dicts.

    `uri_builder(archive_path, inner)` builds the /vsizip/ or /vsirar/ URI.
    """
    parent_label = archive_path.parent.name or "unsorted"
    for inner in names:
        if inner.endswith("/"):
            continue
        ext = Path(inner).suffix.lower()
        if ext not in _ARCHIVE_INNER_EXTENSIONS:
            continue
        uri = uri_builder(archive_path, inner)
        # Layer name: always include the archive stem so layers from
        # sibling archives in the same group remain traceable, but avoid
        # a redundant "stem__stem" when the inner file matches the stem.
        inner_stem = Path(inner).stem
        layer_name = (
            inner_stem
            if inner_stem == archive_path.stem
            else f"{archive_path.stem}__{inner_stem}"
        )
        yield {
            # Use the archive path (a real file on disk) so callers'
            # `.exists()` checks succeed; the OGR-friendly URI lives
            # in `uri` and is preferred by the converter.
            "path": archive_path,
            "uri": uri,
            "format": SUPPORTED_EXTENSIONS[ext],
            "name": layer_name,
            "item_type": "vector",
            "is_virtual": True,
            "archive": archive_path,
            "archive_kind": kind,
            "subfolder": parent_label,
            "inner_path": inner,
        }


# ---------------------------------------------------------------------------
# QGIS-dependent inspection (kept isolated for testability)
# ---------------------------------------------------------------------------


def _inspect_with_qgis(path) -> Dict[str, object]:
    """
    Open `path` with QgsVectorLayer and extract metadata.

    `path` can be a `pathlib.Path` for a file on disk OR a string-like
    URI (e.g. ``/vsizip/foo.zip/inner.shp``). Strings are passed
    verbatim to OGR, which understands the GDAL virtual filesystems.

    Returns a dict with keys: geometry_type, crs, feature_count, warnings.
    Never raises — failures are reported via the `warnings` list and
    fallback values ("Unknown" / 0).
    """
    warnings: List[str] = []
    geometry_type = "Unknown"
    crs_id = "Unknown"
    feature_count = 0

    try:
        from qgis.core import QgsVectorLayer, QgsWkbTypes
    except ImportError:
        warnings.append("QGIS core not available; metadata limited to filename")
        return {
            "geometry_type": geometry_type,
            "crs": crs_id,
            "feature_count": feature_count,
            "warnings": warnings,
        }

    source = str(path)
    name = Path(source).stem
    layer = QgsVectorLayer(source, name, "ogr")
    if not layer.isValid():
        warnings.append("Layer invalid or unreadable by OGR")
        return {
            "geometry_type": geometry_type,
            "crs": crs_id,
            "feature_count": feature_count,
            "warnings": warnings,
        }

    wkb = layer.wkbType()
    geometry_type = QgsWkbTypes.displayString(wkb) or "Unknown"

    crs = layer.crs()
    if crs.isValid():
        auth = crs.authid()
        crs_id = auth if auth else crs.description() or "Unknown"
    else:
        warnings.append("CRS not recognised")
        crs_id = "Unknown"

    feature_count = max(int(layer.featureCount()), 0)
    return {
        "geometry_type": geometry_type,
        "crs": crs_id,
        "feature_count": feature_count,
        "warnings": warnings,
    }


def _inspect_raster_with_qgis(path) -> Dict[str, object]:
    """
    Open `path` with QgsRasterLayer and extract metadata.

    Returns a dict with keys: width, height, band_count, crs, warnings.
    Never raises — failures are reported via the `warnings` list.
    """
    warnings: List[str] = []
    width = height = band_count = 0
    crs_id = "Unknown"

    try:
        from qgis.core import QgsRasterLayer
    except ImportError:
        warnings.append("QGIS core not available; metadata limited to filename")
        return {
            "width": width,
            "height": height,
            "band_count": band_count,
            "crs": crs_id,
            "warnings": warnings,
        }

    source = str(path)
    name = Path(source).stem
    layer = QgsRasterLayer(source, name)
    if not layer.isValid():
        warnings.append("Raster invalid or unreadable by GDAL")
        return {
            "width": width,
            "height": height,
            "band_count": band_count,
            "crs": crs_id,
            "warnings": warnings,
        }

    width = layer.width()
    height = layer.height()
    band_count = layer.bandCount()

    crs = layer.crs()
    if crs.isValid():
        auth = crs.authid()
        crs_id = auth if auth else crs.description() or "Unknown"
    else:
        warnings.append("CRS not recognised")
        crs_id = "Unknown"

    return {
        "width": width,
        "height": height,
        "band_count": band_count,
        "crs": crs_id,
        "warnings": warnings,
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def _iter_candidate_files(root: Path, recursive: bool) -> Iterable[Path]:
    """
    Yield files under `root` whose extension is supported directly OR
    is an archive we know how to peek into.

    Uses `os.walk` (not `Path.rglob`) because `pathlib`'s glob has a
    long-standing Windows bug on paths containing characters like
    `°`, `&` or non-ASCII punctuation: `rglob('*')` silently fails to
    descend past the offending segment. `os.walk` walks correctly.
    """
    accepted = set(SUPPORTED_EXTENSIONS) | set(SUPPORTED_RASTER_EXTENSIONS) | _ARCHIVE_EXTENSIONS
    walk_root = _long_path(root)
    if recursive:
        for dirpath, _dirs, filenames in os.walk(walk_root):
            for fname in filenames:
                if Path(fname).suffix.lower() in accepted:
                    # Strip the long-path prefix back so downstream
                    # tools see a clean Path. We re-add it on access.
                    clean_dir = dirpath[4:] if dirpath.startswith("\\\\?\\") else dirpath
                    yield Path(clean_dir) / fname
    else:
        try:
            entries = list(os.scandir(walk_root))
        except OSError:
            return
        for entry in entries:
            if entry.is_file() and Path(entry.name).suffix.lower() in accepted:
                clean = entry.path[4:] if entry.path.startswith("\\\\?\\") else entry.path
                yield Path(clean)


def scan_folder(
    path: Union[str, Path],
    recursive: bool = True,
    flatten_hierarchy: bool = False,
    mirror_hierarchy: bool = False,
) -> List[Dict[str, object]]:
    """
    Scan `path` for supported vector and raster files and return metadata for each.

    Args:
        path: directory to scan.
        recursive: when True (default), descend into subdirectories.
        flatten_hierarchy: when True, the `subfolder` field of each item
            encodes the *full* relative path from `root` (joined with
            ``__``) instead of just the immediate parent name. This lets
            the "by subfolder" grouping preserve a deep hierarchy in the
            output filename.
        mirror_hierarchy: when True, the `subfolder` field encodes the
            full relative path joined with the OS separator (``/``).
            Combined with the "by subfolder" grouping, the converter
            *replicates the input folder structure on disk* — each
            ``.gpkg`` lands inside nested directories that mirror the
            source layout. Wins over ``flatten_hierarchy`` when both
            are passed.

    Returns:
        A list of dicts with keys:
            path, format, name, geometry_type, crs, feature_count,
            encoding, warnings.
        Returns an empty list when `path` does not exist or contains no
        supported files.

    Raises:
        NotADirectoryError: if `path` exists but is not a directory.
    """
    root = Path(path)
    if not root.exists():
        return []
    if not root.is_dir():
        raise NotADirectoryError(f"Not a directory: {root}")

    def _subfolder_label(file_or_zip: Path) -> str:
        """Compute the grouping label honoring the hierarchy flags."""
        try:
            rel = file_or_zip.relative_to(root)
        except ValueError:
            return file_or_zip.parent.name or "unsorted"
        parts = rel.parts[:-1]  # drop filename
        if not parts:
            return root.name or "unsorted"
        if mirror_hierarchy:
            # Forward-slash joined: grouping_strategies will turn this
            # back into nested output directories on disk.
            return "/".join(parts)
        if flatten_hierarchy:
            return "__".join(parts)
        return parts[-1]

    results: List[Dict[str, object]] = []
    for file_path in sorted(_iter_candidate_files(root, recursive)):
        ext = file_path.suffix.lower()

        # Archives: expand into one entry per inner vector file.
        if ext in _ARCHIVE_EXTENSIONS:
            archive_iter = (
                _iter_rar_vector_entries(file_path)
                if ext == ".rar"
                else _iter_zip_vector_entries(file_path)
            )
            for entry in archive_iter:
                if "format" in entry and "geometry_type" not in entry:
                    meta = _inspect_with_qgis(entry["uri"])
                    entry["geometry_type"] = meta["geometry_type"]
                    entry["crs"] = meta["crs"]
                    entry["feature_count"] = meta["feature_count"]
                    entry["encoding"] = "UTF-8"  # vsizip + chardet rarely useful
                    entry["warnings"] = list(meta.get("warnings") or [])
                # When flatten/mirror is on, encode the full hierarchy.
                # Otherwise keep the zip-parent subfolder set inside
                # _iter_zip_vector_entries.
                if flatten_hierarchy or mirror_hierarchy:
                    entry["subfolder"] = _subfolder_label(file_path)
                results.append(entry)
            continue

        # Raster file on disk.
        if ext in SUPPORTED_RASTER_EXTENSIONS:
            fmt = SUPPORTED_RASTER_EXTENSIONS[ext]
            meta = _inspect_raster_with_qgis(file_path)
            warnings_list: List[str] = list(meta.get("warnings") or [])
            w = meta.get("width", 0)
            h = meta.get("height", 0)
            bands = meta.get("band_count", 0)
            results.append(
                {
                    "path": file_path,
                    "format": fmt,
                    "name": file_path.stem,
                    "item_type": "raster",
                    "geometry_type": "Raster",
                    "crs": meta["crs"],
                    "feature_count": 0,
                    "raster_width": w,
                    "raster_height": h,
                    "band_count": bands,
                    "encoding": "N/A",
                    "warnings": warnings_list,
                    "subfolder": _subfolder_label(file_path),
                }
            )
            continue

        # Regular vector file on disk.
        fmt = SUPPORTED_EXTENSIONS[ext]
        encoding = _detect_encoding_safe(file_path, ext)
        meta = _inspect_with_qgis(file_path)

        warnings: List[str] = list(meta.get("warnings") or [])  # type: ignore[arg-type]
        if encoding is None:
            encoding = "UTF-8"
            warnings.append("Encoding detection failed; assumed UTF-8")

        results.append(
            {
                "path": file_path,
                "format": fmt,
                "name": file_path.stem,
                "item_type": "vector",
                "geometry_type": meta["geometry_type"],
                "crs": meta["crs"],
                "feature_count": meta["feature_count"],
                "encoding": encoding,
                "warnings": warnings,
                "subfolder": _subfolder_label(file_path),
            }
        )
    return results


def _detect_encoding_safe(file_path: Path, ext: str) -> Optional[str]:
    """
    Encoding detection that never raises. Returns a label or None.
    XML-/JSON-based formats short-circuit to UTF-8 without probing.
    """
    if ext not in _ENCODING_RELEVANT_EXTS:
        return "UTF-8"
    try:
        return detect_encoding(file_path)
    except Exception:  # noqa: BLE001 - defensive: scanner must never crash on a single file
        return None


__all__ = ["scan_folder", "SUPPORTED_EXTENSIONS", "SUPPORTED_RASTER_EXTENSIONS"]
